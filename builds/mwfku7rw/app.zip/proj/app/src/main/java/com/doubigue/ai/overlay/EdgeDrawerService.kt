package com.doubigue.ai.overlay

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.doubigue.ai.MainActivity
import com.doubigue.ai.R
import com.doubigue.ai.apps.AppController
import com.doubigue.ai.apps.InstalledApp
import com.doubigue.ai.data.AssistantDatabase
import com.doubigue.ai.system.PhoneTools
import com.doubigue.ai.ui.runCommand
import com.doubigue.ai.voice.VoiceEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlin.math.abs

/**
 * Tiroir en arc au bord de l'écran (fenêtre superposée, même autorisation que la bulle).
 * Une fine poignée reste sur le bord ; la tirer vers l'intérieur ouvre l'arc.
 */
class EdgeDrawerService : Service() {
    private lateinit var wm: WindowManager
    private var handle: EdgeHandleView? = null
    private var panel: EdgeArcView? = null
    private var voice: VoiceEngine? = null
    private var db: AssistantDatabase? = null
    private var micTypeActive = false
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val autoClose = Runnable { closePanel() }
    private val releaseVoice = Runnable { voice?.release(); voice = null }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        try { startFg(false) } catch (_: Exception) { stopSelf(); return }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { EdgePrefs.setEnabled(this, false); stopSelf(); return START_NOT_STICKY }
            ACTION_RELOAD -> { closePanelNow(); removeHandle(); addHandle() }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        closePanelNow(); removeHandle(); addHandle()
    }

    // ---------- notification / premier plan ----------
    private fun createChannel() {
        val m = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        m.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Tiroir en arc", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 3, Intent(this, EdgeDrawerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 4, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_doubigue)
            .setContentTitle("Tiroir DOUBIGUE actif")
            .setContentText("Tire depuis le bord de l'écran pour l'ouvrir")
            .setContentIntent(open).setOngoing(true)
            .addAction(0, "Désactiver", stop).build()
    }

    /** Le type « microphone » n'est activé que pendant l'écoute (indicateur micro Android visible). */
    private fun startFg(mic: Boolean) {
        val n = notification()
        when {
            Build.VERSION.SDK_INT >= 34 -> {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                startForeground(NOTIF_ID, n, type)
            }
            Build.VERSION.SDK_INT >= 29 ->
                startForeground(NOTIF_ID, n, if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
            else -> startForeground(NOTIF_ID, n)
        }
    }

    private fun setMicType(on: Boolean): Boolean {
        if (micTypeActive == on) return true
        return try { startFg(on); micTypeActive = on; true } catch (_: Throwable) { false }
    }

    // ---------- poignée ----------
    private fun addHandle() {
        val left = EdgePrefs.side(this) == "left"
        val v = EdgeHandleView(this, left) { openPanel() }
        val lp = WindowManager.LayoutParams(
            (28 * resources.displayMetrics.density).toInt(), (240 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = (if (left) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL }
        try { wm.addView(v, lp); handle = v } catch (_: Exception) { stopSelf() }
    }

    private fun removeHandle() {
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
    }

    // ---------- panneau en arc ----------
    private fun openPanel() {
        if (panel != null) return
        val apps = EdgePrefs.resolveShortcuts(this)
        val left = EdgePrefs.side(this) == "left"
        val view = EdgeArcView(this, apps, left,
            onLaunch = { launchApp(it) }, onMic = { startMic() }, onAssistant = { openAssistant(false) },
            onClose = { closePanel() }, onInteraction = { if (panel?.listening != true) scheduleAutoClose(9000) })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(view, lp) } catch (_: Exception) { return }
        panel = view
        main.removeCallbacks(releaseVoice)
        view.animateIn()
        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        handle?.visibility = View.GONE
        scheduleAutoClose(9000)
    }

    private fun scheduleAutoClose(ms: Long) { main.removeCallbacks(autoClose); main.postDelayed(autoClose, ms) }

    private fun closePanel() {
        main.removeCallbacks(autoClose)
        val p = panel ?: return
        panel = null
        voice?.stopListening()
        setMicType(false)
        p.animateOut { try { wm.removeView(p) } catch (_: Exception) {} }
        handle?.visibility = View.VISIBLE
        main.postDelayed(releaseVoice, 45_000)
    }

    private fun closePanelNow() {
        main.removeCallbacks(autoClose)
        val p = panel ?: return
        panel = null
        voice?.stopListening(); setMicType(false)
        try { wm.removeView(p) } catch (_: Exception) {}
        handle?.visibility = View.VISIBLE
    }

    private fun launchApp(app: InstalledApp) {
        val i = packageManager.getLaunchIntentForPackage(app.packageName) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i) } catch (_: Exception) {}
        closePanel()
    }

    private fun openAssistant(autoListen: Boolean) {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_AUTO_LISTEN, autoListen)
        try { startActivity(i) } catch (_: Exception) {}
        closePanel()
    }

    // ---------- micro direct ----------
    private fun database(): AssistantDatabase = db ?: Room.databaseBuilder(applicationContext, AssistantDatabase::class.java, "doubigue.db")
        .addMigrations(com.doubigue.ai.data.MIGRATION_1_2, com.doubigue.ai.data.MIGRATION_2_3, com.doubigue.ai.data.MIGRATION_3_4, com.doubigue.ai.data.MIGRATION_4_5)
        .build().also { db = it }

    private fun ensureVoice(): VoiceEngine = voice ?: VoiceEngine(applicationContext, { onHeard(it) }, { onVoiceState(it) }).also { voice = it }

    private fun startMic() {
        main.removeCallbacks(autoClose); main.removeCallbacks(releaseVoice)
        val p = panel ?: return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            p.status = "Autorisation micro requise : ouverture de l'assistant…"
            main.postDelayed({ openAssistant(true) }, 700)
            return
        }
        if (!setMicType(true)) { openAssistant(true); return }   // Android refuse le micro ici : repli sur l'assistant
        p.listening = true
        ensureVoice().listen()
    }

    private fun onVoiceState(s: String) {
        val p = panel
        if (s.startsWith("Prêt")) { p?.listening = false; setMicType(false); return }
        val active = s.startsWith("Écoute") || s.startsWith("Je t'écoute") || s.startsWith("Chargement")
        p?.listening = active
        p?.status = if (s.startsWith("Écoute")) "Parlez maintenant…" else s
        if (!active) { setMicType(false); scheduleAutoClose(5000) }
    }

    private fun onHeard(text: String) {
        panel?.status = "« $text »"
        val v = voice ?: return
        val d = database()
        runCommand(applicationContext, text, AppController(applicationContext), PhoneTools(applicationContext), v,
            d.appVoiceConfigDao(), d.learnedCommandDao(), scope) { msg -> main.post { panel?.status = msg } }
        scheduleAutoClose(3500)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        closePanelNow()
        removeHandle()
        voice?.release(); voice = null
        try { db?.close() } catch (_: Exception) {}
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.doubigue.ai.overlay.EDGE_STOP"
        const val ACTION_RELOAD = "com.doubigue.ai.overlay.EDGE_RELOAD"
        private const val CHANNEL_ID = "doubigue_edge"
        private const val NOTIF_ID = 43

        fun start(c: Context) {
            EdgePrefs.setEnabled(c, true)
            ContextCompat.startForegroundService(c, Intent(c, EdgeDrawerService::class.java))
        }
        fun stop(c: Context) {
            EdgePrefs.setEnabled(c, false)
            c.stopService(Intent(c, EdgeDrawerService::class.java))
        }
        fun reload(c: Context) {
            if (EdgePrefs.isEnabled(c)) c.startService(Intent(c, EdgeDrawerService::class.java).setAction(ACTION_RELOAD))
        }
    }
}

/** Fine poignée lumineuse sur le bord ; un glissement vers l'intérieur ouvre le tiroir. */
class EdgeHandleView(context: Context, private val leftSide: Boolean, private val onSwipe: () -> Unit) : View(context) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 114, 221, 235) }
    private var downX = 0f
    private var downY = 0f
    private var fired = false

    override fun onDraw(c: Canvas) {
        val w = 5 * d; val h = 96 * d; val top = (height - h) / 2f
        val r = if (leftSide) RectF(0f, top, w, top + h) else RectF(width - w, top, width.toFloat(), top + h)
        c.drawRoundRect(r, w / 2, w / 2, paint)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (Build.VERSION.SDK_INT >= 29) systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; fired = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX; val dy = e.rawY - downY
                val inward = if (leftSide) dx else -dx
                if (!fired && inward > 36 * d && inward > abs(dy)) { fired = true; onSwipe() }
            }
        }
        return true
    }
}
