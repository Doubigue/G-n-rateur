package com.doubigue.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

/**
 * Reconnaissance vocale 100 % hors ligne avec Vosk.
 * Le modèle (ex. vosk-model-small-fr-0.22) est importé par l'utilisateur dans Paramètres > Voix hors ligne.
 * Aucune synthèse vocale : les sons sont ceux ajoutés par l'utilisateur.
 */
class VoiceEngine(
    context: Context,
    private val onText: (String) -> Unit,
    private val onState: (String) -> Unit
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var service: SpeechService? = null
    @Volatile private var loading = false

    fun listen() {
        if (!VoskModelManager.isInstalled(appContext)) {
            onState("Modèle Vosk absent : importe-le dans Paramètres > Voix hors ligne")
            return
        }
        if (loading) { onState("Chargement du modèle…"); return }
        stopListening()
        val ready = model
        if (ready != null) { start(ready); return }

        loading = true
        onState("Chargement du modèle vocal…")
        Thread {
            try {
                val loaded = Model(VoskModelManager.modelDir(appContext).absolutePath)
                main.post { model = loaded; loading = false; start(loaded) }
            } catch (e: Throwable) {
                main.post { loading = false; onState("Modèle Vosk illisible : réimporte-le (${e.message ?: "erreur"})") }
            }
        }.start()
    }

    private fun start(readyModel: Model) {
        try {
            val rec = Recognizer(readyModel, 16000f)
            recognizer = rec
            val svc = SpeechService(rec, 16000f)
            service = svc
            onState("Écoute hors ligne…")
            svc.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {
                    val partial = extract(hypothesis, "partial")
                    if (partial.isNotBlank()) main.post { onState("Je t'écoute… $partial") }
                }
                override fun onResult(hypothesis: String?) { deliver(extract(hypothesis, "text")) }
                override fun onFinalResult(hypothesis: String?) { deliver(extract(hypothesis, "text")) }
                override fun onError(exception: Exception?) {
                    main.post { onState("Reconnaissance interrompue (${exception?.message ?: "erreur"})"); stopListening() }
                }
                override fun onTimeout() {
                    main.post { onState("Aucune parole détectée"); stopListening() }
                }
            }, 10000)
        } catch (security: SecurityException) {
            onState("Autorisation microphone nécessaire")
            stopListening()
        } catch (e: Throwable) {
            onState("Impossible de démarrer la reconnaissance (${e.message ?: "erreur"})")
            stopListening()
        }
    }

    private fun deliver(text: String) {
        if (text.isBlank()) return
        main.post {
            if (service == null) return@post
            onText(text)
            onState("Prêt · mode hors ligne")
            stopListening()
        }
    }

    private fun extract(json: String?, key: String): String =
        try { JSONObject(json ?: "{}").optString(key, "") } catch (_: Exception) { "" }

    /** À appeler après l'import d'un nouveau modèle. */
    fun reloadModel() {
        stopListening()
        model?.close()
        model = null
    }

    /** Conservée vide : aucune synthèse vocale. */
    @Suppress("UNUSED_PARAMETER")
    fun speak(message: String) {}

    fun stopListening() {
        val svc = service
        val rec = recognizer
        service = null
        recognizer = null
        try { svc?.stop() } catch (_: Exception) {}
        try { svc?.shutdown() } catch (_: Exception) {}
        try { rec?.close() } catch (_: Exception) {}
    }

    fun release() {
        stopListening()
        model?.close()
        model = null
    }
}
