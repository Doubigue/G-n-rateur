package com.doubigue.ai.voice

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

/** Importe un modèle Vosk (zip, ex. vosk-model-small-fr-0.22.zip) dans le stockage privé de l'appli. */
object VoskModelManager {
    fun modelDir(context: Context): File = File(context.filesDir, "vosk/model")

    fun isInstalled(context: Context): Boolean {
        val dir = modelDir(context)
        return File(dir, "am").isDirectory && (File(dir, "conf").isDirectory || File(dir, "graph").isDirectory)
    }

    /** Décompresse le zip choisi. Le dossier racine du zip (vosk-model-small-fr-0.22/) est retiré automatiquement. */
    fun importZip(context: Context, uri: Uri) {
        val root = File(context.filesDir, "vosk").apply { mkdirs() }
        val temp = File(root, "model_tmp")
        temp.deleteRecursively()
        temp.mkdirs()

        // 1re passe : trouver le dossier racine commun
        var prefix: String? = null
        var common = true
        context.contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val first = entry.name.substringBefore('/', missingDelimiterValue = "")
                    if (first.isEmpty()) common = false
                    else if (prefix == null) prefix = first
                    else if (prefix != first) common = false
                    entry = zip.nextEntry
                }
            }
        } ?: throw IllegalArgumentException("Impossible de lire le fichier choisi.")
        val strip = if (common && prefix != null) "$prefix/" else ""

        // 2e passe : extraction (protection contre les chemins « ../ »)
        val tempCanonical = temp.canonicalPath + File.separator
        context.contentResolver.openInputStream(uri)!!.use { raw ->
            ZipInputStream(raw.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.removePrefix(strip)
                    if (name.isNotEmpty()) {
                        val target = File(temp, name)
                        if (!target.canonicalPath.startsWith(tempCanonical)) throw SecurityException("Zip invalide")
                        if (entry.isDirectory) target.mkdirs()
                        else {
                            target.parentFile?.mkdirs()
                            target.outputStream().use { out -> zip.copyTo(out) }
                        }
                    }
                    entry = zip.nextEntry
                }
            }
        }

        if (!(File(temp, "am").isDirectory)) {
            temp.deleteRecursively()
            throw IllegalArgumentException("Ce zip n'est pas un modèle Vosk (dossier « am » introuvable).")
        }
        val target = modelDir(context)
        target.deleteRecursively()
        if (!temp.renameTo(target)) {
            temp.copyRecursively(target, overwrite = true)
            temp.deleteRecursively()
        }
    }

    fun delete(context: Context) {
        modelDir(context).deleteRecursively()
    }
}
