package com.doubigue.ai.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.graphics.drawable.toBitmap
import com.doubigue.ai.apps.InstalledApp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Tiroir en arc : applications le long du bord, sphère micro au centre.
 * - toucher une icône : ouvre l'app ; glisser verticalement : fait défiler ;
 * - toucher la sphère : écoute directe (sans ouvrir l'assistant) ;
 * - tirer encore depuis le bord (ou toucher « Assistant IA ») : ouvre l'assistant.
 */
@SuppressLint("ViewConstructor")
class EdgeArcView(
    context: Context,
    private val apps: List<InstalledApp>,
    private val leftSide: Boolean,
    private val onLaunch: (InstalledApp) -> Unit,
    private val onMic: () -> Unit,
    private val onAssistant: () -> Unit,
    private val onClose: () -> Unit,
    private val onInteraction: () -> Unit
) : View(context) {
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    var status: String = "Touchez le micro pour parler"
        set(value) { field = value; invalidate() }
    var listening: Boolean = false
        set(value) { field = value; invalidate() }

    private var progress = 0f
    private var scroll = 0f
    private var pulse = 0f
    private val step = 17f
    private val spread = 66f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val icons = HashMap<String, Bitmap?>()
    private val assistantRect = RectF()
    private var pulseAnim: ValueAnimator? = null

    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var moved = false
    private var fromEdge = false
    private var assistantFired = false

    private val cyan = 0xFF40E0FF.toInt()
    private val blue = 0xFF4F6BFF.toInt()
    private val violet = 0xFFB45CFF.toInt()
    private val pink = 0xFFFF5CAA.toInt()
    private val orange = 0xFFFFB04A.toInt()
    private val green = 0xFF5CFF9A.toInt()

    init {
        val size = dp(76f).toInt()
        apps.forEach { a -> icons[a.packageName] = try { a.icon.toBitmap(size, size) } catch (_: Throwable) { null } }
    }

    // ---- géométrie (repère « bord gauche », puis miroir si bord droit) ----
    private val radius: Float get() = min(width * 0.50f, height * 0.30f)
    private val centerLx: Float get() = radius + dp(40f)
    private val centerY: Float get() = height * 0.5f
    private val sphereR: Float get() = radius * 0.48f
    private fun fx(x: Float) = if (leftSide) x else width - x
    private fun angleOf(i: Int) = (i - (apps.size - 1) / 2f) * step + scroll
    private fun maxScroll() = max(0f, (apps.size - 1) / 2f * step - 50f)
    private fun tileX(t: Float) = fx(centerLx - radius * cos(Math.toRadians(t.toDouble())).toFloat())
    private fun tileY(t: Float) = centerY + radius * sin(Math.toRadians(t.toDouble())).toFloat()

    fun animateIn() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 260; interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun animateOut(end: () -> Unit) {
        ValueAnimator.ofFloat(progress, 0f).apply {
            duration = 180
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { end() } })
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        pulseAnim?.cancel(); pulseAnim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val p = progress
        c.drawColor(Color.argb((165 * p).toInt(), 3, 7, 20))
        val layer = c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (255 * p).toInt())
        c.translate((1f - p) * dp(110f) * (if (leftSide) -1f else 1f), 0f)
        drawBand(c); drawSphere(c); drawTiles(c); drawChips(c); drawEdgeCue(c)
        c.restoreToCount(layer)
    }

    private fun drawBand(c: Canvas) {
        val cx = fx(centerLx); val cy = centerY
        val half = spread + 14f
        val start = if (leftSide) 180f - half else -half
        val sweep = half * 2f
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = dp(70f); paint.color = Color.argb(48, 140, 190, 255)
        c.drawArc(RectF(cx - radius, cy - radius, cx + radius, cy + radius), start, sweep, false, paint)
        paint.strokeWidth = dp(2.2f)
        paint.shader = SweepGradient(cx, cy, intArrayOf(cyan, blue, violet, pink, cyan), null)
        val off = dp(35f)
        c.drawArc(RectF(cx - radius - off, cy - radius - off, cx + radius + off, cy + radius + off), start, sweep, false, paint)
        c.drawArc(RectF(cx - radius + off, cy - radius + off, cx + radius - off, cy + radius - off), start, sweep, false, paint)
        paint.shader = null
    }

    private fun starPath(cx: Float, cy: Float, s: Float): Path = Path().apply {
        moveTo(cx, cy - s)
        quadTo(cx + s * .12f, cy - s * .12f, cx + s, cy)
        quadTo(cx + s * .12f, cy + s * .12f, cx, cy + s)
        quadTo(cx - s * .12f, cy + s * .12f, cx - s, cy)
        quadTo(cx - s * .12f, cy - s * .12f, cx, cy - s)
        close()
    }

    private fun drawSphere(c: Canvas) {
        val sx = fx(centerLx); val sy = centerY; val r = sphereR
        paint.reset(); paint.isAntiAlias = true
        paint.shader = RadialGradient(sx, sy, r * 1.7f, intArrayOf(0x663A7BFF, 0x00000000), floatArrayOf(.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, r * 1.7f, paint)
        if (listening) for (k in 0..1) {
            val ph = (pulse + k * .5f) % 1f
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(2f); paint.color = Color.argb((150 * (1f - ph)).toInt(), 120, 220, 255)
            c.drawCircle(sx, sy, r * (1.05f + .45f * ph), paint)
        }
        paint.reset(); paint.isAntiAlias = true
        paint.shader = RadialGradient(sx - r * .3f, sy - r * .35f, r * 1.25f,
            intArrayOf(0xFF8FC2FF.toInt(), 0xFF2448D8.toInt(), 0xFF0B1366.toInt()), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, r, paint)
        // anneau orbital coloré
        val period = if (listening) 2500L else 9000L
        val angle = (SystemClock.uptimeMillis() % period) / period.toFloat() * 360f
        val sweep = SweepGradient(sx, sy, intArrayOf(cyan, blue, violet, pink, orange, green, cyan), null)
        sweep.setLocalMatrix(Matrix().apply { setRotate(angle, sx, sy) })
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(3.5f); paint.shader = sweep
        c.save(); c.rotate(-25f, sx, sy)
        c.drawOval(RectF(sx - r * 1.22f, sy - r * .55f, sx + r * 1.22f, sy + r * .55f), paint)
        c.restore()
        // étoile
        val s = r * .30f
        paint.reset(); paint.isAntiAlias = true
        paint.shader = LinearGradient(sx - s, sy - r * .2f - s, sx + s, sy - r * .2f + s, intArrayOf(0xFF4FD8FF.toInt(), violet, orange), null, Shader.TileMode.CLAMP)
        c.drawPath(starPath(sx, sy - r * .2f, s), paint)
        // micro
        val my = sy + r * .42f; val w = r * .2f; val h = r * .36f
        val micColor = if (listening) 0xFF9BF0FF.toInt() else Color.WHITE
        paint.reset(); paint.isAntiAlias = true; paint.color = micColor
        c.drawRoundRect(RectF(sx - w / 2, my - h * .7f, sx + w / 2, my + h * .3f), w / 2, w / 2, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2.4f); paint.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(sx - w * .95f, my - h * .45f, sx + w * .95f, my + h * .45f), 20f, 140f, false, paint)
        c.drawLine(sx, my + h * .45f, sx, my + h * .62f, paint)
        c.drawLine(sx - w * .6f, my + h * .62f, sx + w * .6f, my + h * .62f, paint)
    }

    private fun drawTiles(c: Canvas) {
        for (i in apps.indices) {
            val t = angleOf(i)
            if (abs(t) > spread) continue
            val fade = ((abs(t) - 48f) / (spread - 48f)).coerceIn(0f, 1f)
            val scale = 1f - .3f * fade
            val alpha = (255 * (1f - .75f * fade)).toInt()
            val x = tileX(t); val y = tileY(t); val half = dp(27f) * scale
            val rect = RectF(x - half, y - half, x + half, y + half)
            paint.reset(); paint.isAntiAlias = true; paint.color = Color.argb((alpha * .28f).toInt(), 200, 225, 255)
            c.drawRoundRect(rect, dp(14f) * scale, dp(14f) * scale, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.2f); paint.color = Color.argb((alpha * .55f).toInt(), 160, 210, 255)
            c.drawRoundRect(rect, dp(14f) * scale, dp(14f) * scale, paint)
            icons[apps[i].packageName]?.let { bmp ->
                val ih = dp(38f) * scale
                bmpPaint.alpha = alpha
                c.drawBitmap(bmp, null, RectF(x - ih / 2, y - ih / 2, x + ih / 2, y + ih / 2), bmpPaint)
            }
        }
    }

    private fun chip(c: Canvas, r: RectF, corner: Float) {
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.FILL; paint.color = Color.argb(225, 14, 22, 56)
        c.drawRoundRect(r, corner, corner, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.5f); paint.color = Color.argb(170, 130, 170, 255)
        c.drawRoundRect(r, corner, corner, paint)
    }

    private fun drawChips(c: Canvas) {
        // « Assistant IA — Touchez pour ouvrir »
        val w = min(dp(236f), width * .7f); val h = dp(54f); val l = dp(14f); val t = dp(56f)
        if (leftSide) assistantRect.set(l, t, l + w, t + h) else assistantRect.set(width - l - w, t, width - l, t + h)
        chip(c, assistantRect, h / 2f)
        val ax = assistantRect.left + dp(28f); val ay = assistantRect.centerY()
        paint.reset(); paint.isAntiAlias = true
        paint.shader = LinearGradient(ax - dp(13f), ay - dp(13f), ax + dp(13f), ay + dp(13f), intArrayOf(0xFF4FD8FF.toInt(), 0xFF5B7CFF.toInt()), null, Shader.TileMode.CLAMP)
        c.drawPath(starPath(ax, ay, dp(13f)), paint)
        text.reset(); text.isAntiAlias = true; text.color = Color.WHITE; text.textSize = sp(15f); text.typeface = Typeface.DEFAULT_BOLD
        c.drawText("Assistant IA", assistantRect.left + dp(54f), assistantRect.top + h * .44f, text)
        text.typeface = Typeface.DEFAULT; text.textSize = sp(12.5f); text.color = 0xFFB9C7E8.toInt()
        c.drawText("Touchez pour ouvrir", assistantRect.left + dp(54f), assistantRect.top + h * .76f, text)

        // état / « Parlez maintenant… »
        val bw = min(dp(250f), width * .64f)
        text.reset(); text.isAntiAlias = true; text.color = Color.WHITE; text.textSize = sp(14f)
        text.typeface = if (listening) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        val layout = StaticLayout.Builder.obtain(status, 0, status.length, text, (bw - dp(28f)).toInt())
            .setMaxLines(3).setEllipsize(TextUtils.TruncateAt.END).build()
        val bh = layout.height + dp(22f)
        val bl = (fx(centerLx) - bw / 2f).coerceIn(dp(10f), max(dp(10f), width - dp(10f) - bw))
        val bt = centerY + sphereR * 1.4f + dp(10f)
        chip(c, RectF(bl, bt, bl + bw, bt + bh), dp(20f))
        c.save(); c.translate(bl + dp(14f), bt + dp(11f)); layout.draw(c); c.restore()

        // indication de défilement
        if (apps.size > 8 && height > dp(560f)) {
            val hint = "Faites glisser pour voir plus d'apps"
            text.reset(); text.isAntiAlias = true; text.textSize = sp(13f); text.color = 0xFFD5DEF5.toInt()
            val tw = text.measureText(hint); val hw = tw + dp(32f); val hl = (width - hw) / 2f; val ht = height - dp(130f)
            chip(c, RectF(hl, ht, hl + hw, ht + dp(40f)), dp(20f))
            c.drawText(hint, hl + dp(16f), ht + dp(25f), text)
        }
    }

    private fun drawEdgeCue(c: Canvas) {
        val a = (110 + 100 * sin(pulse * 2 * Math.PI)).toInt().coerceIn(0, 255)
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(2.5f); paint.strokeCap = Paint.Cap.ROUND; paint.color = Color.argb(a, 130, 220, 255)
        val p = Path().apply {
            moveTo(fx(dp(5f)), centerY - dp(14f)); lineTo(fx(dp(14f)), centerY); lineTo(fx(dp(5f)), centerY + dp(14f))
        }
        c.drawPath(p, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastY = e.y; moved = false; assistantFired = false
                fromEdge = if (leftSide) e.x < dp(44f) else e.x > width - dp(44f)
                onInteraction()
            }
            MotionEvent.ACTION_MOVE -> {
                onInteraction()
                val dx = e.x - downX; val dy = e.y - downY
                val inward = if (leftSide) dx else -dx
                if (fromEdge && !assistantFired && inward > dp(48f) && abs(dx) > abs(dy)) {
                    assistantFired = true; moved = true; onAssistant(); return true
                }
                if (!moved && (abs(dx) > touchSlop || abs(dy) > touchSlop)) moved = true
                if (moved && !assistantFired) {
                    val deltaDeg = Math.toDegrees(((e.y - lastY) / radius).toDouble()).toFloat()
                    val ms = maxScroll()
                    scroll = (scroll + deltaDeg).coerceIn(-ms, ms)
                    invalidate()
                }
                lastY = e.y
            }
            MotionEvent.ACTION_UP -> if (!moved) handleTap(e.x, e.y)
        }
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        if (assistantRect.contains(x, y)) { onAssistant(); return }
        val dxs = x - fx(centerLx); val dys = y - centerY
        if (hypot(dxs, dys) <= sphereR * 1.1f) { onMic(); return }
        for (i in apps.indices) {
            val t = angleOf(i)
            if (abs(t) > spread) continue
            if (hypot(x - tileX(t), y - tileY(t)) <= dp(32f)) { onLaunch(apps[i]); return }
        }
        if (hypot(dxs, dys) > radius + dp(40f)) onClose()
    }
}
