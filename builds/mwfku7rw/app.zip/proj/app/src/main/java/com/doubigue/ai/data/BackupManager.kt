package com.doubigue.ai.data

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.database.sqlite.SQLiteDatabase
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Sauvegarde toutes les données de l'appli (base Room, réglages, commandes apprises, sons importés)
 * dans un zip placé dans Documents/Doubigue Ai Database.
 * Le modèle vocal Vosk est optionnel (volumineux, ~40 Mo).
 *
 * Restauration : le zip est d'abord extrait dans un dossier temporaire, puis appliqué au prochain
 * démarrage de l'appli (avant l'ouverture de la base) pour ne jamais écraser une base en cours d'utilisation.
 */
object BackupManager {
    const val FOLDER = "Doubigue Ai Database"
    private const val INFO_FILE = "sauvegarde_info.txt"
    private val RESTORABLE = listOf("files", "databases", "shared_prefs")

    private fun pendingDir(context: Context) = File(context.noBackupFilesDir, "restore_pending")

    fun createBackup(context: Context, includeModel: Boolean = false): String {
        checkpointDatabases(context)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val name = "DoubigueAI_Sauvegarde_$stamp.zip"

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/$FOLDER")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
                ?: throw IllegalStateException("Impossible de créer le fichier de sauvegarde.")
            try {
                resolver.openOutputStream(uri)!!.use { writeZip(context, it, includeModel) }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            "Documents/$FOLDER/$name"
        } else {
            val dir = File(context.getExternalFilesDir(null), FOLDER).apply { mkdirs() }
            File(dir, name).outputStream().use { writeZip(context, it, includeModel) }
            "${dir.absolutePath}/$name"
        }
    }

    private fun checkpointDatabases(context: Context) {
        val dbDir = File(context.dataDir, "databases")
        dbDir.listFiles()?.filter { it.isFile && !it.name.endsWith("-wal") && !it.name.endsWith("-shm") && !it.name.endsWith("-journal") }?.forEach { f ->
            try {
                SQLiteDatabase.openDatabase(f.absolutePath, null, SQLiteDatabase.OPEN_READWRITE).use { db ->
                    db.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
                }
            } catch (_: Exception) { }
        }
    }

    private fun writeZip(context: Context, out: OutputStream, includeModel: Boolean) {
        ZipOutputStream(out.buffered()).use { zip ->
            val info = "DOUBIGUE AI — sauvegarde\nDate : ${Date()}\nPackage : ${context.packageName}\n"
            zip.putNextEntry(ZipEntry(INFO_FILE))
            zip.write(info.toByteArray())
            zip.closeEntry()

            val base = context.dataDir
            listOf("files", "databases", "shared_prefs").forEach { folder ->
                val root = File(base, folder)
                if (!root.exists()) return@forEach
                root.walkTopDown().filter { it.isFile }.forEach { file ->
                    val relative = file.relativeTo(base).invariantSeparatorsPath
                    if (!includeModel && relative.startsWith("files/vosk/")) return@forEach
                    zip.putNextEntry(ZipEntry(relative))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }

    /** Étape 1 : lit le zip choisi et le prépare dans un dossier temporaire. Retourne le nombre de fichiers. */
    fun stageRestore(context: Context, uri: Uri): Int {
        val pending = pendingDir(context)
        pending.deleteRecursively()
        pending.mkdirs()
        val canonical = pending.canonicalPath + File.separator
        var valid = false
        var count = 0
        try {
            context.contentResolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(raw.buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name.replace('\\', '/')
                        if (name == INFO_FILE) {
                            valid = true
                        } else if (!entry.isDirectory && RESTORABLE.any { name.startsWith("$it/") }) {
                            val target = File(pending, name)
                            if (!target.canonicalPath.startsWith(canonical)) throw SecurityException("Zip invalide")
                            target.parentFile?.mkdirs()
                            target.outputStream().use { out -> zip.copyTo(out) }
                            count++
                        }
                        entry = zip.nextEntry
                    }
                }
            } ?: throw IllegalArgumentException("Impossible de lire le fichier choisi.")
            if (!valid || count == 0) throw IllegalArgumentException("Ce zip n'est pas une sauvegarde DOUBIGUE AI.")
        } catch (t: Throwable) {
            pending.deleteRecursively()
            throw t
        }
        return count
    }

    fun hasPendingRestore(context: Context): Boolean = pendingDir(context).isDirectory

    /** Étape 2 : à appeler très tôt au démarrage (MainActivity.onCreate), avant toute ouverture de la base. */
    fun applyPendingRestore(context: Context): Boolean {
        val pending = pendingDir(context)
        if (!pending.isDirectory) return false
        val base = context.dataDir
        return try {
            pending.listFiles()?.filter { it.isDirectory && it.name in RESTORABLE }?.forEach { staged ->
                val live = File(base, staged.name)
                if (staged.name == "files") {
                    val keepModel = !File(staged, "vosk").exists()
                    live.listFiles()?.forEach { f ->
                        if (!(keepModel && f.name == "vosk")) f.deleteRecursively()
                    }
                } else {
                    live.deleteRecursively()
                }
                staged.copyRecursively(live, overwrite = true)
            }
            true
        } catch (_: Throwable) {
            false
        } finally {
            pending.deleteRecursively()
        }
    }

    /** Relance l'appli pour appliquer la restauration. */
    fun restartApp(context: Context) {
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK) ?: return
        context.startActivity(intent)
        Process.killProcess(Process.myPid())
    }
}
