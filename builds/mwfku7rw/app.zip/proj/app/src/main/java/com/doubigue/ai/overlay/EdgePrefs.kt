package com.doubigue.ai.overlay

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.provider.Settings
import com.doubigue.ai.apps.InstalledApp

/** Réglages du tiroir en arc (lisibles de façon synchrone par le service et le récepteur de démarrage). */
object EdgePrefs {
    private fun sp(c: Context) = c.getSharedPreferences("doubigue_edge", Context.MODE_PRIVATE)
    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("enabled", v).apply() }
    fun side(c: Context): String = sp(c).getString("side", "left") ?: "left"
    fun setSide(c: Context, v: String) { sp(c).edit().putString("side", v).apply() }
    fun favorites(c: Context): List<String> =
        (sp(c).getString("favorites", "") ?: "").split(',').filter { it.isNotBlank() }
    fun setFavorites(c: Context, list: List<String>) { sp(c).edit().putString("favorites", list.joinToString(",")).apply() }

    /** Favoris choisis, sinon sélection par défaut (YouTube, Chrome, Play Store, Appareil photo, Contacts…). */
    fun resolveShortcuts(c: Context): List<InstalledApp> {
        val pm = c.packageManager
        fun hasLaunch(pkg: String) = pkg != c.packageName && pm.getLaunchIntentForPackage(pkg) != null
        fun build(pkg: String): InstalledApp? = try {
            if (!hasLaunch(pkg)) null else {
                val ai = pm.getApplicationInfo(pkg, 0)
                InstalledApp(pm.getApplicationLabel(ai).toString(), pkg, pm.getApplicationIcon(ai))
            }
        } catch (_: Exception) { null }
        fun fromIntent(i: Intent): String? =
            pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.takeIf { it != "android" }

        val chosen = favorites(c).mapNotNull { build(it) }
        if (chosen.isNotEmpty()) return chosen

        val pkgs = LinkedHashSet<String>()
        fun first(vararg names: String?) { names.filterNotNull().firstOrNull { hasLaunch(it) }?.let { pkgs.add(it) } }
        first("com.google.android.youtube")
        first("com.android.chrome", "com.sec.android.app.sbrowser")
        first("com.android.vending")
        first(fromIntent(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)))
        first("com.google.android.contacts", "com.samsung.android.app.contacts", "com.android.contacts")
        first(fromIntent(Intent(Intent.ACTION_DIAL)))
        first("com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms")
        first("com.whatsapp")
        first(fromIntent(Intent(Settings.ACTION_SETTINGS)), "com.android.settings")
        first("com.google.android.apps.nbu.files", "com.sec.android.app.myfiles", "com.android.documentsui")
        return pkgs.mapNotNull { build(it) }
    }
}
