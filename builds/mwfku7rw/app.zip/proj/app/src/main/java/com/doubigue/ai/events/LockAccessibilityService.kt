package com.doubigue.ai.events

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * EXPÉRIMENTAL : détecte « empreinte refusée » en lisant le message affiché par l'écran de verrouillage
 * (ex. « Empreinte non reconnue »). Dépend du constructeur, de la version d'Android et de la langue.
 * Ne lit rien d'autre : seuls les événements de com.android.systemui sont traités et rien n'est enregistré.
 */
class LockAccessibilityService : AccessibilityService() {
    private var lastFire = 0L
    private val markers = listOf(
        "empreinte non reconnue", "empreinte non reconnu", "empreinte digitale non reconnue",
        "doigt non reconnu", "fingerprint not recognized", "not recognized", "non reconnue", "reessayez", "réessayez"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.packageName?.toString()?.contains("systemui") != true) return
        val text = buildString {
            e.text?.forEach { append(it).append(' ') }
            append(e.contentDescription ?: "")
        }.lowercase()
        if (text.isBlank() || markers.none { text.contains(it) }) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastFire < 2500) return   // un seul son par tentative
        lastFire = now
        EventSounds.play(this, SoundEvent.FINGERPRINT_FAIL)
    }

    override fun onInterrupt() {}
}
