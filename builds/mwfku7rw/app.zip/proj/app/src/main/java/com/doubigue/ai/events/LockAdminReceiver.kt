package com.doubigue.ai.events

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.os.UserHandle

/**
 * Reçoit les échecs / réussites de saisie du PIN, mot de passe ou schéma sur l'écran de verrouillage.
 * Android NE signale PAS les empreintes aux applications : voir EventSoundService pour la déduction.
 * Cette autorisation ne donne aucun droit d'effacer ou de verrouiller le téléphone (watch-login uniquement).
 */
class LockAdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent, user: UserHandle) {
        LockState.lastCredentialFail = SystemClock.elapsedRealtime()
        EventSounds.play(context, EventSounds.failEvent(context))
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent, user: UserHandle) {
        // L'événement USER_PRESENT suit quelques ms après ; on mémorise juste que c'était un code saisi.
        LockState.lastCredentialOk = SystemClock.elapsedRealtime()
    }
}

object LockState {
    @Volatile var lastCredentialOk = 0L
    @Volatile var lastCredentialFail = 0L
}
