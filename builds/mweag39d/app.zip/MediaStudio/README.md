# Media Studio (Kotlin / Compose / Media3)
Ouvrir le dossier dans Android Studio (Ladybug+), laisser Gradle synchroniser, lancer sur un appareil (API 26+).

- MP4→MP3, WAV→MP3 : MediaCodec (décodage) + LAME (TAndroidLame)
- Compression MP4 : Media3 Transformer, H.264 matériel, hauteur + débit réglables
- Musique+Vidéo : 2 séquences Media3, musique bouclée
- Coller : séquence Media3 (ordre modifiable)

## Ajouts
- Découpe, filtres (8), texte superposé, fondu entre clips, volumes, découpe musique, aperçu
- Icône adaptative (res/mipmap-anydpi-v26) + notifications de progression / fin d'export
