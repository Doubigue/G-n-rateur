package com.mediastudio.app.router

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.mediastudio.app.Filter
import com.mediastudio.app.TextPos
import java.security.MessageDigest

/**
 * Contrat d'Intent entre les applis clientes (LinkShare) et [com.mediastudio.app.MediaStudioRouterActivity].
 *
 * L'appelant envoie un Intent EXPLICITE (composant + action ci-dessous), les fichiers en `content://`
 * (data + ClipData) et FLAG_GRANT_READ_URI_PERMISSION. Il lance l'activité avec startActivityForResult
 * (Activity Result API) : MediaStudio peut ainsi vérifier l'appelant et lui renvoyer le résultat.
 */
object RouterContract {
    const val ACTION_TO_MP3 = "com.mediastudio.app.action.TO_MP3"
    const val ACTION_COMPRESS = "com.mediastudio.app.action.COMPRESS_VIDEO"
    const val ACTION_EFFECT = "com.mediastudio.app.action.APPLY_EFFECT"
    const val ACTION_MIX = "com.mediastudio.app.action.MIX_MUSIC"
    const val ACTION_CONCAT = "com.mediastudio.app.action.CONCAT"

    // Paramètres (tous optionnels, bornés côté MediaStudio)
    const val EXTRA_BITRATE_KBPS = "bitrate_kbps"      // Int   – MP3 (64..320, défaut 192)
    const val EXTRA_MAX_HEIGHT = "max_height"          // Int   – compression (240..2160, défaut 720)
    const val EXTRA_VIDEO_BITRATE = "video_bitrate"    // Int   – bits/s (défaut 2 000 000)
    const val EXTRA_FILTER = "filter"                  // String – nom de l'enum Filter (NOIR, WARM…)
    const val EXTRA_TEXT = "overlay_text"              // String – texte incrusté (120 car. max)
    const val EXTRA_TEXT_POS = "text_pos"              // String – TOP | MIDDLE | BOTTOM
    const val EXTRA_START_MS = "start_ms"              // Long  – découpe (début)
    const val EXTRA_END_MS = "end_ms"                  // Long  – découpe (fin)
    const val EXTRA_KEEP_AUDIO = "keep_original_audio" // Boolean – mixage
    const val EXTRA_VIDEO_VOLUME = "video_volume"      // Float 0..2
    const val EXTRA_MUSIC_VOLUME = "music_volume"      // Float 0..2
    const val EXTRA_FADE = "fade"                      // Boolean – assemblage avec fondu

    // Résultat renvoyé à l'appelant
    const val EXTRA_OUTPUT_NAME = "output_name"        // String – nom du fichier produit (RESULT_OK, data = URI MediaStore)
    const val EXTRA_ERROR = "error"                    // String – message d'erreur (RESULT_CANCELED)
}

class RouterException(message: String) : Exception(message)

/** Requête validée : plus aucune donnée brute de l'Intent n'est utilisée après [RouterParser.parse]. */
sealed interface RouterRequest {
    val label: String
    val sources: List<Uri>

    class ToMp3(val source: Uri, val bitrateKbps: Int) : RouterRequest {
        override val label = "Conversion en MP3"
        override val sources = listOf(source)
    }

    class Compress(
        val source: Uri, val maxHeight: Int, val videoBitrate: Int, val startMs: Long, val endMs: Long
    ) : RouterRequest {
        override val label = "Compression de la vidéo"
        override val sources = listOf(source)
    }

    class Effect(
        val source: Uri, val filter: Filter, val text: String, val textPos: TextPos,
        val startMs: Long, val endMs: Long
    ) : RouterRequest {
        override val label = "Application des effets"
        override val sources = listOf(source)
    }

    class Mix(
        val video: Uri, val music: Uri, val keepOriginalAudio: Boolean,
        val videoVolume: Float, val musicVolume: Float
    ) : RouterRequest {
        override val label = "Mixage musique + vidéo"
        override val sources = listOf(video, music)
    }

    class Concat(val clips: List<Uri>, val fade: Boolean) : RouterRequest {
        override val label = "Assemblage des vidéos"
        override val sources = clips
    }
}

object RouterParser {
    private const val MAX_SOURCES = 20

    fun parse(ctx: Context, intent: Intent): RouterRequest {
        val uris = collectUris(intent)
        if (uris.isEmpty()) throw RouterException("Aucun fichier reçu.")
        val types = uris.map { mimeOf(ctx, it, intent) }
        fun need(ok: Boolean, msg: String) { if (!ok) throw RouterException(msg) }
        fun isVideo(i: Int) = types[i].startsWith("video/")
        fun isAudio(i: Int) = types[i].startsWith("audio/")

        return when (intent.action) {
            RouterContract.ACTION_TO_MP3 -> {
                need(uris.size == 1, "Un seul fichier attendu.")
                need(isAudio(0) || isVideo(0), "Fichier audio ou vidéo attendu.")
                RouterRequest.ToMp3(uris[0], intent.getIntExtra(RouterContract.EXTRA_BITRATE_KBPS, 192).coerceIn(64, 320))
            }
            RouterContract.ACTION_COMPRESS -> {
                need(uris.size == 1 && isVideo(0), "Une vidéo est attendue.")
                RouterRequest.Compress(
                    uris[0],
                    intent.getIntExtra(RouterContract.EXTRA_MAX_HEIGHT, 720).coerceIn(240, 2160),
                    intent.getIntExtra(RouterContract.EXTRA_VIDEO_BITRATE, 2_000_000).coerceIn(300_000, 40_000_000),
                    intent.getLongExtra(RouterContract.EXTRA_START_MS, -1L),
                    intent.getLongExtra(RouterContract.EXTRA_END_MS, -1L),
                )
            }
            RouterContract.ACTION_EFFECT -> {
                need(uris.size == 1 && isVideo(0), "Une vidéo est attendue.")
                val filter = Filter.entries.firstOrNull { it.name == intent.getStringExtra(RouterContract.EXTRA_FILTER) } ?: Filter.NONE
                val text = intent.getStringExtra(RouterContract.EXTRA_TEXT).orEmpty().trim().take(120)
                need(filter != Filter.NONE || text.isNotEmpty(), "Aucun effet demandé.")
                val pos = TextPos.entries.firstOrNull { it.name == intent.getStringExtra(RouterContract.EXTRA_TEXT_POS) } ?: TextPos.BOTTOM
                RouterRequest.Effect(
                    uris[0], filter, text, pos,
                    intent.getLongExtra(RouterContract.EXTRA_START_MS, -1L),
                    intent.getLongExtra(RouterContract.EXTRA_END_MS, -1L),
                )
            }
            RouterContract.ACTION_MIX -> {
                need(uris.size == 2, "Une vidéo et une musique sont attendues.")
                val v = types.indices.firstOrNull(::isVideo)
                val a = types.indices.firstOrNull(::isAudio)
                need(v != null && a != null, "Une vidéo et une musique sont attendues.")
                RouterRequest.Mix(
                    uris[v!!], uris[a!!],
                    intent.getBooleanExtra(RouterContract.EXTRA_KEEP_AUDIO, true),
                    intent.getFloatExtra(RouterContract.EXTRA_VIDEO_VOLUME, 1f).coerceIn(0f, 2f),
                    intent.getFloatExtra(RouterContract.EXTRA_MUSIC_VOLUME, 0.8f).coerceIn(0f, 2f),
                )
            }
            RouterContract.ACTION_CONCAT -> {
                need(uris.size >= 2, "Au moins deux vidéos sont nécessaires.")
                need(types.indices.all(::isVideo), "Seules des vidéos peuvent être assemblées.")
                RouterRequest.Concat(uris, intent.getBooleanExtra(RouterContract.EXTRA_FADE, false))
            }
            else -> throw RouterException("Action non prise en charge.")
        }
    }

    /** data + ClipData, sans doublon, ordre conservé ; uniquement des content:// (jamais file://). */
    private fun collectUris(intent: Intent): List<Uri> {
        val out = LinkedHashSet<Uri>()
        intent.data?.let(out::add)
        intent.clipData?.let { c -> for (i in 0 until c.itemCount) c.getItemAt(i).uri?.let(out::add) }
        if (out.size > MAX_SOURCES) throw RouterException("Trop de fichiers (maximum $MAX_SOURCES).")
        if (out.any { it.scheme != ContentResolver.SCHEME_CONTENT }) throw RouterException("Source de fichier non prise en charge.")
        return out.toList()
    }

    private fun mimeOf(ctx: Context, uri: Uri, intent: Intent): String =
        (runCatching { ctx.contentResolver.getType(uri) }.getOrNull() ?: intent.type)
            ?.lowercase() ?: throw RouterException("Type de fichier inconnu.")

    fun displayName(ctx: Context, uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()

    /** Nom de base sûr : sans extension, sans séparateur de chemin ni caractère de contrôle. */
    fun baseName(ctx: Context, uri: Uri, fallback: String): String {
        val raw = displayName(ctx, uri)?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: fallback
        return raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().take(80).ifEmpty { fallback }
    }
}

/**
 * Seule l'appli LinkShare est autorisée à piloter le routeur. [callingPackage] n'est fiable que si
 * l'activité a été lancée avec startActivityForResult ; sinon la requête est refusée.
 * L'empreinte du certificat est vérifiée en plus du nom de paquet (un paquet homonyme signé autrement est rejeté).
 */
object CallerVerifier {
    private const val LINKSHARE_PACKAGE = "com.linkshare"

    /** SHA-256 (hex minuscule, sans « : ») du certificat de signature de LinkShare (app/linkshare-release.jks). */
    private val TRUSTED_CERTS = setOf("0f62329c301db9faabd184fc75d3b062051155d6eb3d48d33f347526f7a085ce")

    fun isTrusted(ctx: Context, caller: String?): Boolean {
        if (caller != LINKSHARE_PACKAGE) return false
        if (TRUSTED_CERTS.isEmpty()) return true
        return runCatching { signingCerts(ctx, caller).any { it in TRUSTED_CERTS } }.getOrDefault(false)
    }

    @Suppress("DEPRECATION")
    private fun signingCerts(ctx: Context, pkg: String): Set<String> {
        val pm = ctx.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
            when {
                info == null -> emptyArray<Signature>()
                info.hasMultipleSigners() -> info.apkContentsSigners
                else -> info.signingCertificateHistory
            }
        } else pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES).signatures ?: emptyArray<Signature>()
        return sigs.map { s ->
            MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
        }.toSet()
    }
}
