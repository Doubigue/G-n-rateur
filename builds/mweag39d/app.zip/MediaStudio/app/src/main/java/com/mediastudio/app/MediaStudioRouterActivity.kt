package com.mediastudio.app

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.util.UnstableApi
import com.mediastudio.app.router.CallerVerifier
import com.mediastudio.app.router.RouterContract
import com.mediastudio.app.router.RouterException
import com.mediastudio.app.router.RouterJobs
import com.mediastudio.app.router.RouterParser
import com.mediastudio.app.router.RouterRequest
import kotlinx.coroutines.delay

/**
 * Point d'entrée « sans interface » de MediaStudio pour les autres applis (LinkShare).
 *
 * 1. Vérifie l'appelant (paquet + signature) – lancé via startActivityForResult uniquement.
 * 2. Valide l'Intent ([RouterParser]) puis route vers la bonne classe de traitement ([RouterJobs]).
 * 3. Confie le travail à ExportManager / ExportService (service au premier plan) : le traitement survit
 *    à la rotation, à l'écran éteint et aux changements d'appli ; la fenêtre ne fait qu'observer l'état.
 * 4. Affiche une petite carte flottante sur fond translucide (thème Theme.MediaStudio.Router) avec la progression.
 * 5. À la fin, renvoie l'URI du fichier produit à l'appelant et se ferme toute seule.
 *
 * L'écran principal ([MainActivity]) n'est jamais lancé.
 */
@UnstableApi
class MediaStudioRouterActivity : ComponentActivity() {

    private var started by mutableStateOf(false)
    private var preflightError by mutableStateOf<String?>(null)
    private var sourceName = ""
    private var label = "Traitement"
    private var outputName = ""

    private sealed interface Phase {
        data class Failed(val message: String) : Phase
        data class Running(val progress: Float) : Phase
        data class Done(val uri: Uri) : Phase
        data object Cancelled : Phase
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFinishOnTouchOutside(false)
        Notifier.init(this) // canal requis par la notification du service au premier plan
        started = savedInstanceState?.getBoolean(STATE_STARTED, false) == true

        val request = preflight()
        if (request != null) {
            label = request.label
            sourceName = RouterParser.displayName(this, request.sources.first()).orEmpty()
            if (!started) start(request)
        }
        setContent { MaterialTheme { RouterContent() } }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_STARTED, started) // une recréation ne relance jamais le traitement
    }

    // ───────────────────────────── Routage ─────────────────────────────

    private fun preflight(): RouterRequest? {
        if (!CallerVerifier.isTrusted(this, callingPackage)) {
            preflightError = "Appel non autorisé."
            return null
        }
        return try {
            RouterParser.parse(this, intent)
        } catch (e: RouterException) {
            preflightError = e.message
            null
        }
    }

    private fun start(request: RouterRequest) {
        if (ExportManager.state.value.busy) {
            preflightError = "Un traitement est déjà en cours dans Media Studio."
            return
        }
        val base = RouterParser.baseName(this, request.sources.first(), fallback = "media")
        // applicationContext : le Job est conservé par le service, il ne doit pas retenir l'activité
        val job = RouterJobs.build(applicationContext, request, base)
        outputName = job.name
        ExportManager.start(applicationContext, job)
        started = true
    }

    private fun cancelExport() {
        if (ExportManager.state.value.busy)
            startService(Intent(this, ExportService::class.java).setAction(ExportService.ACTION_CANCEL))
    }

    // ───────────────────────────── Fin ─────────────────────────────

    private fun finishOk(uri: Uri) {
        setResult(
            RESULT_OK,
            Intent().setData(uri)
                .putExtra(RouterContract.EXTRA_OUTPUT_NAME, outputName)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .also { it.clipData = ClipData.newRawUri("", uri) }
        )
        finish()
    }

    private fun finishCanceled(error: String? = null) {
        setResult(RESULT_CANCELED, error?.let { Intent().putExtra(RouterContract.EXTRA_ERROR, it) })
        finish()
    }

    // ───────────────────────────── Interface ─────────────────────────────

    @Composable
    private fun RouterContent() {
        val st by ExportManager.state.collectAsState()
        val phase: Phase = when {
            preflightError != null -> Phase.Failed(preflightError!!)
            !started -> Phase.Cancelled
            st.busy -> Phase.Running(st.progress)
            st.outputUri != null -> Phase.Done(st.outputUri!!)
            st.cancelled -> Phase.Cancelled
            else -> Phase.Failed(st.error ?: "Traitement interrompu.")
        }

        when (phase) {
            is Phase.Done -> LaunchedEffect(phase.uri) { delay(600); finishOk(phase.uri) }
            Phase.Cancelled -> LaunchedEffect(Unit) { finishCanceled() }
            else -> Unit
        }
        BackHandler {
            when (phase) {
                is Phase.Running -> cancelExport()
                is Phase.Failed -> finishCanceled(phase.message)
                else -> finishCanceled()
            }
        }

        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(
                Modifier.widthIn(max = 360.dp).fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            ) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(label, style = MaterialTheme.typography.titleMedium)
                    if (sourceName.isNotEmpty())
                        Text(sourceName, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    when (phase) {
                        is Phase.Running -> {
                            if (phase.progress < 0.005f) LinearProgressIndicator(Modifier.fillMaxWidth())
                            else LinearProgressIndicator(progress = { phase.progress }, modifier = Modifier.fillMaxWidth())
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${(phase.progress * 100).toInt()} %", style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = ::cancelExport) { Text("Annuler") }
                            }
                        }
                        is Phase.Done -> Text("Terminé ✓", style = MaterialTheme.typography.bodyLarge)
                        is Phase.Failed -> {
                            Text(phase.message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                            TextButton(onClick = { finishCanceled(phase.message) }, modifier = Modifier.align(Alignment.End)) { Text("Fermer") }
                        }
                        Phase.Cancelled -> Text("Annulé", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }

    private companion object { const val STATE_STARTED = "started" }
}
