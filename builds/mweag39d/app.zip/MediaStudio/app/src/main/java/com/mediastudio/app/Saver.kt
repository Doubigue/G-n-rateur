package com.mediastudio.app

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Copie le résultat dans la galerie (Movies/MediaStudio) ou Musique (Music/MediaStudio). */
object Saver {
    fun save(ctx: Context, file: File, displayName: String, mime: String): android.net.Uri {
        val video = mime.startsWith("video")
        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                         else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val dir = (if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC) + "/MediaStudio"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, dir)
        }
        val uri = ctx.contentResolver.insert(collection, values) ?: error("Sauvegarde impossible")
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        return uri
    }
}
