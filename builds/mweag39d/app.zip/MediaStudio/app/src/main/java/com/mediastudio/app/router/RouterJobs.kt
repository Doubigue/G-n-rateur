package com.mediastudio.app.router

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import com.mediastudio.app.Clip
import com.mediastudio.app.ExportManager
import com.mediastudio.app.Mp3Converter
import com.mediastudio.app.VideoOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Routeur interne : transforme une [RouterRequest] validée en [ExportManager.Job], exécuté ensuite par
 * ExportService (premier plan + WakeLock) avec les classes existantes :
 * Mp3Converter, VideoOps (+ ClipEffects via Clip.filter / Clip.text) et Saver (via ExportService).
 */
@UnstableApi
internal object RouterJobs {

    fun build(app: Context, req: RouterRequest, base: String): ExportManager.Job {
        val stamp = System.currentTimeMillis()
        return when (req) {
            is RouterRequest.ToMp3 -> ExportManager.Job("${base}_$stamp.mp3", "audio/mpeg") { out, report ->
                Mp3Converter.convert(app, req.source, out, req.bitrateKbps, report)
            }

            is RouterRequest.Compress -> ExportManager.Job("${base}_${req.maxHeight}p_$stamp.mp4", "video/mp4") { out, report ->
                val clip = clipOf(app, req.source, req.startMs, req.endMs)
                VideoOps.compress(app, clip, out, req.maxHeight, req.videoBitrate, report)
            }

            is RouterRequest.Effect -> {
                val tag = if (req.filter.name != "NONE") req.filter.name.lowercase() else "texte"
                ExportManager.Job("${base}_${tag}_$stamp.mp4", "video/mp4") { out, report ->
                    // ClipEffects.videoEffects() lit filter / text / textPos du Clip
                    val clip = clipOf(app, req.source, req.startMs, req.endMs)
                        .copy(filter = req.filter, text = req.text, textPos = req.textPos)
                    VideoOps.applyEffects(app, clip, out, maxHeight = null, onProgress = report)
                }
            }

            is RouterRequest.Mix -> ExportManager.Job("${base}_mix_$stamp.mp4", "video/mp4") { out, report ->
                val video = clipOf(app, req.video)
                val music = clipOf(app, req.music)
                VideoOps.mixMusic(app, video, music, out, req.keepOriginalAudio, req.videoVolume, req.musicVolume, report)
            }

            is RouterRequest.Concat -> ExportManager.Job("montage_$stamp.mp4", "video/mp4") { out, report ->
                val clips = req.clips.map { clipOf(app, it) }
                VideoOps.concat(app, clips, out, req.fade, onProgress = report)
            }
        }
    }

    /** Lecture des métadonnées hors du thread principal (le bloc du Job s'exécute sur Main dans le service). */
    private suspend fun clipOf(ctx: Context, uri: Uri, startMs: Long = -1, endMs: Long = -1): Clip {
        val c = withContext(Dispatchers.IO) { Clip.from(ctx, uri) }
        if (c.durationMs <= 0) error("Durée du média illisible")
        if (startMs < 0 && endMs < 0) return c
        val s = startMs.coerceIn(0, c.durationMs - 1)
        val e = (if (endMs > 0) endMs else c.durationMs).coerceIn(s + 1, c.durationMs)
        return c.copy(startMs = s, endMs = e)
    }
}
