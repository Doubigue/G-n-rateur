package com.mediastudio.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** Aperçu avant export (découpe, musique, volumes, filtre et texte du clip [fxClip]). */
@UnstableApi
@Composable
fun Preview(
    clips: List<Clip>, music: Clip? = null,
    musicVolume: Float = 1f, videoVolume: Float = 1f,
    fxClip: Clip? = clips.firstOrNull()
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val video = remember { ExoPlayer.Builder(ctx).build() }
    val audio = remember { ExoPlayer.Builder(ctx).build().apply { repeatMode = Player.REPEAT_MODE_ALL } }

    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { audio.playWhenReady = isPlaying }
            override fun onPositionDiscontinuity(o: Player.PositionInfo, n: Player.PositionInfo, r: Int) {
                audio.seekTo(video.currentPosition)
            }
        }
        video.addListener(l)
        onDispose { video.removeListener(l); video.release(); audio.release() }
    }
    LaunchedEffect(clips) { video.setMediaItems(clips.map { it.toMediaItem() }); video.prepare() }
    LaunchedEffect(music) {
        if (music != null) { audio.setMediaItem(music.toMediaItem()); audio.prepare() } else audio.clearMediaItems()
    }
    LaunchedEffect(fxClip?.filter, fxClip?.text, fxClip?.textPos) {
        video.setVideoEffects(fxClip?.let { videoEffects(it) } ?: emptyList())
    }
    LaunchedEffect(musicVolume) { audio.volume = musicVolume.coerceAtMost(1f) }
    LaunchedEffect(videoVolume) { video.volume = videoVolume.coerceAtMost(1f) }

    if (clips.isEmpty()) return
    Column {
        Text("Aperçu", style = MaterialTheme.typography.titleSmall)
        AndroidView(
            modifier = Modifier.fillMaxWidth().height(220.dp),
            factory = { PlayerView(it).apply { player = video } })
    }
}

/** Découpe : curseur double début/fin. */
@Composable
fun TrimEditor(clip: Clip, label: String = "Découpe", onChange: (Clip) -> Unit) {
    if (clip.durationMs <= 0) return
    Column {
        Text("$label : ${fmtTime(clip.startMs)} → ${fmtTime(clip.endMs)} (${fmtTime(clip.lengthMs)})")
        RangeSlider(
            value = clip.startMs.toFloat()..clip.endMs.toFloat(),
            onValueChange = {
                val s = it.start.toLong(); val e = it.endInclusive.toLong()
                if (e - s >= 500) onChange(clip.copy(startMs = s, endMs = e))
            },
            valueRange = 0f..clip.durationMs.toFloat())
    }
}

/** Filtre + texte superposé. */
@Composable
fun EffectsPanel(clip: Clip, onChange: (Clip) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Filtre")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Filter.entries.forEach {
                FilterChip(clip.filter == it, { onChange(clip.copy(filter = it)) }, label = { Text(it.label) })
            }
        }
        OutlinedTextField(
            value = clip.text, onValueChange = { onChange(clip.copy(text = it)) },
            label = { Text("Texte sur la vidéo") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        if (clip.text.isNotBlank()) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TextPos.entries.forEach {
                FilterChip(clip.textPos == it, { onChange(clip.copy(textPos = it)) }, label = { Text(it.label) })
            }
        }
    }
}
