package com.mediastudio.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.media3.common.MediaItem

enum class Filter(val label: String) {
    NONE("Aucun"), NOIR("Noir & blanc"), WARM("Chaud"), COOL("Froid"),
    VIVID("Vif"), CONTRAST("Contraste"), BRIGHT("Lumineux"), INVERT("Inversé")
}

enum class TextPos(val label: String, val y: Float) {
    TOP("Haut", 0.8f), MIDDLE("Milieu", 0f), BOTTOM("Bas", -0.8f)
}

/** Une source (vidéo ou musique) avec découpe, filtre et texte. */
data class Clip(
    val uri: Uri, val durationMs: Long,
    val startMs: Long = 0, val endMs: Long = durationMs,
    val filter: Filter = Filter.NONE,
    val text: String = "", val textPos: TextPos = TextPos.BOTTOM
) {
    val lengthMs get() = endMs - startMs

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setUri(uri)
        .setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs).setEndPositionMs(endMs).build())
        .build()

    companion object {
        fun from(ctx: Context, uri: Uri): Clip {
            val r = MediaMetadataRetriever()
            return try {
                r.setDataSource(ctx, uri)
                Clip(uri, r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L)
            } finally { r.release() }
        }
    }
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d.%d".format(s / 60, s % 60, (ms % 1000) / 100)
}
