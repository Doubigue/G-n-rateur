package com.mediastudio.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/** Pont entre l'interface et le service : file d'attente d'un export + état observable. */
object ExportManager {
    data class State(
        val busy: Boolean = false, val progress: Float = 0f, val status: String = "",
        /** Renseigné à la fin d'un export réussi (URI MediaStore du fichier produit). */
        val outputUri: Uri? = null,
        /** Renseigné si l'export a échoué ou a été interrompu. */
        val error: String? = null,
        val cancelled: Boolean = false
    )

    class Job(
        val name: String, val mime: String,
        val block: suspend (File, (Float) -> Unit) -> Unit
    )

    val state = MutableStateFlow(State())
    @Volatile var pending: Job? = null

    fun start(ctx: Context, job: Job) {
        if (state.value.busy) return
        pending = job
        state.value = State(busy = true, status = "En cours…")
        ContextCompat.startForegroundService(ctx, Intent(ctx, ExportService::class.java))
    }
}
