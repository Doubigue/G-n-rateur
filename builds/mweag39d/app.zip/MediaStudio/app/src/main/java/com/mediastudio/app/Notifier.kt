package com.mediastudio.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.Uri

/** Notification persistante (service) avec progression + bouton Annuler, puis notification de fin. */
object Notifier {
    const val ID_PROGRESS = 1
    private const val CH_PROGRESS = "export_progress"
    private const val CH_DONE = "export_done"
    private fun nm(c: Context) = c.getSystemService(NotificationManager::class.java)

    fun init(c: Context) {
        nm(c).createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Export en cours", NotificationManager.IMPORTANCE_LOW))
        nm(c).createNotificationChannel(
            NotificationChannel(CH_DONE, "Export terminé", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun progressNotification(c: Context, title: String, pct: Int): Notification {
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val cancel = PendingIntent.getService(c, 1,
            Intent(c, ExportService::class.java).setAction(ExportService.ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(c, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Export en cours")
            .setContentText("$title – $pct %")
            .setProgress(100, pct, pct == 0)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(c, R.drawable.ic_notif), "Annuler", cancel).build())
            .setOngoing(true).setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    fun progress(c: Context, title: String, pct: Int) =
        nm(c).notify(ID_PROGRESS, progressNotification(c, title, pct))

    fun done(c: Context, title: String, uri: Uri, mime: String) {
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val pi = PendingIntent.getActivity(c, 2, view,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm(c).notify(System.currentTimeMillis().toInt(), Notification.Builder(c, CH_DONE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Export terminé")
            .setContentText("$title – touchez pour ouvrir")
            .setContentIntent(pi).setAutoCancel(true).build())
    }

    fun fail(c: Context, msg: String) {
        nm(c).notify(System.currentTimeMillis().toInt(), Notification.Builder(c, CH_DONE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Échec de l'export").setContentText(msg).setAutoCancel(true).build())
    }
}
