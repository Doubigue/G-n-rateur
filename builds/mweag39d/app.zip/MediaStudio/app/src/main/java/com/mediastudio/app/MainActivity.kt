package com.mediastudio.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.launch
import java.io.File

@UnstableApi
class MainActivity : ComponentActivity() {
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.init(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED)
            notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { App() } }
    }
}

private enum class Tool(val label: String) {
    MP4_MP3("MP4→MP3"), WAV_MP3("WAV→MP3"), COMPRESS("Compresser"),
    MIX("Musique+Vidéo"), CONCAT("Coller")
}

@UnstableApi
@Composable
private fun App() {
    var tool by remember { mutableStateOf(Tool.MP4_MP3) }
    Scaffold { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Media Studio", style = MaterialTheme.typography.headlineSmall)
            ScrollableTabRow(selectedTabIndex = tool.ordinal, edgePadding = 0.dp) {
                Tool.entries.forEach { Tab(tool == it, { tool = it }, text = { Text(it.label) }) }
            }
            key(tool) {
                when (tool) {
                    Tool.MP4_MP3 -> ToMp3("video/*")
                    Tool.WAV_MP3 -> ToMp3("audio/*")
                    Tool.COMPRESS -> Compress()
                    Tool.MIX -> Mix()
                    Tool.CONCAT -> Concat()
                }
            }
        }
    }
}

/** Lance l'export dans le service au premier plan ; l'état vient d'ExportManager. */
@Composable
private fun rememberRunner(): Runner {
    val ctx = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val st = ExportManager.state.collectAsState()
    return remember { Runner(ctx, st) }
}

private class Runner(val ctx: Context, private val st: State<ExportManager.State>) {
    val busy get() = st.value.busy
    val progress get() = st.value.progress
    val status get() = st.value.status

    fun run(name: String, mime: String, job: suspend (File, (Float) -> Unit) -> Unit) =
        ExportManager.start(ctx, ExportManager.Job(name, mime, job))
}

@Composable
private fun Status(r: Runner) {
    if (r.busy) {
        LinearProgressIndicator(progress = { r.progress }, modifier = Modifier.fillMaxWidth())
        TextButton({
            r.ctx.startService(android.content.Intent(r.ctx, ExportService::class.java)
                .setAction(ExportService.ACTION_CANCEL))
        }) { Text("Annuler") }
        Text("L'export continue même écran éteint ou app en arrière-plan.")
    }
    if (r.status.isNotEmpty()) Text(r.status)
}

private fun stamp() = System.currentTimeMillis().toString()

@Composable
private fun ToMp3(mimeFilter: String) {
    val r = rememberRunner()
    var bitrate by remember { mutableFloatStateOf(192f) }
    var src by remember { mutableStateOf<Uri?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { src = it }
    Button({ pick.launch(mimeFilter) }) { Text(if (src == null) "Choisir un fichier" else "Fichier choisi ✓") }
    Text("Débit : ${bitrate.toInt()} kbps")
    Slider(bitrate, { bitrate = it }, valueRange = 96f..320f, steps = 6)
    Button(enabled = src != null && !r.busy, onClick = {
        val u = src!!; val br = bitrate.toInt()
        r.run("audio_${stamp()}.mp3", "audio/mpeg") { f, rep ->
            Mp3Converter.convert(r.ctx, u, f, br) { rep(it) }
        }
    }) { Text("Convertir en MP3") }
    Status(r)
}

@UnstableApi
@Composable
private fun Compress() {
    val r = rememberRunner()
    var clip by remember { mutableStateOf<Clip?>(null) }
    var height by remember { mutableIntStateOf(720) }
    var mbps by remember { mutableFloatStateOf(2f) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        u?.let { clip = Clip.from(r.ctx, it) }
    }
    Button({ pick.launch("video/*") }) { Text(if (clip == null) "Choisir une vidéo" else "Changer de vidéo") }
    clip?.let { c ->
        Preview(listOf(c))
        TrimEditor(c) { clip = it }
        EffectsPanel(c) { clip = it }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(480, 720, 1080).forEach {
            FilterChip(height == it, { height = it }, label = { Text("${it}p") })
        }
    }
    Text("Débit vidéo : %.1f Mbps".format(mbps))
    Slider(mbps, { mbps = it }, valueRange = 0.5f..8f)
    Button(enabled = clip != null && !r.busy, onClick = {
        val c = clip!!; val h = height; val br = (mbps * 1_000_000).toInt()
        r.run("compressed_${stamp()}.mp4", "video/mp4") { f, rep ->
            VideoOps.compress(r.ctx, c, f, h, br) { rep(it) }
        }
    }) { Text("Compresser") }
    Status(r)
}

@UnstableApi
@Composable
private fun Mix() {
    val r = rememberRunner()
    var clip by remember { mutableStateOf<Clip?>(null) }
    var music by remember { mutableStateOf<Clip?>(null) }
    var keep by remember { mutableStateOf(true) }
    var vVol by remember { mutableFloatStateOf(1f) }
    var mVol by remember { mutableFloatStateOf(0.8f) }
    val pv = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        u?.let { clip = Clip.from(r.ctx, it) }
    }
    val pm = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        u?.let { music = Clip.from(r.ctx, it) }
    }
    Button({ pv.launch("video/*") }) { Text(if (clip == null) "Choisir la vidéo" else "Vidéo ✓") }
    Button({ pm.launch("audio/*") }) { Text(if (music == null) "Choisir la musique" else "Musique ✓") }
    clip?.let { c ->
        Preview(listOf(c), music, mVol, if (keep) vVol else 0f)
        TrimEditor(c, "Découpe vidéo") { clip = it }
        EffectsPanel(c) { clip = it }
    }
    music?.let { m -> TrimEditor(m, "Découpe musique") { music = it } }
    Row { Switch(keep, { keep = it }); Spacer(Modifier.width(8.dp)); Text("Garder le son d'origine") }
    if (keep) {
        Text("Volume vidéo : ${(vVol * 100).toInt()} %")
        Slider(vVol, { vVol = it }, valueRange = 0f..2f)
    }
    Text("Volume musique : ${(mVol * 100).toInt()} %")
    Slider(mVol, { mVol = it }, valueRange = 0f..2f)
    Button(enabled = clip != null && music != null && !r.busy, onClick = {
        val c = clip!!; val m = music!!; val k = keep; val vv = vVol; val mv = mVol
        r.run("mix_${stamp()}.mp4", "video/mp4") { f, rep ->
            VideoOps.mixMusic(r.ctx, c, m, f, k, vv, mv) { rep(it) }
        }
    }) { Text("Mixer") }
    Status(r)
}

@UnstableApi
@Composable
private fun Concat() {
    val r = rememberRunner()
    var clips by remember { mutableStateOf(listOf<Clip>()) }
    var selected by remember { mutableIntStateOf(0) }
    var fade by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { list ->
        clips = clips + list.map { Clip.from(r.ctx, it) }
    }
    Button({ pick.launch("video/*") }) { Text("Ajouter des vidéos") }
    Preview(clips, fxClip = clips.getOrNull(selected))
    clips.forEachIndexed { i, c ->
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton({ selected = i }, Modifier.weight(1f)) {
                Text("${if (i == selected) "▶ " else ""}${i + 1}. ${fmtTime(c.lengthMs)}")
            }
            TextButton({ if (i > 0) clips = clips.toMutableList().also { l -> l.add(i - 1, l.removeAt(i)) } }) { Text("↑") }
            TextButton({ clips = clips.filterIndexed { k, _ -> k != i }; selected = 0 }) { Text("✕") }
        }
    }
    clips.getOrNull(selected)?.let { c ->
        TrimEditor(c) { n -> clips = clips.toMutableList().also { it[selected] = n } }
        EffectsPanel(c) { n -> clips = clips.toMutableList().also { it[selected] = n } }
    }
    Row { Switch(fade, { fade = it }); Spacer(Modifier.width(8.dp)); Text("Transition : fondu entre les clips") }
    Button(enabled = clips.size >= 2 && !r.busy, onClick = {
        val list = clips; val fd = fade
        r.run("montage_${stamp()}.mp4", "video/mp4") { f, rep ->
            VideoOps.concat(r.ctx, list, f, fd) { rep(it) }
        }
    }) { Text("Assembler") }
    Status(r)
}
