package com.mediastudio.app

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.*
import java.io.File

/**
 * Service au premier plan : l'export continue app en arrière-plan et écran éteint.
 * Un WakeLock partiel garde le processeur actif ; le service s'arrête tout seul à la fin.
 */
class ExportService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { job?.cancel(); return START_NOT_STICKY }

        val p = ExportManager.pending
        if (p == null) { stopSelf(); return START_NOT_STICKY }
        ExportManager.pending = null

        val n = Notifier.progressNotification(this, p.name, 0)
        when {
            Build.VERSION.SDK_INT >= 35 -> startForeground(Notifier.ID_PROGRESS, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
            Build.VERSION.SDK_INT >= 29 -> startForeground(Notifier.ID_PROGRESS, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else -> startForeground(Notifier.ID_PROGRESS, n)
        }

        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mediastudio:export")
            .apply { acquire(2 * 60 * 60 * 1000L) } // sécurité : 2 h max

        job = scope.launch {
            var lastPct = -1
            try {
                val tmp = File(cacheDir, p.name)
                p.block(tmp) { pr ->
                    val pct = (pr * 100).toInt()
                    ExportManager.state.value = ExportManager.State(true, pr, "En cours…")
                    if (pct != lastPct) { lastPct = pct; Notifier.progress(this@ExportService, p.name, pct) }
                }
                val uri = Saver.save(this@ExportService, tmp, p.name, p.mime)
                ExportManager.state.value = ExportManager.State(
                    false, 1f, "Terminé : ${p.name} (taille ${tmp.length() / 1024} Ko)", outputUri = uri)
                Notifier.done(this@ExportService, p.name, uri, p.mime)
            } catch (e: CancellationException) {
                ExportManager.state.value = ExportManager.State(false, 0f, "Export annulé", cancelled = true)
            } catch (e: Exception) {
                ExportManager.state.value = ExportManager.State(false, 0f, "Erreur : ${e.message}", error = e.message ?: "erreur")
                Notifier.fail(this@ExportService, e.message ?: "erreur")
            } finally {
                wake?.takeIf { it.isHeld }?.release()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        wake?.takeIf { it.isHeld }?.release()
        if (ExportManager.state.value.busy)
            ExportManager.state.value = ExportManager.State(false, 0f, "Export interrompu", error = "Export interrompu")
        super.onDestroy()
    }

    companion object { const val ACTION_CANCEL = "com.mediastudio.app.CANCEL" }
}
