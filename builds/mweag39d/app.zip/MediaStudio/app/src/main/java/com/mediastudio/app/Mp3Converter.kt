package com.mediastudio.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteOrder

/** MP4 -> MP3 et WAV -> MP3 : décodage PCM (MediaCodec) puis encodage LAME. */
object Mp3Converter {

    suspend fun convert(
        ctx: Context, input: Uri, output: File, bitrateKbps: Int = 192,
        onProgress: (Float) -> Unit = {}
    ) = withContext(Dispatchers.IO) {
        val ex = MediaExtractor().apply { setDataSource(ctx, input, null) }
        val track = (0 until ex.trackCount).firstOrNull {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")
        } ?: error("Aucune piste audio")
        ex.selectTrack(track)
        val inFmt = ex.getTrackFormat(track)
        val durationUs = if (inFmt.containsKey(MediaFormat.KEY_DURATION))
            inFmt.getLong(MediaFormat.KEY_DURATION) else 1L

        val codec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(inFmt, null, null, 0); codec.start()

        var lame: AndroidLame? = null
        var channels = 2
        val info = MediaCodec.BufferInfo()
        var inputDone = false; var outputDone = false
        val mp3Buf = ByteArray(1024 * 64)

        output.outputStream().buffered().use { out ->
            while (!outputDone) {
                if (!inputDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        val rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        lame = LameBuilder()
                            .setInSampleRate(rate).setOutSampleRate(rate)
                            .setOutChannels(channels).setOutBitrate(bitrateKbps)
                            .setQuality(2).build()
                    }
                    o >= 0 -> {
                        val shorts = codec.getOutputBuffer(o)!!
                            .order(ByteOrder.nativeOrder()).asShortBuffer()
                        val total = shorts.remaining()
                        val pcm = ShortArray(total); shorts.get(pcm)
                        val frames = total / channels
                        if (frames > 0 && lame != null) {
                            val l = ShortArray(frames); val r = ShortArray(frames)
                            for (k in 0 until frames) {
                                l[k] = pcm[k * channels]
                                r[k] = if (channels > 1) pcm[k * channels + 1] else l[k]
                            }
                            val w = if (channels == 1) lame!!.encode(l, l, frames, mp3Buf)
                                    else lame!!.encode(l, r, frames, mp3Buf)
                            if (w > 0) out.write(mp3Buf, 0, w)
                        }
                        onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 1f))
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(o, false)
                    }
                }
            }
            lame?.let { val w = it.flush(mp3Buf); if (w > 0) out.write(mp3Buf, 0, w); it.close() }
        }
        codec.stop(); codec.release(); ex.release()
    }
}
