package com.example.mydm.core

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Mise à jour « Over The Air » de MyDM lui-même.
 *
 * L'adresse (Paramètres) pointe vers :
 *  • un fichier JSON  { "versionCode": 11, "versionName": "2.8.0", "apkUrl": "https://…/MyDM.apk", "notes": "…", "sha256": "…" }
 *  • ou un dépôt GitHub : https://github.com/<compte>/<depot> (releases du générateur d'APK : « Version : X (code) », « Paquet : … »)
 *
 * Le nouvel APK doit être signé avec la MÊME clé que l'appli installée, sinon Android refuse la mise à jour.
 */
object Updater {
    data class Info(val versionCode: Long, val versionName: String, val apkUrl: String, val notes: String, val sha256: String?)

    sealed class Result {
        object UpToDate : Result()
        class Available(val info: Info) : Result()
        class Error(val msg: String) : Result()
    }

    /** Mise à jour trouvée : l'écran principal affiche la fenêtre « Mettre à jour ». */
    var pending by mutableStateOf<Info?>(null)
    /** Progression du téléchargement (0‒100), -1 = taille inconnue. */
    var progress by mutableIntStateOf(0)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).followRedirects(true).build()

    fun currentName(ctx: Context): String = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
    private fun currentCode(ctx: Context): Long = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode }.getOrDefault(0L)

    private fun nums(v: String) = Regex("\\d+").findAll(v).map { it.value.toIntOrNull() ?: 0 }.toList()
    private fun compare(a: String, b: String): Int {
        val x = nums(a); val y = nums(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = (x.getOrElse(i) { 0 }).compareTo(y.getOrElse(i) { 0 })
            if (d != 0) return d
        }
        return 0
    }

    /** Dépôt GitHub (« https://github.com/compte/depot » ou l'API) → liste des releases ; sinon fichier JSON. */
    private fun githubListUrl(url: String): String? {
        val m = Regex("^https?://(?:api\\.)?github\\.com/(?:repos/)?([^/?#]+)/([^/?#]+)", RegexOption.IGNORE_CASE).find(url.trim()) ?: return null
        return "https://api.github.com/repos/${m.groupValues[1]}/${m.groupValues[2].removeSuffix(".git")}/releases?per_page=40"
    }

    /**
     * Release GitHub → Info. Les releases du générateur d'APK portent « Version : 2.8.0 (11) » et « Paquet : com.example.mydm » :
     * on ignore celles d'un autre paquet (un même dépôt peut contenir plusieurs applis).
     */
    private fun fromRelease(j: JSONObject, pkg: String): Info? {
        if (j.optBoolean("draft")) return null
        val body = j.optString("body")
        val rp = Regex("Paquet\\s*:\\s*(\\S+)").find(body)?.groupValues?.get(1)
        if (rp != null && rp != pkg) return null
        val assets = j.optJSONArray("assets") ?: return null
        var apk = ""; var sha: String? = null
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk", true)) {
                apk = a.optString("browser_download_url")
                sha = a.optString("digest").removePrefix("sha256:").takeIf { it.length == 64 }
                break
            }
        }
        if (apk.isEmpty()) return null
        val v = Regex("Version\\s*:\\s*([^\\s(]+)\\s*\\((\\d+)\\)").find(body)
        val name = v?.groupValues?.get(1) ?: j.optString("tag_name").trimStart('v', 'V')
        val code = v?.groupValues?.get(2)?.toLongOrNull() ?: 0L
        val notes = if (body.contains("Config :")) "" else body
        return Info(code, name, apk, notes, sha)
    }

    /** Interroge le serveur. [force] = ignore la version « ignorée ». */
    suspend fun check(ctx: Context, force: Boolean = false): Result = withContext(Dispatchers.IO) {
        val url = Prefs.updateUrl.trim()
        if (url.isEmpty()) return@withContext Result.Error("Indiquez d'abord l'adresse de mise à jour (Paramètres)")
        if (!url.startsWith("http", true)) return@withContext Result.Error("Adresse invalide (http:// ou https://)")
        try {
            val target = githubListUrl(url) ?: url
            val body = http.newCall(Request.Builder().url(target).header("Accept", "application/json").header("User-Agent", AutoDownload.UA).build())
                .execute().use { r ->
                    if (r.code == 404) return@withContext Result.Error("Introuvable (404) : le dépôt doit être public")
                    if (!r.isSuccessful) return@withContext Result.Error("Serveur de mise à jour : erreur ${r.code}")
                    r.body?.string().orEmpty()
                }
            Prefs.markUpdateChecked()
            val pkg = ctx.packageName
            val txt = body.trim()
            val info: Info? = if (txt.startsWith("[")) {
                val arr = org.json.JSONArray(txt)
                (0 until arr.length()).mapNotNull { fromRelease(arr.getJSONObject(it), pkg) }
                    .maxWithOrNull(compareBy<Info>({ it.versionCode }).thenComparator { x, y -> compare(x.versionName, y.versionName) })
            } else {
                val j = JSONObject(txt)
                if (j.has("tag_name")) fromRelease(j, pkg)
                else {
                    val apk = j.optString("apkUrl")
                    if (apk.isEmpty()) return@withContext Result.Error("Fichier de mise à jour invalide (apkUrl manquant)")
                    Info(j.optLong("versionCode", 0L), j.optString("versionName", "?"), apk, j.optString("notes"),
                        j.optString("sha256").takeIf { it.isNotBlank() })
                }
            }
            if (info == null) return@withContext Result.Error("Aucun APK de MyDM trouvé dans ce dépôt")
            val newer = if (info.versionCode > 0L) info.versionCode > currentCode(ctx) else compare(info.versionName, currentName(ctx)) > 0
            when {
                !newer -> Result.UpToDate
                !force && Prefs.skippedUpdate == info.versionName -> Result.UpToDate
                else -> Result.Available(info)
            }
        } catch (e: Exception) {
            Result.Error("Recherche impossible : " + (e.message ?: e::class.java.simpleName).take(100))
        }
    }

    /** Vérification discrète au démarrage (au plus toutes les 6 h) : affiche la fenêtre si une version est disponible. */
    suspend fun autoCheck(ctx: Context) {
        if (!Prefs.autoUpdateCheck || Prefs.updateUrl.isBlank()) return
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck() < 6 * 3600_000L) return
        (check(ctx) as? Result.Available)?.let { pending = it.info }
    }

    /** Télécharge l'APK dans le cache et vérifie l'empreinte SHA-256 si elle est fournie. */
    suspend fun download(ctx: Context, info: Info): File = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val out = File(dir, "MyDM-${info.versionName}.apk")
        progress = 0
        http.newBuilder().readTimeout(60, TimeUnit.SECONDS).build()
            .newCall(Request.Builder().url(info.apkUrl).header("User-Agent", AutoDownload.UA).build()).execute().use { r ->
                if (!r.isSuccessful) error("Téléchargement refusé (${r.code})")
                val body = r.body ?: error("Réponse vide")
                val total = body.contentLength()
                val md = MessageDigest.getInstance("SHA-256")
                var done = 0L
                body.byteStream().use { inp -> out.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = inp.read(buf); if (n < 0) break
                        o.write(buf, 0, n); md.update(buf, 0, n); done += n
                        progress = if (total > 0) (done * 100 / total).toInt() else -1
                    }
                } }
                info.sha256?.let { want ->
                    val got = md.digest().joinToString("") { "%02x".format(it) }
                    if (!got.equals(want.trim(), true)) { out.delete(); error("Fichier corrompu (empreinte SHA-256 différente)") }
                }
            }
        if (out.length() < 100_000) { out.delete(); error("Fichier APK invalide") }
        out
    }

    /** Installe l'APK via PackageInstaller. false = autorisation « sources inconnues » à accorder d'abord. */
    fun install(ctx: Context, apk: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(ctx, "Autorisez MyDM à installer des applications, puis réessayez", Toast.LENGTH_LONG).show()
            runCatching {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return false
        }
        val pi = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setAppPackageName(ctx.packageName); setSize(apk.length())
            if (Build.VERSION.SDK_INT >= 31) setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        val id = pi.createSession(params)
        pi.openSession(id).use { s ->
            apk.inputStream().use { inp -> s.openWrite("mydm-update", 0, apk.length()).use { o -> inp.copyTo(o); s.fsync(o) } }
            val intent = Intent(ctx, UpdateInstallReceiver::class.java).setAction("com.example.mydm.UPDATE_RESULT")
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(ctx, id, intent, flags).intentSender)
        }
        return true
    }
}
