package com.example.mydm.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.widget.Toast

/** Résultat de l'installation de la mise à jour : confirmation Android, ou message d'erreur. */
class UpdateInstallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        when (val status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION") val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                confirm?.let { runCatching { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            }
            PackageInstaller.STATUS_SUCCESS -> Unit      // Android relance MyDM avec la nouvelle version
            else -> {
                val m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE).orEmpty()
                val hint = if (status == PackageInstaller.STATUS_FAILURE_CONFLICT || m.contains("signature", true) || m.contains("INCOMPATIBLE", true))
                    " (l'APK doit être signé avec la même clé que l'appli installée)" else ""
                Toast.makeText(ctx, "Mise à jour non installée : " + m.take(120) + hint, Toast.LENGTH_LONG).show()
            }
        }
    }
}
