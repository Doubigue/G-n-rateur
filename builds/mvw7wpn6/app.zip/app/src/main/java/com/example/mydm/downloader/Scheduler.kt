package com.example.mydm.downloader

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

/**
 * Alarme système (AlarmManager) qui lance un téléchargement programmé à l'heure choisie.
 * Une alarme par tâche : l'Intent porte l'identifiant dans son adresse (mydm-schedule://<id>), donc elles ne se confondent pas.
 * Les alarmes disparaissent au redémarrage du téléphone : [ScheduleReceiver] les remet (via DownloadEngine.rearmSchedules).
 */
object Scheduler {
    const val ACTION_FIRE = "com.example.mydm.SCHEDULE_FIRE"
    const val EXTRA_ID = "id"

    private fun intent(ctx: Context, id: String) = Intent(ctx, ScheduleReceiver::class.java)
        .setAction(ACTION_FIRE).setData(Uri.parse("mydm-schedule://$id")).putExtra(EXTRA_ID, id)

    /** Programme (ou remplace) l'alarme de la tâche [id] à l'heure [at] (ms). Heure exacte si autorisée, sinon « à peu près ». */
    fun arm(ctx: Context, id: String, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(ctx, 0, intent(ctx, id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun disarm(ctx: Context, id: String) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(ctx, 0, intent(ctx, id), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        am.cancel(pi); pi.cancel()
    }
}
