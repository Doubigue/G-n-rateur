package com.example.mydm.downloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.mydm.App
import com.example.mydm.MainActivity
import com.example.mydm.core.Status
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * • ACTION_FIRE : l'heure programmée est arrivée → on démarre le téléchargement.
 * • Redémarrage du téléphone / mise à jour de l'appli : les alarmes sont perdues → on les remet.
 */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val app = ctx.applicationContext as App
        when (intent.action) {
            Scheduler.ACTION_FIRE -> {
                val id = intent.getStringExtra(Scheduler.EXTRA_ID) ?: return
                val pending = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val task = app.db.downloadDao().task(id)
                        // Alarme périmée (tâche supprimée, déjà lancée à la main…) : on ignore
                        if (task != null && task.status == Status.SCHEDULED) {
                            try {
                                DownloadService.start(ctx, id)
                            } catch (e: Exception) {
                                // Android refuse de lancer le service en arrière-plan : on met en pause + on prévient l'utilisateur
                                app.downloadEngine.unschedule(id)
                                notifyReady(ctx, task.fileName)
                            }
                        }
                    } finally { pending.finish() }
                }
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                val pending = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try { app.downloadEngine.rearmSchedules() } finally { pending.finish() }
                }
            }
        }
    }

    private fun notifyReady(ctx: Context, name: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("scheduled", "Téléchargements programmés", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(name.hashCode(), NotificationCompat.Builder(ctx, "scheduled").setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Téléchargement programmé prêt").setContentText("$name — touchez pour ouvrir MyDM puis « Reprendre »")
            .setContentIntent(pi).setAutoCancel(true).build())
    }
}
