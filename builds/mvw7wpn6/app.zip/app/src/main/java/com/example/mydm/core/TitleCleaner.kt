package com.example.mydm.core

import android.net.Uri

/**
 * Extrait le NOM du film / de la série d'un titre de page de site de streaming
 * (« Regarder Mon Film (2023) en streaming VF complet HD - Cinezzz : Synopsis… » → « Mon Film (2023) »).
 */
object TitleCleaner {
    private val sepRe = Regex("""\s+[|–—»«•·]\s+|\s+-\s+|\s*\|\s*""")
    private val siteRe = Regex("""(?i)\b[\w-]+\.(com|net|org|club|co|cc|to|tv|me|fr|io|xyz|vip|top|site|online|lol|ws|su|one)\b""")
    private val lead = Regex("""(?i)^\s*(regarder|voir|visionner|t[ée]l[ée]charger|streaming|film|s[ée]rie)\s+(le\s+|la\s+|les\s+|un\s+|l['’]\s*)?(film\s+|s[ée]rie\s+|[ée]pisode\s+|anim[ée]\s+|dessin\s+anim[ée]\s+)?(streaming\s+)?(de\s+|d['’]\s*)?""")
    private val junkTail = setOf("streaming", "stream", "vf", "vostfr", "vo", "truefrench", "french", "francais", "français", "gratuit",
        "gratuitement", "complet", "complete", "complète", "ligne", "hd", "fullhd", "full", "1080p", "720p", "480p", "en", "sans",
        "inscription", "illimité", "illimite", "télécharger", "telecharger", "download", "regarder", "voir", "et", "sur", "&")
    private val epInTitle = Regex("""(?i)\s*[-–:]?\s*(s(?:aison|eason)?\s*\d{1,2}\s*[-x]?\s*(?:e|[ée]p(?:isode)?)\s*\d{1,3}|saison\s*\d{1,2}|season\s*\d{1,2}|[ée]pisode\s*\d{1,3}|\d{1,2}x\d{1,3})\b.*$""")
    private val seRe = Regex("""(?i)(?:s(?:aison|eason)?[\s._-]*0*(\d{1,2})[\s._xX-]*(?:e|[ée]p(?:isode)?)[\s._-]*0*(\d{1,3}))|(?:saison[\s._-]*0*(\d{1,2}).{0,25}?[ée]pisode[\s._-]*0*(\d{1,3}))|(?:\b0*(\d{1,2})x0*(\d{1,3})\b)""")

    private fun slugTokens(pageUrl: String?): List<String> {
        val last = pageUrl?.let { Uri.decode(Uri.parse(it).path.orEmpty()).substringAfterLast('/') } ?: return emptyList()
        return last.substringBeforeLast('.').replace(Regex("^\\d+[-_]"), "").lowercase()
            .split('-', '_', ' ').filter { it.length > 1 && !it.all(Char::isDigit) }
    }

    private fun slugTitle(pageUrl: String?): String =
        slugTokens(pageUrl).joinToString(" ") { it.replaceFirstChar(Char::uppercase) }

    /** Saison / épisode lus dans l'adresse ou le titre (null si absents). */
    fun seasonEpisode(vararg texts: String?): Pair<Int, Int>? {
        for (t in texts) {
            val m = seRe.find(t ?: continue) ?: continue
            val g = m.groupValues
            val s = (g[1].ifEmpty { g[3] }.ifEmpty { g[5] }).toIntOrNull() ?: continue
            val e = (g[2].ifEmpty { g[4] }.ifEmpty { g[6] }).toIntOrNull() ?: continue
            return s to e
        }
        return null
    }

    private fun strip(seg: String): String {
        var s = seg.trim()
        s = lead.replace(s, "")
        s = epInTitle.replace(s, "")
        // On retire seulement les mots parasites situés À LA FIN (« … en streaming VF complet HD »), jamais ceux du milieu
        val words = s.split(Regex("\\s+")).toMutableList()
        while (words.size > 1 && words.last().trim('(', ')', '[', ']', ',', '.', '-').lowercase() in junkTail) words.removeAt(words.size - 1)
        s = words.joinToString(" ")
        if (s.length > 60 && ": " in s) s = s.substringBefore(": ")
        return s.trim(' ', '-', '–', ':', '|', ',', '.', '"', '\'', '«', '»').replace(Regex("\\s{2,}"), " ")
    }

    /** Nom propre (sans saison/épisode). */
    fun name(pageTitle: String?, pageUrl: String?): String {
        val title = pageTitle?.trim().orEmpty()
        val slug = slugTokens(pageUrl)
        val segs = title.split(sepRe).map { it.trim() }.filter { it.isNotBlank() && !siteRe.matches(it) && !siteRe.containsMatchIn(it).let { m -> m && it.length < 25 } }
        val best = segs.maxByOrNull { sg ->
            val low = sg.lowercase()
            var score = slug.count { it in low } * 10
            if (strip(sg).isNotBlank()) score += 2
            if (sg.length in 3..60) score += 3 else if (sg.length > 90) score -= 8
            score - segs.indexOf(sg)          // à égalité : le premier segment
        }
        var out = best?.let(::strip).orEmpty()
        if (out.isBlank() || out.length > 90) out = slugTitle(pageUrl).ifBlank { out.take(60) }
        return out.take(80).trim()
    }

    /** Nom de fichier pour une vidéo : « Mon Film (2023) » ou « Ma Série S02E05 ». */
    fun fileTitle(pageTitle: String?, pageUrl: String?): String {
        val n = name(pageTitle, pageUrl)
        val se = seasonEpisode(pageUrl?.let { Uri.decode(it) }, pageTitle)
        return if (se != null && n.isNotBlank()) "$n " + String.format(java.util.Locale.ROOT, "S%02dE%02d", se.first, se.second) else n
    }
}
