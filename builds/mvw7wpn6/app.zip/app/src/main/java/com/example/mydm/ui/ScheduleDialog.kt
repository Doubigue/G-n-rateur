package com.example.mydm.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.core.formatWhen
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

/** Barre « ⏰ Début du téléchargement : Immédiat / demain à 03:00 » avec boutons Programmer / Immédiat. */
@Composable
fun ScheduleBar(startAt: Long?, onPick: () -> Unit, onClear: () -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().glass().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("⏰ Début du téléchargement", color = Muted, fontSize = 12.sp)
            Text(startAt?.let { formatWhen(it) } ?: "Immédiat", color = if (startAt != null) Accent else Txt, fontSize = 14.sp)
        }
        if (startAt != null) TextButton(onClear) { Text("Immédiat") }
        OutlinedButton(onPick) { Text(if (startAt == null) "Programmer" else "Modifier") }
    }
}

/**
 * Choix de l'heure de départ : raccourcis (dans 1 h, ce soir, cette nuit) ou date puis heure précises.
 * [onConfirm] reçoit l'heure en millisecondes (toujours dans le futur).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleDialog(title: String = "Programmer le téléchargement", onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val zone = ZoneId.systemDefault()
    var step by remember { mutableIntStateOf(0) }          // 0 = raccourcis • 1 = date • 2 = heure
    var date by remember { mutableStateOf(LocalDate.now(zone)) }

    when (step) {
        0 -> {
            val now = ZonedDateTime.now(zone)
            fun next(hour: Int): Long {
                var t = now.toLocalDate().atTime(hour, 0).atZone(zone)
                if (!t.isAfter(now.plusMinutes(1))) t = t.plusDays(1)
                return t.toInstant().toEpochMilli()
            }
            val presets = listOf(
                "Dans 1 heure" to now.plusHours(1).toInstant().toEpochMilli(),
                "Soirée (23:00)" to next(23),
                "Nuit (03:00)" to next(3)
            )
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text(title) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        presets.forEach { (label, ms) ->
                            TextButton({ onConfirm(ms) }, Modifier.fillMaxWidth()) {
                                Column(Modifier.fillMaxWidth()) {
                                    Text(label)
                                    Text(formatWhen(ms), color = Muted, fontSize = 11.sp)
                                }
                            }
                        }
                        OutlinedButton({ step = 1 }, Modifier.fillMaxWidth()) { Text("Choisir la date et l'heure…") }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onDismiss) { Text("Annuler") } }
            )
        }
        1 -> {
            val todayUtc = LocalDate.now(zone).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
            val state = rememberDatePickerState(
                initialSelectedDateMillis = todayUtc,
                selectableDates = object : SelectableDates {
                    override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis >= todayUtc
                }
            )
            DatePickerDialog(
                onDismissRequest = onDismiss,
                confirmButton = {
                    TextButton({
                        state.selectedDateMillis?.let {
                            date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate(); step = 2
                        }
                    }) { Text("Suivant") }
                },
                dismissButton = { TextButton({ step = 0 }) { Text("Retour") } }
            ) { DatePicker(state) }
        }
        else -> {
            val start = ZonedDateTime.now(zone).plusHours(1)
            val ts = rememberTimePickerState(initialHour = start.hour, initialMinute = 0, is24Hour = true)
            val at = date.atTime(ts.hour, ts.minute).atZone(zone).toInstant().toEpochMilli()
            val valid = at > System.currentTimeMillis()
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text(formatWhen(at)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeInput(ts)
                        if (!valid) Text("Cette heure est déjà passée.", color = Danger, fontSize = 12.sp)
                    }
                },
                confirmButton = { TextButton({ onConfirm(at) }, enabled = valid) { Text("Programmer") } },
                dismissButton = { TextButton({ step = 1 }) { Text("Retour") } }
            )
        }
    }
}
