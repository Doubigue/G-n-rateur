package com.example.mydm.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.mydm.core.AccentColor
import com.example.mydm.core.Prefs
import com.example.mydm.core.ThemeMode

/** Palette courante (état Compose : toute l'UI se met à jour quand le style change). */
object Ui {
    /** Style réellement affiché (jamais SYSTEM : « Auto » est résolu en Sombre ou Clair). */
    var theme by mutableStateOf(ThemeMode.DARK)
    var accent by mutableStateOf(Color(0xFF8B7CFF))
    val dark: Boolean get() = theme.dark
}

// Couleurs lues partout dans l'application (getters => suivent le style choisi : fond, cartes, texte, accent)
val Bg: Color get() = Color(Ui.theme.bg)
val Surface1: Color get() = Color(Ui.theme.surface1)
val Surface2: Color get() = Color(Ui.theme.surface2)
val Txt: Color get() = Color(Ui.theme.text)
val Muted: Color get() = Color(Ui.theme.muted)
val Accent: Color get() = Ui.accent
/** Texte posé sur l'accent : sombre sur un accent clair, blanc sur un accent foncé. */
val OnAccent: Color get() = if (Ui.accent.luminance() > 0.45f) Color(0xFF0D0F1C) else Color.White
val Outline: Color get() = if (Ui.dark) Color(0x2AFFFFFF) else Color(0x22000000)
val Danger: Color get() = Color(0xFFFF6B7A)
val Success: Color get() = Color(0xFF3DDC97)
val Warn: Color get() = Color(0xFFFFC857)

fun accentOf(a: AccentColor) = Color(a.argb)

@Composable
fun MyDMTheme(content: @Composable () -> Unit) {
    val style = when (Prefs.themeMode) {
        ThemeMode.SYSTEM -> if (isSystemInDarkTheme()) ThemeMode.DARK else ThemeMode.LIGHT
        else -> Prefs.themeMode
    }
    val acc = if (Prefs.accent == AccentColor.AUTO) Color(style.accent) else accentOf(Prefs.accent)
    if (Ui.theme != style) Ui.theme = style
    if (Ui.accent != acc) Ui.accent = acc
    val dark = style.dark

    // Icônes de la barre d'état / de navigation lisibles sur le fond du style
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = !dark; isAppearanceLightNavigationBars = !dark }
    }

    val onAcc = if (acc.luminance() > 0.45f) Color(0xFF0D0F1C) else Color.White
    val scheme = if (dark) darkColorScheme(
        primary = acc, onPrimary = onAcc, secondary = acc, tertiary = Color(0xFF22D3EE),
        background = Bg, onBackground = Txt, surface = Surface1, onSurface = Txt,
        surfaceVariant = Surface2, onSurfaceVariant = Muted, outline = Outline,
        surfaceContainer = Surface1, surfaceContainerHigh = Surface2, surfaceContainerHighest = Surface2,
        error = Danger
    ) else lightColorScheme(
        primary = acc, onPrimary = onAcc, secondary = acc, tertiary = Color(0xFF0891B2),
        background = Bg, onBackground = Txt, surface = Surface1, onSurface = Txt,
        surfaceVariant = Surface2, onSurfaceVariant = Muted, outline = Outline,
        surfaceContainer = Surface1, surfaceContainerHigh = Surface2, surfaceContainerHighest = Surface2,
        error = Danger
    )
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)),
        content = content
    )
}

/** Carte arrondie (surface + liseré discret). Garde le nom historique « glass ». */
fun Modifier.glass(): Modifier = this
    .clip(RoundedCornerShape(18.dp))
    .background(Surface1)
    .border(1.dp, Outline, RoundedCornerShape(18.dp))
