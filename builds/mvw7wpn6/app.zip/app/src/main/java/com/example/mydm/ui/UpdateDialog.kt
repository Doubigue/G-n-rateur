package com.example.mydm.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.core.Prefs
import com.example.mydm.core.Updater
import kotlinx.coroutines.launch

/** Fenêtre « Mise à jour disponible » : télécharge l'APK puis lance l'installation. */
@Composable
fun UpdateDialog(info: Updater.Info, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = Surface1,
        title = { Text("Mise à jour ${info.versionName}", color = Txt) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Installée : ${Updater.currentName(ctx)}", color = Muted, fontSize = 12.sp)
                Text(info.notes.ifBlank { "Une nouvelle version de MyDM est disponible." }.take(600), color = Txt, fontSize = 14.sp)
                if (busy) {
                    if (Updater.progress in 0..99) LinearProgressIndicator(progress = { Updater.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(if (Updater.progress in 0..99) "Téléchargement… ${Updater.progress} %" else "Téléchargement…", color = Muted, fontSize = 12.sp)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                busy = true; error = null
                scope.launch {
                    runCatching { Updater.install(ctx, Updater.download(ctx, info)) }
                        .onSuccess { ok -> if (ok) onDismiss() else { busy = false; error = "Autorisez l'installation, puis touchez « Réessayer »." } }
                        .onFailure { busy = false; error = (it.message ?: "Échec").take(160) }
                }
            }) { Text(if (error != null) "Réessayer" else "Mettre à jour") }
        },
        dismissButton = {
            Row {
                TextButton(enabled = !busy, onClick = { Prefs.skipUpdate(info.versionName); onDismiss() }) { Text("Ignorer", color = Muted) }
                TextButton(enabled = !busy, onClick = onDismiss) { Text("Plus tard") }
            }
        }
    )
}
