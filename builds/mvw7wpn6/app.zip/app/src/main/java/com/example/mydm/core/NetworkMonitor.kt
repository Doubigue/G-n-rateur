package com.example.mydm.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/**
 * Surveille la connexion : les téléchargements se mettent en pause quand elle tombe
 * (ou quand « Wi-Fi uniquement » est actif sur données mobiles) et repartent d'eux-mêmes à son retour.
 */
object NetworkMonitor {
    private val _changes = MutableStateFlow(0)
    /** Se met à jour à chaque changement de réseau : il suffit d'appeler [usable] à ce moment-là. */
    val changes: StateFlow<Int> = _changes
    @Volatile private var cm: ConnectivityManager? = null
    @Volatile private var started = false

    @Synchronized fun init(ctx: Context) {
        if (started) return
        val c = ctx.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return
        cm = c; started = true
        runCatching {
            c.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { _changes.update { it + 1 } }
                override fun onLost(network: Network) { _changes.update { it + 1 } }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { _changes.update { it + 1 } }
            })
        }
    }

    /** null = on peut télécharger ; sinon la raison de l'attente. */
    fun waitReason(): String? {
        val c = cm ?: return null
        val caps = c.getNetworkCapabilities(c.activeNetwork) ?: return "En attente du réseau…"
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "En attente du réseau…"
        if (Prefs.wifiOnly && !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) return "En attente du Wi-Fi…"
        return null
    }

    fun usable() = waitReason() == null

    /** Texte affiché dans la liste quand un téléchargement est suspendu. */
    fun pausedText(): String =
        if (waitReason()?.contains("Wi-Fi") == true) "⏸ En pause : Wi-Fi requis — reprise automatique"
        else "⏸ En pause : pas de connexion — reprise automatique"
}
