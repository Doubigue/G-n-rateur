package com.example.mydm.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.mydm.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Visionneuse intégrée : vidéo, audio, images (zoom + balayage), PDF, texte, installation d'APK. */
@Composable
fun ViewerScreen() {
    val item = Viewer.current ?: return
    val ctx = LocalContext.current
    val kind = item.kind
    BackHandler { Viewer.close() }
    val darkPane = kind == ViewKind.VIDEO || kind == ViewKind.AUDIO || kind == ViewKind.IMAGE
    val bg = if (darkPane) Color(0xFF05060B) else Bg
    val fg = if (darkPane) Color.White else Txt

    Column(Modifier.fillMaxSize().background(bg).systemBarsPadding().pointerInput(Unit) { detectTapGestures { } }) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton({ Viewer.close() }) { Text("◀", fontSize = 18.sp, color = Accent) }
            Column(Modifier.weight(1f)) {
                Text(item.name, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
                if (Viewer.items.size > 1) Text("${Viewer.index + 1} / ${Viewer.items.size}", color = Muted, fontSize = 11.sp)
            }
            TextButton({ shareItem(ctx, item) }) { Text("Partager", color = Accent, fontSize = 12.sp) }
            TextButton({ openWithOtherApp(ctx, item) }) { Text("Ouvrir avec…", color = Accent, fontSize = 12.sp) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            // Les images partagent un seul pager (clé fixe) ; le reste est recréé à chaque élément
            key(if (kind == ViewKind.IMAGE) "images" else item.uri.toString()) {
                when (kind) {
                    ViewKind.VIDEO -> PlayerPane(item, audio = false) { if (Prefs.autoPlayNext) Viewer.next() }
                    ViewKind.AUDIO -> PlayerPane(item, audio = true) { if (Prefs.autoPlayNext) Viewer.next() }
                    ViewKind.IMAGE -> ImagePane(item)
                    ViewKind.PDF -> PdfPane(item)
                    ViewKind.TEXT -> TextPane(item)
                    ViewKind.APK -> ApkPane(item)
                    ViewKind.OTHER -> OtherPane(item)
                }
            }
        }
        if (Viewer.items.size > 1 && kind != ViewKind.IMAGE) {
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton({ Viewer.prev() }, enabled = Viewer.index > 0) { Text("◀ Précédent") }
                OutlinedButton({ Viewer.next() }, enabled = Viewer.index < Viewer.items.lastIndex) { Text("Suivant ▶") }
            }
        }
    }
}

// ───────────── Vidéo / audio (Media3 ExoPlayer)
@Composable
private fun PlayerPane(item: ViewItem, audio: Boolean, onEnded: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var error by remember { mutableStateOf<String?>(null) }
    val key = item.uri.toString()
    val exo = remember(key) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(item.uri))
            prepare()
            if (Prefs.resumePlayback) { val p = Prefs.position(key); if (p > 3000) seekTo(p) }
            playWhenReady = true
        }
    }
    val endedCb by rememberUpdatedState(onEnded)
    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { error = "Lecture impossible (" + e.errorCodeName + ")" }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) { Prefs.savePosition(key, 0); endedCb() }
            }
        }
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP && !audio) exo.pause() }
        exo.addListener(listener)
        owner.lifecycle.addObserver(obs)
        onDispose {
            if (exo.playbackState != Player.STATE_ENDED) Prefs.savePosition(key, exo.currentPosition)
            owner.lifecycle.removeObserver(obs)
            exo.removeListener(listener)
            exo.release()
        }
    }
    Box(Modifier.fillMaxSize()) {
        if (audio) Column(Modifier.align(Alignment.Center).padding(bottom = 120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎵", fontSize = 96.sp)
            Text(item.name.substringBeforeLast('.'), color = Color.White, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
        }
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    this.player = exo
                    useController = true
                    controllerShowTimeoutMs = if (audio) 0 else 3500
                    controllerHideOnTouch = !audio
                    keepScreenOn = Prefs.keepScreenOn && !audio
                }
            },
            modifier = if (audio) Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(220.dp) else Modifier.fillMaxSize()
        )
        error?.let { e ->
            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(e, color = Danger, fontSize = 14.sp)
                Text("Ce format n'est pas géré par le lecteur intégré.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                Button({ openWithOtherApp(ctx, item) }) { Text("Ouvrir avec une autre application") }
            }
        }
    }
}

// ───────────── Images : balayage + pincer pour zoomer + double tap
@Composable
private fun ImagePane(current: ViewItem) {
    val imgs = remember { Viewer.items.filter { it.kind == ViewKind.IMAGE } }
    if (imgs.isEmpty()) return
    val start = imgs.indexOfFirst { it.uri == current.uri }.coerceAtLeast(0)
    val pager = rememberPagerState(initialPage = start, pageCount = { imgs.size })
    var zoomed by remember { mutableStateOf(false) }
    LaunchedEffect(pager.currentPage) {
        val idx = Viewer.items.indexOfFirst { it.uri == imgs[pager.currentPage].uri }
        if (idx >= 0) Viewer.go(idx)
    }
    HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed, key = { imgs[it].uri.toString() }) { page ->
        ZoomableImage(imgs[page].uri) { z -> zoomed = z }
    }
}

private class Loaded(val bmp: ImageBitmap?)

@Composable
private fun ZoomableImage(uri: Uri, onZoom: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val loaded by produceState<Loaded?>(null, uri) { value = withContext(Dispatchers.IO) { Loaded(loadBitmap(ctx, uri, 2400)) } }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(scale) { onZoom(scale > 1.01f) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        // Un doigt à zoom 1 : on laisse le pager gérer le balayage
                        if (event.changes.size > 1 || scale > 1f) {
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale > 1f) offset + pan else Offset.Zero
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val l = loaded
        when {
            l == null -> CircularProgressIndicator(color = Accent)
            l.bmp == null -> Text("Image illisible", color = Muted)
            else -> Image(l.bmp, null,
                Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y),
                contentScale = ContentScale.Fit)
        }
    }
}

private fun loadBitmap(ctx: Context, uri: Uri, max: Int): ImageBitmap? = runCatching {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > max || bounds.outHeight / sample > max) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return@runCatching null
    val orientation = runCatching {
        cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
    }.getOrDefault(1)
    val deg = when (orientation) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
    val out = if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
    out.asImageBitmap()
}.getOrNull()

// ───────────── PDF (PdfRenderer d'Android)
private class PdfHolder(ctx: Context, uri: Uri) {
    private val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")!!
    private val renderer = PdfRenderer(pfd)
    val pageCount: Int get() = renderer.pageCount

    @Synchronized
    fun render(i: Int, width: Int): Bitmap {
        renderer.openPage(i).use { page ->
            val h = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        }
    }

    @Synchronized
    fun close() { runCatching { renderer.close(); pfd.close() } }
}

@Composable
private fun PdfPane(item: ViewItem) {
    val ctx = LocalContext.current
    val holder by produceState<PdfHolder?>(null, item.uri) {
        value = withContext(Dispatchers.IO) { runCatching { PdfHolder(ctx, item.uri) }.getOrNull() }
    }
    val h = holder
    DisposableEffect(h) { onDispose { h?.close() } }
    if (h == null) { Centered("Ouverture du PDF…") { OutlinedButton({ openWithOtherApp(ctx, item) }) { Text("Ouvrir avec…") } }; return }
    val widthPx = with(androidx.compose.ui.platform.LocalDensity.current) { (LocalConfiguration.current.screenWidthDp.dp.toPx() * 1.5f).toInt() }
    val state = rememberLazyListState()
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), state = state, contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(h.pageCount) { i ->
                val page by produceState<ImageBitmap?>(null, i) {
                    value = withContext(Dispatchers.IO) { runCatching { h.render(i, widthPx).asImageBitmap() }.getOrNull() }
                }
                val p = page
                if (p == null) Box(Modifier.fillMaxWidth().height(420.dp).background(Surface2), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Accent)
                } else Image(p, null, Modifier.fillMaxWidth().background(Color.White), contentScale = ContentScale.FillWidth)
            }
        }
        Text("Page ${state.firstVisibleItemIndex + 1} / ${h.pageCount}", color = Txt, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).background(Surface1.copy(alpha = 0.85f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
    }
}

// ───────────── Texte (txt, md, csv, json, srt…)
@Composable
private fun TextPane(item: ViewItem) {
    val ctx = LocalContext.current
    val text by produceState<String?>(null, item.uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(item.uri)!!.use { s ->
                    val buf = ByteArray(600_000); var n = 0
                    while (n < buf.size) { val r = s.read(buf, n, buf.size - n); if (r < 0) break; n += r }
                    String(buf, 0, n, Charsets.UTF_8)
                }
            }.getOrElse { "Lecture impossible : ${it.message}" }
        }
    }
    val t = text
    if (t == null) { Centered("Chargement…"); return }
    val lines = remember(t) { t.lines() }
    SelectionContainer {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
            items(lines.size) { Text(lines[it], color = Txt, fontSize = 13.sp, fontFamily = FontFamily.Monospace) }
        }
    }
}

// ───────────── APK : installation depuis l'application
@Composable
private fun ApkPane(item: ViewItem) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🤖", fontSize = 72.sp)
        Text(item.name, color = Txt, fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp))
        Text("Application Android (APK)", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 16.dp))
        Button({ Installer.install(ctx, item.uri) }) { Text("⬇ Installer l'application") }
        Text("Android vous demandera d'autoriser MyDM à installer des applications la première fois. N'installez que des APK de sources fiables.",
            color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 16.dp))
    }
}

@Composable
private fun OtherPane(item: ViewItem) {
    val ctx = LocalContext.current
    Centered("Pas de lecteur intégré pour « .${extOf(item.name)} ».") {
        Button({ openWithOtherApp(ctx, item) }) { Text("Ouvrir avec une autre application") }
    }
}
