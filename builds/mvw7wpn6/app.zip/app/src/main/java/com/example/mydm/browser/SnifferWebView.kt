package com.example.mydm.browser

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.webkit.*
import com.example.mydm.core.DetectedMedia
import com.example.mydm.core.MediaDetector
import com.example.mydm.core.MediaType
import com.example.mydm.core.Prefs
import com.example.mydm.core.UserScripts
import com.example.mydm.core.FileChooserBridge
import java.io.ByteArrayInputStream
import kotlinx.coroutines.flow.MutableSharedFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

object SnifferScript {
    const val JS = """
(function(){
  if (window.__sniffer) return; window.__sniffer = true;
  const seen = new Set();
  const exts = /\.(mp4|webm|mkv|m3u8|mp3|m4a|apk|pdf|zip|rar|vtt|srt)(\?|#|${'$'})/i;
  function send(u, kind){
    try { u = new URL(u, location.href).href; } catch(e){ return; }
    if (u.startsWith('blob:') || u.startsWith('data:') || seen.has(u)) return;
    seen.add(u); try { SnifferBridge.reportRef(u, kind, document.title || '', location.href); } catch(e){}
  }
  function scan(){
    document.querySelectorAll('video,audio').forEach(function(m){
      if (m.currentSrc) send(m.currentSrc,'media'); if (m.src) send(m.src,'media');
      m.querySelectorAll('source').forEach(function(s){ if (s.src) send(s.src,'media'); });
    });
    document.querySelectorAll('a[href]').forEach(function(a){ if (exts.test(a.href)) send(a.href,'link'); });
  }
  try { scan(); } catch(e){}
  new MutationObserver(function(){ try { scan(); } catch(e){} }).observe(document,
    {childList:true, subtree:true, attributes:true, attributeFilter:['src','href']});
  document.addEventListener('play', function(e){ if (e.target && e.target.currentSrc) send(e.target.currentSrc,'media'); }, true);
  const xo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(m,u){
    if (exts.test(u)) send(u,'xhr');
    try { this.addEventListener('readystatechange', function(){
      if (this.readyState === 2) { try { var ct = this.getResponseHeader('content-type') || '';
        if (/mpegurl/i.test(ct)) send(this.responseURL || u, 'hls'); else if (/^video\//i.test(ct)) send(this.responseURL || u, 'vid'); } catch(e){} } }); } catch(e){}
    return xo.apply(this, arguments); };
  const f = window.fetch;
  window.fetch = function(i){
    var u=(typeof i==='string')?i:(i&&i.url); if (u&&exts.test(u)) send(u,'fetch');
    var p = f.apply(this, arguments);
    try { p.then(function(r){ try { var ct = r.headers.get('content-type') || '';
      if (/mpegurl/i.test(ct)) send(r.url || u, 'hls'); else if (/^video\//i.test(ct)) send(r.url || u, 'vid'); } catch(e){} }).catch(function(){}); } catch(e){}
    return p; };
})();
"""
}

/**
 * Script anti-pub injecté dans toutes les pages et leurs iframes (au tout début du chargement).
 *  - window.open sans geste réel de l'utilisateur ou vers un autre site : refusé (sauf connexion Google / Apple / Facebook…)
 *  - clic sur un calque transparent plein écran (pub « cliquez n'importe où ») : annulé et calque supprimé
 *  - liens target=_blank vers un autre site, posés par un script sans clic : neutralisés
 *  - bannières et emplacements publicitaires courants : masqués
 */
object AdBlockScript {
    const val JS = """
(function(){
  if (window.__mydmAds) return; window.__mydmAds = true;
  var AUTH = /(^|\.)(accounts\.google\.com|appleid\.apple\.com|login\.microsoftonline\.com|login\.live\.com|github\.com|twitter\.com|x\.com|facebook\.com|paypal\.com|discord\.com)${'$'}/i;
  function base(h){ h = (h||'').toLowerCase().replace(/^www\./,'').split('.'); return h.length>2 ? h.slice(-2).join('.') : h.join('.'); }
  function sameSite(u){ try { return base(new URL(u, location.href).hostname) === base(location.hostname); } catch(e){ return false; } }
  function active(){ try { return navigator.userActivation ? navigator.userActivation.isActive : true; } catch(e){ return true; } }
  var realOpen = window.open;
  window.open = function(u){
    try {
      var host = ''; try { host = new URL(u || 'about:blank', location.href).hostname; } catch(e){}
      if (host && AUTH.test(host) && active()) return realOpen.apply(window, arguments);
      if (!active() || (u && !sameSite(u))) return null;
    } catch(e){ return null; }
    return realOpen.apply(window, arguments);
  };
  // Calque invisible plein écran : le clic ne doit rien ouvrir
  function isOverlay(el){
    try {
      if (!el || el === document.body || el === document.documentElement) return false;
      if (/^(VIDEO|AUDIO|CANVAS|INPUT|BUTTON|SELECT|TEXTAREA)${'$'}/.test(el.tagName)) return false;
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'absolute') return false;
      var r = el.getBoundingClientRect();
      if (r.width < innerWidth * 0.85 || r.height < innerHeight * 0.85) return false;
      var z = parseInt(cs.zIndex, 10) || 0;
      var transparent = parseFloat(cs.opacity) < 0.15 || cs.backgroundColor === 'rgba(0, 0, 0, 0)' || cs.backgroundColor === 'transparent';
      return z >= 100 && transparent && (el.textContent || '').trim().length < 3;
    } catch(e){ return false; }
  }
  document.addEventListener('click', function(e){
    var t = e.target;
    var a = t && t.closest ? t.closest('a[href]') : null;
    if (isOverlay(t) || (a && isOverlay(a))) {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      try { (a && isOverlay(a) ? a : t).remove(); } catch(x){}
      return;
    }
    if (a && a.target === '_blank' && !sameSite(a.href) && !e.isTrusted) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  // Liens « fantômes » créés par un script puis cliqués par lui-même (a.click())
  var realClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    try { if (/^https?:/i.test(this.href) && !sameSite(this.href) && (!active() || !this.isConnected)) return; } catch(e){}
    return realClick.apply(this, arguments);
  };
  // Emplacements publicitaires courants
  var css = '.adsbygoogle,ins.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[id*="ad-container"],[id*="adcontainer"],' +
    '[class*="ad-banner"],[class*="adbanner"],[class*="ad_banner"],[class*="advert"],[class*="popunder"],[class*="pop-under"],' +
    'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"],iframe[src*="exoclick"],iframe[src*="propeller"],' +
    'iframe[id^="google_ads"],a[href*="doubleclick.net"],a[href*="adsterra"],a[href*="exoclick"],a[href*="popads"]{display:none!important;visibility:hidden!important}';
  function addCss(){
    try { var st = document.createElement('style'); st.textContent = css; (document.head || document.documentElement).appendChild(st); } catch(e){}
  }
  if (document.head || document.documentElement) addCss(); else document.addEventListener('DOMContentLoaded', addCss);
})();
"""
}

/** Règles communes : sites publicitaires et « même site » (pour bloquer pop-ups et redirections parasites). */
object UrlRules {
    val adHosts = listOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "taboola.com", "outbrain.com", "adnxs.com", "criteo.com", "criteo.net", "popads.net",
        "propellerads.com", "exoclick.com", "adsterra.com", "mgid.com", "ads.yahoo.com", "scorecardresearch.com", "hotjar.com",
        "popcash.net", "juicyads.com", "trafficjunky.net", "amazon-adsystem.com", "moatads.com", "adform.net", "rubiconproject.com",
        "onclickads.net", "clickadu.com", "hilltopads.net", "adcash.com", "richpush.co", "a-ads.com", "ad-maven.com", "admaven.com",
        "tsyndicate.com", "bidvertiser.com", "revcontent.com", "yllix.com", "usrpubtrk.com", "popunder.net", "adspyglass.com",
        "adskeeper.com", "ero-advertising.com", "trafficstars.com", "realsrv.com", "syndication.exdynsrv.com", "pushwhy.com",
        "notifpush.com", "cloudfront-ads.com", "highperformanceformat.com", "profitablecpmrate.com", "effectivegatecpm.com",
        "pubmatic.com", "openx.net", "casalemedia.com", "smartadserver.com", "adsrvr.org", "3lift.com", "sharethrough.com", "teads.tv",
        "adtelligent.com", "sovrn.com", "quantserve.com", "zedo.com", "serving-sys.com", "bidswitch.net", "inmobi.com", "mopub.com",
        "applovin.com", "adcolony.com", "vungle.com", "chartboost.com", "adsco.re", "onclkds.com", "clickaine.com", "magsrv.com",
        "exosrv.com", "exdynsrv.com", "2mdn.net", "googletagservices.com", "advertising.com", "adition.com",
        "contextweb.com", "lijit.com", "krxd.net", "rlcdn.com", "bluekai.com", "yandexadexchange.net", "an.yandex.ru",
        "adsafeprotected.com", "doubleverify.com", "outbrainimg.com", "taboolasyndication.com", "smartclip.net", "adform.com",
        "tapad.com", "everesttech.net", "demdex.net", "adblade.com", "monetag.com")
    fun isAdHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return adHosts.any { h == it || h.endsWith(".$it") }
    }
    fun isAdUrl(u: String) = isAdHost(Uri.parse(u).host)
    /** Sous-ressource (script, iframe, image…) dont l'adresse trahit une régie publicitaire, même sur un hôte inconnu. */
    private val adResource = Regex("""(?i)(/|[._-])(popunder|pop-under|popads|adsbygoogle|adserver|adserving|ad-?frame|ad_?banner|prebid|vast\.xml|ads?\.js|pagead|show_ads|adsense|sponsored-?ads)([/._?&-]|${'$'})""")
    fun looksLikeAdResource(u: String): Boolean {
        val uri = Uri.parse(u)
        return adResource.containsMatchIn((uri.path ?: "") + "?" + (uri.query ?: "").take(120))
    }
    /** Connexion « Se connecter avec Google / Apple / Facebook… » : seul cas où une fenêtre vers un autre site est permise. */
    fun isAuthHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return listOf("accounts.google.com", "appleid.apple.com", "login.microsoftonline.com", "login.live.com", "github.com",
            "facebook.com", "paypal.com", "discord.com", "twitter.com", "x.com").any { h == it || h.endsWith(".$it") }
    }
    private val adWords = Regex("""(?i)(^|[/_.\-?&=])(ads?|adv|adserver|adserving|vast|vpaid|preroll|pre-roll|midroll|banner|popunder|sponsor|googleads|imasdk|adtag|ad_tag|promo)([/_.\-?&=]|$)""")
    /** Vidéo de publicité : hôte publicitaire ou mots typiques dans l'adresse (vast, preroll, /ads/…). */
    fun looksLikeAd(u: String): Boolean {
        val uri = Uri.parse(u)
        return isAdHost(uri.host) || adWords.containsMatchIn((uri.path ?: "") + "?" + (uri.query ?: "").take(120))
    }
    fun originOf(url: String?): String? = url?.let { runCatching { Uri.parse(it).let { p -> p.scheme + "://" + p.host + (if (p.port > 0) ":" + p.port else "") } }.getOrNull() }
    private fun base(h: String): String = h.lowercase().removePrefix("www.").split('.').let { if (it.size > 2) it.takeLast(2).joinToString(".") else it.joinToString(".") }
    fun sameSite(a: String?, b: String?): Boolean {
        val ha = a?.let { Uri.parse(it).host } ?: return false
        val hb = b?.let { Uri.parse(it).host } ?: return false
        return base(ha) == base(hb)
    }
}

class JsBridge(private val onFound: (String, String, String, String?) -> Unit) {
    @JavascriptInterface fun report(url: String, kind: String, title: String) = onFound(url, kind, title, null)
    @JavascriptInterface fun reportRef(url: String, kind: String, title: String, ref: String) = onFound(url, kind, title, ref)
}

class SnifferWebViewClient(
    private val events: MutableSharedFlow<DetectedMedia>,
    private val userAgent: () -> String
) : WebViewClient() {
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val refOf = ConcurrentHashMap<String, String>()   // url -> référent déjà transmis
    private val probed = ConcurrentHashMap.newKeySet<String>()
    @Volatile var pageDone = false
    /** Navigation protégée : pop-ups / redirections automatiques vers d'autres sites bloquées (onglets visibles). */
    @Volatile var guardNavigation = true
    /** Jusqu'à cet instant (uptimeMillis), toute navigation vers un autre site est refusée (clics simulés de l'analyse). */
    @Volatile var blockNavUntil = 0L
    @Volatile var currentPage: String? = null
    @Volatile var currentTitle: String? = null
    var onUrlChanged: (String) -> Unit = {}

    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
    private val pool = ThreadPoolExecutor(2, 3, 30, TimeUnit.SECONDS, ArrayBlockingQueue(40), ThreadPoolExecutor.DiscardPolicy())

    private val staticExt = Regex("\\.(js|css|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|html?|json|map|ts)(\\?|#|$)", RegexOption.IGNORE_CASE)
    private val hints = listOf("video", "mp4", "stream", "download", "/media/", "audio", "videoplayback")
    private val cdName = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)", RegexOption.IGNORE_CASE)

    override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
        currentPage = url; pageDone = false; seen.clear(); probed.clear(); onUrlChanged(url)
    }
    override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
        if (url.startsWith("http")) onUrlChanged(url)
    }
    override fun onPageFinished(view: WebView, url: String) {
        currentTitle = view.title
        pageDone = true
        view.evaluateJavascript(SnifferScript.JS, null)
        if (Prefs.blockAds) view.evaluateJavascript(AdBlockScript.JS, null)
        UserScripts.forUrl(url).forEach { view.evaluateJavascript(UserScripts.wrap(it.code), null) }
    }

    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        val url = request.url.toString()
        // intent://, market://, application externe… : jamais (les sites de streaming s'en servent pour détourner)
        if (!url.startsWith("http") && !url.startsWith("about:") && !url.startsWith("blob:") && !url.startsWith("data:")) return true
        if (!request.isForMainFrame) return false
        if ((Prefs.blockPopups || Prefs.blockAds) && (UrlRules.isAdUrl(url) || UrlRules.looksLikeAdResource(url))) return true
        val cur = currentPage
        if (cur != null && !UrlRules.sameSite(cur, url) && !request.isRedirect) {
            // Analyse : un clic simulé sur « lecture » ne doit pas nous envoyer sur une page de pub
            if (android.os.SystemClock.uptimeMillis() < blockNavUntil) return true
            // Onglet visible : une page qui s'envoie seule ailleurs (sans clic) est bloquée
            if (Prefs.blockPopups && guardNavigation && pageDone && !request.hasGesture()) return true
        }
        return false
    }

    // Thread d'arrière-plan : ne pas toucher à la View
    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val url = request.url.toString()
        if (!url.startsWith("http")) return null
        if (Prefs.blockAds && (UrlRules.isAdHost(request.url.host) ||
                (!request.isForMainFrame && UrlRules.looksLikeAdResource(url))))
            return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
        val type = MediaDetector.detect(url)
        val ref = request.requestHeaders.entries.firstOrNull { it.key.equals("Referer", true) }?.value
        if (type != null) emit(url, type, referer = ref)
        else if (request.method == "GET" && shouldProbe(url, request.requestHeaders)) probe(url, ref)
        return null
    }

    private fun shouldProbe(url: String, headers: Map<String, String>): Boolean {
        val u = Uri.parse(url)
        val host = u.host?.lowercase() ?: return false
        if (host.endsWith("googlevideo.com") || host.contains("doubleclick") || host.contains("google-analytics")) return false
        if (staticExt.containsMatchIn(u.path ?: "")) return false
        // Un lecteur média envoie toujours un en-tête Range
        if (headers.keys.any { it.equals("Range", ignoreCase = true) }) return true
        val l = url.lowercase()
        return hints.any { it in l }
    }

    /** Détection par Content-Type / Content-Disposition (fichiers sans extension dans l'URL). */
    private fun probe(url: String, requestReferer: String? = null) {
        if (!probed.add(url)) return
        val ref = requestReferer ?: currentPage; val ua = userAgent()
        pool.execute {
            runCatching {
                val rb = Request.Builder().url(url).header("Range", "bytes=0-0").header("User-Agent", ua)
                ref?.let { rb.header("Referer", it); UrlRules.originOf(it)?.let { o -> rb.header("Origin", o) } }
                CookieManager.getInstance().getCookie(url)?.let { rb.header("Cookie", it) }
                http.newCall(rb.build()).execute().use { r ->
                    if (!r.isSuccessful) return@use
                    val ct = r.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase() ?: ""
                    val cd = r.header("Content-Disposition")
                    val cdFile = cd?.let { cdName.find(it)?.groupValues?.get(1)?.trim() }?.let { Uri.decode(it) }
                    val type = typeFromMime(ct) ?: cdFile?.let { MediaDetector.detect("http://x/$it") } ?: return@use
                    val size = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                        ?: if (r.code == 200) r.header("Content-Length")?.toLongOrNull() else null
                    if ((type == MediaType.VIDEO || type == MediaType.AUDIO) && size != null && size < 100_000) return@use
                    val fileName = cdFile ?: Uri.parse(url).lastPathSegment?.takeIf { it.contains('.') }
                    emit(url, type, fileName, size, ref)
                }
            }
        }
    }

    private fun typeFromMime(ct: String): MediaType? = when {
        ct == "video/mp2t" -> null
        ct.contains("mpegurl") -> MediaType.HLS
        ct.startsWith("video/") -> MediaType.VIDEO
        ct.startsWith("audio/") -> MediaType.AUDIO
        ct == "application/pdf" -> MediaType.PDF
        ct == "application/vnd.android.package-archive" -> MediaType.APK
        ct == "application/zip" || ct == "application/x-zip-compressed" ||
            ct == "application/x-rar-compressed" || ct == "application/x-7z-compressed" -> MediaType.ARCHIVE
        else -> null
    }

    fun emit(url: String, type: MediaType, name: String? = null, size: Long? = null, referer: String? = null, fromScript: Boolean = false) {
        val allowed = when (type) {
            MediaType.VIDEO, MediaType.HLS -> Prefs.detectVideo
            MediaType.AUDIO -> Prefs.detectAudio
            else -> Prefs.detectFiles
        }
        if (!allowed || UrlRules.looksLikeAd(url)) return                          // publicités : jamais captées
        val fresh = seen.add(url)
        // Déjà vu : on ne ré-émet que si le lecteur (iframe) fournit un référent plus précis que celui de la requête
        if (!fresh) { if (referer == null || refOf[url] == referer || refOf[url] != null && !fromScript) return }
        referer?.let { refOf[url] = it }
        events.tryEmit(DetectedMedia(url, type, currentPage, currentTitle, userAgent(),
            CookieManager.getInstance().getCookie(url), referer ?: currentPage, name, size))
    }
}

class SnifferWebView(context: Context) : WebView(context) {
    val detectedMedia = MutableSharedFlow<DetectedMedia>(extraBufferCapacity = 64)
    // User-Agent mis en cache : le client le lit depuis un thread d'arrière-plan (jamais settings.* ici)
    @Volatile private var ua: String = ""
    private val client = SnifferWebViewClient(detectedMedia) { ua }
    private val defaultUa: String
    private val defaultWideViewPort: Boolean
    private val defaultOverview: Boolean

    var onUrlChanged: (String) -> Unit
        get() = client.onUrlChanged
        set(v) { client.onUrlChanged = v }
    var onTitleChanged: (String) -> Unit = {}
    var onProgress: (Int) -> Unit = {}
    /** Appelé quand une page ouvre une nouvelle fenêtre (target=_blank, window.open) : renvoie la WebView du nouvel onglet. */
    var windowRequested: () -> SnifferWebView? = { null }
    var closeRequested: () -> Unit = {}
    /** false pour la WebView invisible d'analyse : aucune fenêtre ni redirection automatique n'est suivie. */
    var guardNavigation: Boolean
        get() = client.guardNavigation
        set(v) { client.guardNavigation = v }
    /** Refuse toute navigation vers un autre site pendant [ms] millisecondes. */
    fun blockNavFor(ms: Long) { client.blockNavUntil = android.os.SystemClock.uptimeMillis() + ms }
    /** (niveau, message, source:ligne) — console JavaScript de la page. */
    var onConsole: (String, String, String) -> Unit = { _, _, _ -> }

    init {
        settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            builtInZoomControls = true; displayZoomControls = false
        }
        defaultUa = settings.userAgentString
        defaultWideViewPort = settings.useWideViewPort
        defaultOverview = settings.loadWithOverviewMode
        applyPrefs()
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = client
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) = onProgress(newProgress)
            override fun onReceivedTitle(view: WebView, title: String?) { title?.let(onTitleChanged) }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!guardNavigation) return false
                if (Prefs.blockPopups) return handlePopup(view, isUserGesture, resultMsg)
                val child = windowRequested() ?: return false
                (resultMsg.obj as WebView.WebViewTransport).webView = child
                resultMsg.sendToTarget()
                return true
            }
            override fun onCloseWindow(window: WebView) = closeRequested()
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (Prefs.captureConsole) onConsole(m.messageLevel().name, m.message(), m.sourceId().orEmpty().substringAfterLast('/') + ":" + m.lineNumber())
                return true
            }
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean =
                FileChooserBridge.show(cb, params.createIntent())
        }
        addJavascriptInterface(JsBridge { url, kind, title, ref ->
            val type = MediaDetector.detect(url) ?: when (kind) {
                "media", "vid" -> MediaType.VIDEO
                "hls" -> MediaType.HLS
                else -> return@JsBridge
            }
            client.emit(url, type, if (kind == "media") title.takeIf { it.isNotBlank() } else null, referer = ref, fromScript = true)
        }, "SnifferBridge")
        // Le script est aussi injecté dans les iframes (lecteurs d'hébergeurs : uqload, voe…), pas seulement la page
        runCatching {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT))
                androidx.webkit.WebViewCompat.addDocumentStartJavaScript(this, SnifferScript.JS, setOf("*"))
        }
        // Anti-pub dès le début de chaque page ET de chaque iframe (les pubs « popunder » viennent souvent d'une iframe)
        runCatching {
            if (Prefs.blockAds && androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT))
                androidx.webkit.WebViewCompat.addDocumentStartJavaScript(this, AdBlockScript.JS, setOf("*"))
        }
        setDownloadListener { url, _, disposition, mime, length ->
            val type = MediaDetector.detect(url)
                ?: if (mime?.startsWith("video") == true) MediaType.VIDEO
                else if (mime?.startsWith("audio") == true) MediaType.AUDIO else MediaType.ARCHIVE
            client.emit(url, type, URLUtil.guessFileName(url, disposition, mime), length.takeIf { it > 0 })
        }
    }

    /**
     * Pop-up (window.open / target=_blank) : on l'ouvre dans une WebView jetable qui ne charge rien,
     * on lit seulement l'adresse visée. Lien du même site cliqué par vous → ouvert dans cet onglet ; tout le reste est ignoré.
     */
    private fun handlePopup(view: WebView, userGesture: Boolean, msg: Message): Boolean {
        val cur = view.url.orEmpty()
        val probe = WebView(view.context)
        probe.settings.javaScriptEnabled = false
        var handled = false
        fun decide(u: String?) {
            if (handled || u.isNullOrBlank() || u == "about:blank") return
            handled = true
            val ok = userGesture && u.startsWith("http") && !UrlRules.isAdUrl(u) && !UrlRules.looksLikeAdResource(u) &&
                (UrlRules.sameSite(cur, u) || UrlRules.isAuthHost(Uri.parse(u).host))
            view.post { if (ok) view.loadUrl(u); probe.stopLoading(); probe.destroy() }
        }
        probe.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean { decide(r.url.toString()); return true }
            override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) { decide(u) }
        }
        (msg.obj as WebView.WebViewTransport).webView = probe
        msg.sendToTarget()
        view.postDelayed({ if (!handled) { handled = true; probe.stopLoading(); probe.destroy() } }, 4000)
        return true
    }

    /** Applique les réglages (mode ordinateur). Thread principal uniquement. Renvoie true si le User-Agent a changé. */
    fun applyPrefs(): Boolean {
        val desktop = Prefs.desktopMode
        val newUa = if (desktop) DESKTOP_UA else defaultUa
        val changed = newUa != ua
        ua = newUa
        settings.userAgentString = newUa
        val jsBefore = settings.javaScriptEnabled
        settings.javaScriptEnabled = Prefs.jsEnabled
        settings.loadsImagesAutomatically = Prefs.loadImages
        settings.textZoom = Prefs.textZoom
        settings.useWideViewPort = if (desktop) true else defaultWideViewPort
        settings.loadWithOverviewMode = if (desktop) true else defaultOverview
        return changed || jsBefore != Prefs.jsEnabled
    }

    companion object {
        const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
}
