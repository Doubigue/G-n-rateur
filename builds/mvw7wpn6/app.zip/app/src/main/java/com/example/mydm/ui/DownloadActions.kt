package com.example.mydm.ui

import android.content.Context
import com.example.mydm.App
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService

object DownloadActions {
    /**
     * Met un média détecté en file d'attente (direct ou HLS via yt-dlp) puis le lance — ou le programme si [startAt] est dans le futur.
     * [variant] : qualité choisie d'un flux HLS.
     */
    suspend fun queue(ctx: Context, app: App, m: DetectedMedia, subFolder: String? = null, name: String? = null, variant: HlsVariant? = null, startAt: Long? = null) {
        val meta = MediaResolver.cachedMeta(m.url) ?: MediaResolver.probeMeta(m)
        val dur = meta.durationSec ?: 0L
        val id = if (m.type == MediaType.HLS) {
            // Taille estimée (débit × durée) conservée dans la liste des téléchargements
            val size = variant?.estimatedSize(meta.durationSec) ?: meta.sizeBytes
            app.downloadEngine.enqueueYt(m.url, name ?: m.displayName(), variant?.toOption() ?: QualityOption("HLS", null, false, "b"),
                m.referer, m.userAgent, subFolder, dur, m.cookies, size)
        } else app.downloadEngine.enqueue(m, subFolder, name, dur)
        launch(ctx, app, id, startAt)
    }

    /** Lance la tâche maintenant, ou la programme à l'heure [startAt] (ms) si elle est dans le futur. */
    suspend fun launch(ctx: Context, app: App, id: String, startAt: Long?) {
        if (startAt != null && startAt > System.currentTimeMillis() + 5_000) app.downloadEngine.schedule(id, startAt)
        else DownloadService.start(ctx, id)
    }
}
