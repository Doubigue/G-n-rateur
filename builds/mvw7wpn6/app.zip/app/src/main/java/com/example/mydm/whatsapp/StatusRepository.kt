package com.example.mydm.whatsapp

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import com.example.mydm.core.Category
import com.example.mydm.core.Storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class WaApp(val label: String, val pkg: String, val rootFolders: List<String>) {
    WHATSAPP("WhatsApp", "com.whatsapp", listOf("WhatsApp")),
    BUSINESS("WhatsApp Business", "com.whatsapp.w4b", listOf("WhatsApp Business", "WhatsApp"))
}

data class StatusItem(val uri: Uri, val name: String, val mime: String, val size: Long, val modified: Long) {
    val isVideo get() = mime.startsWith("video/")
}

data class ScanResult(val items: List<StatusItem>, val message: String, val info: String = "")

class StatusRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("wa", Context.MODE_PRIVATE)

    fun initialUri(app: WaApp): Uri = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents", "primary:Android/media/${app.pkg}")

    fun persistGrant(app: WaApp, treeUri: Uri) {
        context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        prefs.edit().putString(app.pkg, treeUri.toString()).apply()
    }

    fun hasGrant(app: WaApp) = prefs.getString(app.pkg, null) != null

    private data class Found(val dir: DocumentFile, val path: String)

    /** Trouve tous les dossiers ".Statuses" de l'arborescence autorisée (ancien + nouvel emplacement). */
    private fun findAllStatusesDirs(root: DocumentFile, app: WaApp): List<Found> {
        if (root.name == ".Statuses") return listOf(Found(root, ".Statuses"))
        val results = mutableListOf<Found>()
        val hints = listOf("Android", "media", app.pkg, "WhatsApp Business", "WhatsApp", "Media")
        var level = listOf(Found(root, root.name ?: ""))
        var visited = 0
        repeat(7) {
            val next = mutableListOf<Found>()
            for (f in level) for (c in f.dir.listFiles()) {
                if (!c.isDirectory) continue
                val n = c.name ?: continue
                val path = f.path + "/" + n
                if (n == ".Statuses") {
                    val business = path.contains("w4b", true) || path.contains("Business", true)
                    if (business == (app == WaApp.BUSINESS)) results.add(Found(c, path))
                    continue
                }
                if (++visited > 800) return results
                next.add(Found(c, path))
            }
            level = next.sortedBy { hints.indexOf(it.dir.name).let { i -> if (i < 0) 99 else i } }.take(200)
        }
        return results
    }

    private fun mimeOf(f: DocumentFile): String? {
        val t = f.type
        if (t != null && t != "application/octet-stream") return t
        return when (f.name?.substringAfterLast('.', "")?.lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"
            "mp4", "m4v" -> "video/mp4"; "3gp" -> "video/3gpp"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"
            else -> null
        }
    }

    suspend fun scan(app: WaApp): ScanResult = withContext(Dispatchers.IO) {
        val tree = prefs.getString(app.pkg, null)?.let(Uri::parse)
            ?: return@withContext ScanResult(emptyList(), "Accès non autorisé.")
        val root = DocumentFile.fromTreeUri(context, tree)
        if (root == null || !root.exists())
            return@withContext ScanResult(emptyList(), "Le dossier autorisé est introuvable. Choisissez-le à nouveau.")
        val dirs = findAllStatusesDirs(root, app)
        if (dirs.isEmpty())
            return@withContext ScanResult(emptyList(),
                "Dossier « .Statuses » introuvable dans « ${root.name} ».\nChoisissez Android/media/${app.pkg} " +
                "(ou « WhatsApp/Media » sur Android 10), puis appuyez sur « Utiliser ce dossier ».")

        val seen = HashSet<String>()
        val items = mutableListOf<StatusItem>()
        val info = StringBuilder()
        for (d in dirs) {
            var count = 0
            for (f in d.dir.listFiles()) {
                if (!f.isFile) continue
                val mime = mimeOf(f)?.takeIf { it.startsWith("image/") || it.startsWith("video/") } ?: continue
                if (!seen.add((f.name ?: "") + "|" + f.length())) continue
                items.add(StatusItem(f.uri, f.name ?: "status", mime, f.length(), f.lastModified()))
                count++
            }
            info.append("• ").append(d.path.removePrefix("/")).append(" : ").append(count).append(" fichier(s)\n")
        }
        items.sortByDescending { it.modified }
        ScanResult(items,
            if (items.isEmpty()) "Dossier trouvé mais aucun statut.\nOuvrez WhatsApp, visionnez des statuts, puis actualisez." else "",
            info.toString().trim())
    }

    suspend fun save(item: StatusItem): Uri = withContext(Dispatchers.IO) {
        val dest = Storage.create(context, item.name, item.mime, Storage.rel(Category.VIDEO_MADE, "Statuts"))
        val resolver = context.contentResolver
        resolver.openInputStream(item.uri)!!.use { i -> resolver.openOutputStream(dest)!!.use { o -> i.copyTo(o) } }
        Storage.finish(context, dest)
        dest
    }
}
