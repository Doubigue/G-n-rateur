pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories {
        google(); mavenCentral()
        // jlibtorrent n'est pas sur Maven Central : dépôt officiel de FrostWire
        maven {
            url = uri("https://dl.frostwire.com/maven")
            content { includeGroup("com.frostwire") }
        }
    }
}
rootProject.name = "MyDM"
include(":app")
