# Extrait

Appli Android (Kotlin + Jetpack Compose) qui extrait le texte d'une ou de plusieurs centaines d'images, en gardant la disposition du texte.

- OCR local avec ML Kit (alphabet latin, hors ligne)
- Choix multiple d'images, lecture une par une avec progression
- Recadrage et rotation avant lecture (réglage appliqué à toutes les images choisies)
- Écran de lecture fidèle à l'image : couleur de fond, couleur du texte, gras et titres plus grands relevés dans l'image, texte sélectionnable
- Icône copier, partage en .txt, taille de texte réglable

## Compiler
Poussez le dossier sur la branche `main` d'un dépôt GitHub : le workflow `.github/workflows/build.yml` produit l'APK (onglet Actions > artefact `Extrait-debug-apk`).

## Fonctions ajoutées
- **Scanner (texte)** : scanner de documents (caméra, détourage, filtres couleur) puis lecture du texte.
- **Numériser (PDF)** : scanner de documents, PDF propre prêt à enregistrer ou partager.
- **Enregistrer** depuis l'écran de lecture : PDF, Word (.docx), Excel (.xlsx) ou .txt, avec fond, couleurs et gras relevés dans l'image.

## Nouveautés v1.1
- **Captures d'écran** : interrupteur sur l'accueil. Une fois activé, une petite carte (ou une notification) propose « Extraire le texte » ou « PDF » dès qu'une capture est prise, même app fermée. Autorisations : photos, notifications et, pour la carte flottante, « Affichage par-dessus les autres applis ».
- **Galerie / explorateur** : sélectionner une ou plusieurs images > Partager > *Extrait : texte ou PDF* ouvre une petite fenêtre avec « Extraire le texte » et « Numériser en PDF » (copier, partager, enregistrer le PDF, ou ouvrir dans l'app complète).
- **Clé de signature dédiée** : `app/extrait-release.jks` + `keystore.properties`. Le workflow produit un APK signé (`assembleRelease`) : les mises à jour s'installent par-dessus la version précédente. Sauvegardez ces deux fichiers ; si le dépôt est public, déplacez-les dans les *Secrets* GitHub (variables `KEYSTORE_FILE`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`).

## Pont avec LinkShare (v1.2)
Dans l'explorateur LinkShare (`com.linkshare`), sélectionner des images affiche les boutons **Extraire le texte** et **PDF**. Ils ouvrent
la petite fenêtre d'Extrait (`QuickActivity`, action `com.dlvibe.extrait.QUICK`, extra `mode` = `ocr` ou `pdf`). En mode PDF, Extrait
renvoie le PDF créé à LinkShare (résultat de l'activité), qui l'enregistre dans le dossier des images. Le contrat est dupliqué dans
`ExtraitBridge.kt` côté LinkShare : toute modification doit être faite des deux côtés.

## Captures d'écran, v1.3 (sans ouvrir l'app)
Dès qu'une capture est prise, une carte flottante propose **Extraire le texte** et **Numériser en PDF**. Les deux actions s'exécutent dans le
service de surveillance : l'app ne s'ouvre pas.
- *Extraire le texte* : lecture locale, texte copié tout de suite dans le presse-papiers, bouton **Partager**.
- *Numériser en PDF* : PDF enregistré dans `Téléchargements/Extrait` (Android 10+), boutons **Ouvrir** et **Partager**.
- Sans l'autorisation « Affichage par-dessus les autres applis », la même proposition arrive en notification (mêmes deux boutons).
- Détection plus rapide, avec nouvelles tentatives si la capture met un instant à apparaître dans la galerie.

## Identifiant (package)
`applicationId = com.doubigue.ocr` (espace de noms du code : `com.dlvibe.extrait`). LinkShare (`com.doubigue.linkshareexplorer`) cherche ce package pour afficher ses boutons Extraire / PDF.

## Diagnostic des captures, v1.4
Sous l'interrupteur « Captures d'écran », un petit rapport en direct indique : état du service, dernier signal de la galerie, résultat de la
dernière analyse, affichage de la carte, autorisations et exemption batterie. Boutons **Tester la carte** (affiche la carte tout de suite avec la
dernière image) et **Batterie : sans restriction**. La détection interroge aussi la galerie toutes les 4 s (filet de sécurité) et reconnaît une
image récente de la taille de l'écran même si son nom n'indique pas « capture ».

## v1.5
Détection des captures sans dépendre de la date : toute image apparue depuis le démarrage du service dont le nom ou le dossier évoque une capture
est proposée. Le rapport de l'accueil garde un journal des 8 derniers événements (images vues, capture trouvée, carte affichée).
