import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'models.dart';

class RouterException implements Exception {
  RouterException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Client HTTP du routeur. Protocole pris en charge : ZTE « goform »
/// (interface web courante sur les CPE LTE). Huawei est seulement détecté.
class RouterClient {
  RouterClient(String ip, {this.password = 'admin'}) : ip = _clean(ip);

  final String ip;
  final String password;
  final List<String> log = [];
  final Map<String, String> _cookies = {};
  final http.Client _http = http.Client();
  String dialect = 'inconnu';
  String? _secret;

  static const _timeout = Duration(seconds: 6);
  static const _zteCmds =
      'modem_main_state,pin_status,loginfo,wa_inner_version,imei,unlock_nck_time,network_type,sim_imsi';

  static String _clean(String s) {
    var v = s.trim().replaceFirst(RegExp(r'^https?://'), '');
    while (v.endsWith('/')) {
      v = v.substring(0, v.length - 1);
    }
    return v;
  }

  String _two(int n) => n.toString().padLeft(2, '0');
  void _l(String m) {
    final t = DateTime.now();
    log.add('${_two(t.hour)}:${_two(t.minute)}:${_two(t.second)}  ${_mask(m)}');
  }

  String _mask(String s) =>
      (_secret == null || _secret!.isEmpty) ? s : s.replaceAll(_secret!, '••••');

  String _short(String s) {
    final t = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    return t.length > 300 ? '${t.substring(0, 300)}…' : t;
  }

  void _store(String? header) {
    if (header == null) return;
    for (final part in header.split(RegExp(r',(?=\s*[A-Za-z0-9_\-]+=)'))) {
      final kv = part.split(';').first.trim();
      final i = kv.indexOf('=');
      if (i > 0) _cookies[kv.substring(0, i)] = kv.substring(i + 1);
    }
  }

  Future<http.Response> _req(String method, String path,
      {Map<String, String>? query, Map<String, String>? form}) async {
    final uri = Uri.http(ip, path, query);
    final headers = <String, String>{
      'Referer': 'http://$ip/index.html',
      'Origin': 'http://$ip',
      'X-Requested-With': 'XMLHttpRequest',
      'User-Agent': 'Mozilla/5.0 (Linux; Android) NCKUnlocker',
      if (_cookies.isNotEmpty)
        'Cookie': _cookies.entries.map((e) => '${e.key}=${e.value}').join('; '),
    };
    _l('$method $uri${form != null ? '  corps: ${form.entries.map((e) => '${e.key}=${e.value}').join('&')}' : ''}');
    final r = method == 'GET'
        ? await _http.get(uri, headers: headers).timeout(_timeout)
        : await _http.post(uri, headers: headers, body: form).timeout(_timeout);
    _store(r.headers['set-cookie']);
    _l('→ HTTP ${r.statusCode} ${_short(r.body)}');
    return r;
  }

  // ---------------------------------------------------------------- ZTE

  Future<Map<String, dynamic>?> _zteGet(String cmds) async {
    final r = await _req('GET', '/goform/goform_get_cmd_process',
        query: {'isTest': 'false', 'cmd': cmds, 'multi_data': '1'});
    if (r.statusCode != 200) return null;
    try {
      final j = jsonDecode(r.body);
      return j is Map<String, dynamic> ? j : null;
    } catch (_) {
      return null;
    }
  }

  RouterLock _parseLock(String state) {
    final s = state.toLowerCase();
    if (s.contains('nck')) return RouterLock.locked;
    if (s.contains('waitpuk')) return RouterLock.puk;
    if (s.contains('waitpin')) return RouterLock.pin;
    if (s.contains('sim_undetected') || s.contains('sim_destroy')) {
      return RouterLock.noSim;
    }
    if (s.contains('init_complete')) return RouterLock.unlocked;
    return RouterLock.unknown;
  }

  RouterInfo _zteInfo(Map<String, dynamic> j) {
    String s(String k) => (j[k] ?? '').toString();
    final st = s('modem_main_state');
    return RouterInfo(
      dialect: 'zte',
      rawState: st,
      lock: _parseLock(st),
      remaining: int.tryParse(s('unlock_nck_time')),
      firmware: s('wa_inner_version'),
      imei: s('imei'),
      network: s('network_type'),
    );
  }

  Future<void> _zteLoginIfNeeded(Map<String, dynamic> j) async {
    if ((j['loginfo'] ?? '').toString() != 'no') return;
    _l('Connexion à l’interface d’administration…');
    for (final pw in [base64.encode(utf8.encode(password)), password]) {
      final r = await _req('POST', '/goform/goform_set_cmd_process',
          form: {'isTest': 'false', 'goformId': 'LOGIN', 'password': pw});
      if (r.body.contains('"result":"0"') || r.body.contains('success')) {
        return;
      }
    }
    _l('Connexion admin refusée (mot de passe ?) – on continue sans.');
  }

  // ------------------------------------------------------------- public

  Future<RouterInfo> connect() async {
    _l('Connexion à $ip');
    try {
      final z = await _zteGet(_zteCmds);
      if (z != null && z.containsKey('modem_main_state')) {
        dialect = 'zte';
        await _zteLoginIfNeeded(z);
        return _zteInfo(await _zteGet(_zteCmds) ?? z);
      }
      final h = await _req('GET', '/api/webserver/SesTokInfo');
      if (h.statusCode == 200 && h.body.contains('SesInfo')) {
        dialect = 'huawei';
        return RouterInfo(dialect: 'huawei');
      }
      dialect = 'inconnu';
      return RouterInfo(dialect: 'inconnu');
    } on TimeoutException {
      throw RouterException(
          'Délai dépassé : le routeur ne répond pas sur $ip. Vérifiez que vous êtes connecté à son Wi‑Fi (données mobiles coupées) et que l’adresse IP est correcte.');
    } on SocketException catch (e) {
      throw RouterException(
          'Impossible de joindre $ip (${e.osError?.message ?? e.message}). Vérifiez le Wi‑Fi du routeur et l’adresse IP.');
    } on http.ClientException catch (e) {
      throw RouterException('Erreur réseau : ${e.message}');
    }
  }

  Future<RouterInfo> refresh() async {
    if (dialect != 'zte') return RouterInfo(dialect: dialect);
    final z = await _zteGet(_zteCmds);
    if (z == null) throw RouterException('Réponse illisible du routeur');
    return _zteInfo(z);
  }

  Future<UnlockResult> unlock(String nck) async {
    _secret = nck;
    final started = DateTime.now();
    Map<String, String> details(RouterInfo? b, RouterInfo? a, {String? sent}) => {
          'Adresse du routeur': ip,
          'Protocole': dialect,
          if (b != null) 'État avant': b.rawState.isEmpty ? '—' : b.rawState,
          if (a != null) 'État après': a.rawState.isEmpty ? '—' : a.rawState,
          if (b?.remaining != null) 'Tentatives avant': '${b!.remaining}',
          if (a?.remaining != null) 'Tentatives après': '${a!.remaining}',
          if (sent != null) 'Réponse du routeur': sent,
          'Durée': '${DateTime.now().difference(started).inSeconds} s',
        };

    if (dialect != 'zte') {
      return UnlockResult(
        outcome: Outcome.failed,
        title: 'Modèle non pris en charge',
        cause: dialect == 'huawei'
            ? 'Ce routeur utilise l’API Huawei, dont la commande de déverrouillage n’est pas implémentée dans cette version.'
            : 'Le protocole de ce routeur n’a pas été reconnu. Aucune commande n’a été envoyée, donc aucune tentative n’a été consommée.',
        suggestion:
            'Copiez le rapport ci‑dessous et envoyez‑le pour adapter l’application à votre modèle.',
        details: details(null, null),
        log: log,
      );
    }

    RouterInfo before;
    try {
      before = await refresh();
    } catch (e) {
      return UnlockResult(
        outcome: Outcome.failed,
        title: 'Connexion perdue',
        cause: 'Impossible de lire l’état du routeur avant l’envoi : $e',
        suggestion: 'Reconnectez‑vous au Wi‑Fi du routeur puis réessayez.',
        details: details(null, null),
        log: log,
      );
    }

    if (before.remaining == 0) {
      return UnlockResult(
        outcome: Outcome.failed,
        title: 'Plus aucune tentative',
        cause:
            'Le routeur indique 0 tentative NCK restante : il est bloqué. Rien n’a été envoyé.',
        suggestion: 'Contactez MTN pour débloquer le compteur.',
        details: details(before, null),
        log: log,
      );
    }

    String sent = '';
    try {
      final r = await _req('POST', '/goform/goform_set_cmd_process', form: {
        'isTest': 'false',
        'goformId': 'UNLOCK_NETWORK',
        'notCallback': 'true',
        'unlock_network_code': nck,
      });
      sent = _short(r.body);
    } on TimeoutException {
      sent = 'aucune réponse (délai dépassé)';
      _l('Pas de réponse à la commande – le routeur redémarre peut‑être.');
    } catch (e) {
      sent = 'erreur : $e';
    }
    final accepted = sent.contains('success') || sent.contains('"result":"0"');

    RouterInfo? after;
    for (var i = 0; i < 10; i++) {
      await Future.delayed(const Duration(milliseconds: 1500));
      try {
        after = await refresh();
        if (after.lock != RouterLock.locked) break;
      } catch (_) {
        _l('Routeur injoignable (redémarrage ?) – nouvelle tentative…');
      }
    }

    if (after == null) {
      return UnlockResult(
        outcome: Outcome.info,
        title: 'Résultat indéterminé',
        cause:
            'La commande a été envoyée mais le routeur ne répond plus (il redémarre probablement).',
        suggestion:
            'Attendez 1 à 2 minutes, reconnectez‑vous au Wi‑Fi, puis appuyez sur Connecter pour vérifier l’état.',
        details: details(before, null, sent: sent),
        log: log,
      );
    }

    if (after.lock != RouterLock.locked && after.lock != RouterLock.unknown) {
      final extra = after.lock == RouterLock.noSim
          ? ' Aucune SIM n’est détectée : insérez‑en une.'
          : after.lock == RouterLock.pin
              ? ' La SIM demande maintenant son code PIN.'
              : '';
      return UnlockResult(
        outcome: Outcome.success,
        title: 'Déverrouillage réussi',
        cause: 'Le routeur a accepté le code NCK et n’est plus verrouillé.$extra',
        suggestion: 'Redémarrez le routeur avec la SIM de votre choix.',
        details: details(before, after, sent: sent),
        log: log,
      );
    }

    if (after.lock == RouterLock.unknown) {
      return UnlockResult(
        outcome: Outcome.info,
        title: 'Résultat indéterminé',
        cause:
            'Le routeur a renvoyé un état non reconnu (« ${after.rawState} »).',
        suggestion: 'Copiez le rapport pour analyse.',
        details: details(before, after, sent: sent),
        log: log,
      );
    }

    // Toujours verrouillé
    String cause;
    String? tip;
    final rem = after.remaining;
    if (rem == 0) {
      cause =
          'Code NCK incorrect et plus aucune tentative restante : le routeur est bloqué.';
      tip = 'Contactez MTN pour obtenir un nouveau code ou réinitialiser le compteur.';
    } else if (rem != null &&
        before.remaining != null &&
        rem < before.remaining!) {
      cause = 'Code NCK incorrect : le routeur l’a rejeté.';
      tip = 'Vérifiez le code (chaque chiffre). Il reste $rem tentative(s).';
    } else if (!accepted) {
      cause =
          'Le routeur a refusé la commande (réponse : ${sent.isEmpty ? 'vide' : sent}). Code incorrect, ou commande non acceptée par ce firmware.';
      tip = 'Vérifiez le code. Si le problème persiste, copiez le rapport.';
    } else {
      cause =
          'Le routeur a accepté la commande mais reste verrouillé : code probablement incorrect.';
      tip = 'Vérifiez le code avant de réessayer.';
    }
    return UnlockResult(
      outcome: Outcome.failed,
      title: 'Déverrouillage échoué',
      cause: cause,
      suggestion: tip,
      details: details(before, after, sent: sent),
      log: log,
    );
  }
}
