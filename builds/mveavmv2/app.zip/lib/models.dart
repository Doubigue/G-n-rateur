enum RouterLock { locked, unlocked, noSim, pin, puk, unknown }

enum Outcome { success, failed, info }

class RouterInfo {
  RouterInfo({
    required this.dialect,
    this.rawState = '',
    this.lock = RouterLock.unknown,
    this.remaining,
    this.firmware = '',
    this.imei = '',
    this.network = '',
  });

  /// 'zte' (pris en charge), 'huawei' ou 'inconnu'
  final String dialect;
  final String rawState;
  final RouterLock lock;
  final int? remaining;
  final String firmware;
  final String imei;
  final String network;

  bool get supported => dialect == 'zte';

  String get lockLabel {
    if (!supported) {
      return dialect == 'huawei'
          ? 'Routeur Huawei détecté (déverrouillage automatique non pris en charge)'
          : 'Routeur joignable, mais protocole non reconnu';
    }
    switch (lock) {
      case RouterLock.locked:
        return 'Verrouillé sur un opérateur (code NCK requis)';
      case RouterLock.unlocked:
        return 'Aucun verrouillage détecté';
      case RouterLock.noSim:
        return 'SIM non détectée';
      case RouterLock.pin:
        return 'Code PIN de la SIM requis';
      case RouterLock.puk:
        return 'Code PUK de la SIM requis';
      case RouterLock.unknown:
        return 'État inconnu ($rawState)';
    }
  }
}

class UnlockResult {
  UnlockResult({
    required this.outcome,
    required this.title,
    required this.cause,
    this.suggestion,
    this.details = const {},
    this.log = const [],
  });

  final Outcome outcome;
  final String title;
  final String cause;
  final String? suggestion;
  final Map<String, String> details;
  final List<String> log;

  String report() {
    final b = StringBuffer()
      ..writeln('Résultat : $title')
      ..writeln('Cause : $cause');
    if (suggestion != null) b.writeln('Conseil : $suggestion');
    details.forEach((k, v) => b.writeln('$k : $v'));
    b.writeln('--- Journal ---');
    for (final l in log) {
      b.writeln(l);
    }
    return b.toString();
  }
}
