import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../config.dart';
import '../models.dart';
import '../router_client.dart';
import '../update_service.dart';
import 'result_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _ip = TextEditingController();
  final _pw = TextEditingController();
  final _nck = TextEditingController();
  RouterClient? _client;
  RouterInfo? _info;
  bool _connecting = false;
  bool _unlocking = false;
  bool _hide = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _nck.addListener(() => setState(() {}));
    _load();
  }

  Future<void> _load() async {
    _ip.text = await Config.getIp();
    _pw.text = await Config.getPassword();
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _ip.dispose();
    _pw.dispose();
    _nck.dispose();
    super.dispose();
  }

  bool get _nckValid => RegExp(r'^\d{8,16}$').hasMatch(_nck.text.trim());
  bool get _canUnlock =>
      _info != null && _nckValid && !_unlocking && !_connecting;

  Future<void> _connect() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _connecting = true;
      _error = null;
      _info = null;
    });
    final c = RouterClient(_ip.text,
        password: _pw.text.isEmpty ? 'admin' : _pw.text);
    try {
      final i = await c.connect();
      await Config.setIp(_ip.text.trim());
      await Config.setPassword(_pw.text);
      if (mounted) {
        setState(() {
          _client = c;
          _info = i;
        });
      }
    } on RouterException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (e) {
      if (mounted) setState(() => _error = 'Erreur inattendue : $e');
    } finally {
      if (mounted) setState(() => _connecting = false);
    }
  }

  Future<void> _unlock() async {
    final c = _client;
    final info = _info;
    if (c == null || info == null) return;
    final code = _nck.text.trim();

    if (info.supported && info.lock != RouterLock.locked) {
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Pas de verrouillage détecté'),
          content: Text(
              'État du routeur : ${info.lockLabel}.\n\nEnvoyer quand même le code ?'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Annuler')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Envoyer')),
          ],
        ),
      );
      if (go != true) return;
    } else {
      final rem = info.remaining;
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          icon: const Icon(Icons.warning_amber_rounded),
          title: const Text('Confirmer le déverrouillage'),
          content: Text(
              '${rem != null ? 'Il vous reste $rem tentative(s). ' : 'Le nombre de tentatives est limité. '}'
              'Après épuisement, le routeur peut se bloquer définitivement.\n\n'
              'Code saisi :\n$code\n\nEst‑il exact ?'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Corriger')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Déverrouiller')),
          ],
        ),
      );
      if (go != true) return;
    }

    setState(() => _unlocking = true);
    UnlockResult res;
    try {
      res = await c.unlock(code);
    } catch (e) {
      res = UnlockResult(
        outcome: Outcome.failed,
        title: 'Erreur inattendue',
        cause: e.toString(),
        log: c.log,
      );
    }
    if (!mounted) return;
    setState(() => _unlocking = false);
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => ResultScreen(result: res)));
    if (res.outcome == Outcome.success) _nck.clear();
    try {
      final i = await c.refresh();
      if (mounted) setState(() => _info = i);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Déblocage NCK'),
        actions: [
          IconButton(
            tooltip: 'Réglages',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _UpdateCard(),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('1 · Connexion au routeur',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _ip,
                    keyboardType: TextInputType.url,
                    decoration: const InputDecoration(
                      labelText: 'Adresse IP du routeur',
                      helperText:
                          'Souvent 192.168.0.1, 192.168.1.1 ou 192.168.100.1',
                      prefixIcon: Icon(Icons.router_outlined),
                    ),
                  ),
                  Theme(
                    data: Theme.of(context)
                        .copyWith(dividerColor: Colors.transparent),
                    child: ExpansionTile(
                      tilePadding: EdgeInsets.zero,
                      title: const Text('Options avancées'),
                      children: [
                        TextField(
                          controller: _pw,
                          decoration: const InputDecoration(
                            labelText: 'Mot de passe admin du routeur',
                            helperText: 'Par défaut : admin',
                            prefixIcon: Icon(Icons.key_outlined),
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _connecting ? null : _connect,
                      icon: _connecting
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.wifi_find),
                      label: Text(_connecting ? 'Connexion…' : 'Connecter'),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    _Banner(
                        icon: Icons.error_outline,
                        text: _error!,
                        color: cs.errorContainer,
                        onColor: cs.onErrorContainer),
                  ],
                  if (_info != null) ...[
                    const SizedBox(height: 12),
                    _Banner(
                      icon: _info!.supported && _info!.lock == RouterLock.locked
                          ? Icons.lock_outline
                          : _info!.supported
                              ? Icons.check_circle_outline
                              : Icons.info_outline,
                      text:
                          'Connecté à ${_ip.text.trim()}\n${_info!.lockLabel}'
                          '${_info!.remaining != null ? '\nTentatives restantes : ${_info!.remaining}' : ''}'
                          '${_info!.firmware.isNotEmpty ? '\nFirmware : ${_info!.firmware}' : ''}',
                      color: cs.secondaryContainer,
                      onColor: cs.onSecondaryContainer,
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('2 · Déverrouillage',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _nck,
                    enabled: _info != null,
                    obscureText: _hide,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    maxLength: 16,
                    decoration: InputDecoration(
                      labelText: 'Token NCK',
                      helperText: _info == null
                          ? 'Connectez‑vous d’abord au routeur'
                          : '8 à 16 chiffres',
                      prefixIcon: const Icon(Icons.pin_outlined),
                      suffixIcon: IconButton(
                        icon: Icon(
                            _hide ? Icons.visibility_off : Icons.visibility),
                        onPressed: () => setState(() => _hide = !_hide),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _canUnlock ? _unlock : null,
                      icon: _unlocking
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.lock_open),
                      label: Text(
                          _unlocking ? 'Vérification…' : 'Déverrouiller'),
                    ),
                  ),
                  if (_unlocking)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                          'Envoi du code puis vérification (jusqu’à 15 s). Ne quittez pas l’application.'),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner(
      {required this.icon,
      required this.text,
      required this.color,
      required this.onColor});
  final IconData icon;
  final String text;
  final Color color;
  final Color onColor;
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration:
            BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: onColor),
            const SizedBox(width: 10),
            Expanded(child: Text(text, style: TextStyle(color: onColor))),
          ],
        ),
      );
}

/// Carte affichée quand une nouvelle version existe.
class _UpdateCard extends StatelessWidget {
  const _UpdateCard();
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return AnimatedBuilder(
      animation: UpdateController.instance,
      builder: (context, _) {
        final u = UpdateController.instance;
        if (u.info == null && u.status != UpdateStatus.error) {
          return const SizedBox.shrink();
        }
        final busy = u.status == UpdateStatus.downloading ||
            u.status == UpdateStatus.installing;
        return Card(
          color: cs.primaryContainer,
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.system_update, color: cs.onPrimaryContainer),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      u.info != null
                          ? 'Nouvelle version ${u.info!.versionName} disponible'
                          : 'Mise à jour',
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: cs.onPrimaryContainer),
                    ),
                  ),
                ]),
                if (u.status == UpdateStatus.error && u.error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(u.error!,
                        style: TextStyle(color: cs.onPrimaryContainer)),
                  ),
                if (u.status == UpdateStatus.downloading) ...[
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                      value: u.progress > 0 ? u.progress : null),
                  const SizedBox(height: 4),
                  Text('Téléchargement ${(u.progress * 100).round()} %',
                      style: TextStyle(color: cs.onPrimaryContainer)),
                ],
                if (u.status == UpdateStatus.installing)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text('Ouverture de l’installateur…',
                        style: TextStyle(color: cs.onPrimaryContainer)),
                  ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: busy ? null : () => u.install(),
                  icon: const Icon(Icons.download),
                  label: Text(u.status == UpdateStatus.error
                      ? 'Réessayer'
                      : 'Mettre à jour'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
