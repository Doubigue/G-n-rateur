package com.mediastudio.app

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.mediastudio.app.router.CallerVerifier
import com.mediastudio.app.router.RouterContract
import com.mediastudio.app.router.RouterException
import com.mediastudio.app.router.RouterJobs
import com.mediastudio.app.router.RouterParser
import com.mediastudio.app.router.RouterRequest
import kotlinx.coroutines.delay

/**
 * Point d'entrée « sans interface » de MediaStudio pour les autres applis (LinkShare).
 *
 * 1. Vérifie l'appelant (paquet + signature) – lancé via startActivityForResult uniquement.
 * 2. Valide l'Intent ([RouterParser]) puis route vers la bonne classe de traitement ([RouterJobs]).
 * 3. Confie le travail à ExportManager / ExportService (service au premier plan) : le traitement survit
 *    à la rotation, à l'écran éteint et aux changements d'appli ; la fenêtre ne fait qu'observer l'état.
 * 4. Affiche une petite carte flottante sur fond translucide (thème Theme.MediaStudio.Router) avec la progression.
 * 5. À la fin, renvoie l'URI du fichier produit à l'appelant et se ferme toute seule.
 *
 * L'écran principal ([MainActivity]) n'est jamais lancé.
 */
@UnstableApi
class MediaStudioRouterActivity : ComponentActivity() {

    private var started by mutableStateOf(false)
    private var preflightError by mutableStateOf<String?>(null)
    private var sourceName = ""
    private var label = "Traitement"
    private var emoji = "⚙️"
    private var accent = 0xFF6750A4
    private var outputName = ""

    private sealed interface Phase {
        data class Failed(val message: String) : Phase
        data class Running(val progress: Float) : Phase
        data class Done(val uri: Uri) : Phase
        data object Cancelled : Phase
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFinishOnTouchOutside(false)
        Notifier.init(this) // canal requis par la notification du service au premier plan
        started = savedInstanceState?.getBoolean(STATE_STARTED, false) == true

        val request = preflight()
        if (request != null) {
            label = request.label
            emoji = request.emoji
            accent = request.accent
            sourceName = RouterParser.displayName(this, request.sources.first()).orEmpty()
                .let { if (request.sources.size > 1) "$it  +${request.sources.size - 1}" else it }
            if (!started) start(request)
        }
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) { RouterContent() }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_STARTED, started) // une recréation ne relance jamais le traitement
    }

    // ───────────────────────────── Routage ─────────────────────────────

    private fun preflight(): RouterRequest? {
        if (!CallerVerifier.isTrusted(this, callingPackage)) {
            preflightError = "Appel non autorisé (appelant : ${callingPackage ?: "inconnu"})."
            return null
        }
        return try {
            RouterParser.parse(this, intent)
        } catch (e: RouterException) {
            preflightError = e.message
            null
        }
    }

    private fun start(request: RouterRequest) {
        if (ExportManager.state.value.busy) {
            preflightError = "Un traitement est déjà en cours dans Media Studio."
            return
        }
        val base = RouterParser.baseName(this, request.sources.first(), fallback = "media")
        // applicationContext : le Job est conservé par le service, il ne doit pas retenir l'activité
        val job = RouterJobs.build(applicationContext, request, base)
        outputName = job.name
        ExportManager.start(applicationContext, job)
        started = true
    }

    private fun cancelExport() {
        if (ExportManager.state.value.busy)
            startService(Intent(this, ExportService::class.java).setAction(ExportService.ACTION_CANCEL))
    }

    // ───────────────────────────── Fin ─────────────────────────────

    private fun finishOk(uri: Uri) {
        setResult(
            RESULT_OK,
            Intent().setData(uri)
                .putExtra(RouterContract.EXTRA_OUTPUT_NAME, outputName)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .also { it.clipData = ClipData.newRawUri("", uri) }
        )
        finish()
    }

    private fun finishCanceled(error: String? = null) {
        setResult(RESULT_CANCELED, error?.let { Intent().putExtra(RouterContract.EXTRA_ERROR, it) })
        finish()
    }

    // ───────────────────────────── Interface ─────────────────────────────

    @Composable
    private fun RouterContent() {
        val st by ExportManager.state.collectAsState()
        val phase: Phase = when {
            preflightError != null -> Phase.Failed(preflightError!!)
            !started -> Phase.Cancelled
            st.busy -> Phase.Running(st.progress)
            st.outputUri != null -> Phase.Done(st.outputUri!!)
            st.cancelled -> Phase.Cancelled
            else -> Phase.Failed(st.error ?: "Traitement interrompu.")
        }

        when (phase) {
            is Phase.Done -> LaunchedEffect(phase.uri) { delay(600); finishOk(phase.uri) }
            Phase.Cancelled -> LaunchedEffect(Unit) { finishCanceled() }
            else -> Unit
        }
        BackHandler {
            when (phase) {
                is Phase.Running -> cancelExport()
                is Phase.Failed -> finishCanceled(phase.message)
                else -> finishCanceled()
            }
        }

        val accentColor = Color(accent)
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Surface(
                modifier = Modifier.widthIn(max = 380.dp).fillMaxWidth(),
                shape = RoundedCornerShape(32.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 18.dp,
            ) {
                Column {
                    // ── Bandeau dégradé avec l'icône de l'action ──
                    Box(
                        Modifier.fillMaxWidth().height(116.dp)
                            .background(Brush.linearGradient(listOf(accentColor, lerp(accentColor, Color.Black, 0.40f)))),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(Modifier.align(Alignment.TopEnd).offset(x = 28.dp, y = (-34).dp).size(120.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)))
                        Box(Modifier.align(Alignment.BottomStart).offset(x = (-26).dp, y = 30.dp).size(90.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)))
                        Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                            Text(emoji, fontSize = 36.sp)
                        }
                    }
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Text(label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        if (sourceName.isNotEmpty()) Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant) {
                            Text(
                                sourceName, Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        when (phase) {
                            is Phase.Running -> {
                                val animated by animateFloatAsState(phase.progress.coerceIn(0f, 1f), tween(350), label = "progress")
                                Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(
                                        progress = { 1f }, modifier = Modifier.fillMaxSize(), strokeWidth = 10.dp,
                                        color = accentColor.copy(alpha = 0.14f), trackColor = Color.Transparent,
                                    )
                                    if (phase.progress < 0.005f) CircularProgressIndicator(
                                        modifier = Modifier.fillMaxSize(), strokeWidth = 10.dp, color = accentColor, strokeCap = StrokeCap.Round,
                                    ) else CircularProgressIndicator(
                                        progress = { animated }, modifier = Modifier.fillMaxSize(), strokeWidth = 10.dp,
                                        color = accentColor, trackColor = Color.Transparent, strokeCap = StrokeCap.Round,
                                    )
                                    Text("${(animated * 100).toInt()} %", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    "Traitement en cours, ne quittez pas…",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                OutlinedButton(onClick = ::cancelExport, shape = RoundedCornerShape(50)) { Text("Annuler") }
                            }
                            is Phase.Done -> {
                                var shown by remember { mutableStateOf(false) }
                                LaunchedEffect(Unit) { shown = true }
                                val pop by animateFloatAsState(
                                    if (shown) 1f else 0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "pop"
                                )
                                Box(
                                    Modifier.size(112.dp).scale(pop).clip(CircleShape).background(Color(0xFF1FA463)),
                                    contentAlignment = Alignment.Center,
                                ) { Text("✓", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold) }
                                Text("Terminé !", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            }
                            is Phase.Failed -> {
                                Box(
                                    Modifier.size(88.dp).clip(CircleShape).background(MaterialTheme.colorScheme.errorContainer),
                                    contentAlignment = Alignment.Center,
                                ) { Text("!", color = MaterialTheme.colorScheme.error, fontSize = 44.sp, fontWeight = FontWeight.Bold) }
                                Text(
                                    phase.message, style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center,
                                )
                                Button(onClick = { finishCanceled(phase.message) }, shape = RoundedCornerShape(50)) { Text("Fermer") }
                            }
                            Phase.Cancelled -> Text("Annulé", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }

    private companion object { const val STATE_STARTED = "started" }
}
