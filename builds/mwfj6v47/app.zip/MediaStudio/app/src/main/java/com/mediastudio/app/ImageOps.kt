package com.mediastudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Conversion / compression d'images (JPG, PNG, WebP), orientation EXIF respectée. */
object ImageOps {

    /** Décodage économe en mémoire, réduit à [maxSide] pixels sur le grand côté, redressé selon l'EXIF. */
    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("Image illisible")
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: error("Image illisible")
        orientationMatrix(ctx, uri)?.let { m ->
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val big = maxOf(bmp.width, bmp.height)
        if (big > maxSide) {
            val f = maxSide.toFloat() / big
            bmp = Bitmap.createScaledBitmap(
                bmp, (bmp.width * f).toInt().coerceAtLeast(1), (bmp.height * f).toInt().coerceAtLeast(1), true
            )
        }
        return bmp
    }

    private fun orientationMatrix(ctx: Context, uri: Uri): Matrix? {
        val o = try {
            ctx.contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        } catch (e: Exception) { null } ?: return null
        val (deg, flip) = when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f to false
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f to false
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f to false
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> 0f to true
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180f to true
            ExifInterface.ORIENTATION_TRANSPOSE -> 90f to true
            ExifInterface.ORIENTATION_TRANSVERSE -> 270f to true
            else -> return null
        }
        return Matrix().apply {
            if (flip) postScale(-1f, 1f)
            if (deg != 0f) postRotate(deg)
        }
    }

    @Suppress("DEPRECATION")
    /** [format] : JPG, PNG ou WEBP. [quality] 30..100 (ignorée pour PNG). */
    suspend fun convert(
        ctx: Context, uri: Uri, output: File, format: String, quality: Int, maxSide: Int,
        onProgress: (Float) -> Unit = {}
    ) = withContext(Dispatchers.IO) {
        onProgress(0.1f)
        var bmp = decode(ctx, uri, maxSide)
        onProgress(0.6f)
        if (format == "JPG" && bmp.hasAlpha()) { // pas de transparence en JPEG : fond blanc
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            Canvas(flat).apply { drawColor(Color.WHITE); drawBitmap(bmp, 0f, 0f, null) }
            bmp.recycle()
            bmp = flat
        }
        val (cf, q) = when (format) {
            "PNG" -> Bitmap.CompressFormat.PNG to 100
            "WEBP" -> (if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP) to quality
            else -> Bitmap.CompressFormat.JPEG to quality
        }
        output.outputStream().use { bmp.compress(cf, q, it) }
        bmp.recycle()
        onProgress(1f)
    }
}
