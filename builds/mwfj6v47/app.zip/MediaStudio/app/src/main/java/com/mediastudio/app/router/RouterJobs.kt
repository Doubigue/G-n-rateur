package com.mediastudio.app.router

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import com.mediastudio.app.Clip
import com.mediastudio.app.DocConverters
import com.mediastudio.app.ExportManager
import com.mediastudio.app.ImageOps
import com.mediastudio.app.MediaFrame
import com.mediastudio.app.Mp3Converter
import com.mediastudio.app.VideoOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Routeur interne : transforme une [RouterRequest] validée en [ExportManager.Job], exécuté ensuite par
 * ExportService (premier plan + WakeLock) avec les classes existantes :
 * Mp3Converter, VideoOps (+ ClipEffects via Clip.filter / Clip.text), ImageOps, MediaFrame, DocConverters,
 * puis Saver (via ExportService).
 *
 * Toutes les opérations vidéo conservent le son d'origine (sauf « retirer le son » / « remplacer le son »).
 */
@UnstableApi
internal object RouterJobs {

    private const val MP4 = "video/mp4"

    fun build(app: Context, req: RouterRequest, base: String): ExportManager.Job {
        val t = System.currentTimeMillis()
        return when (req) {
            is RouterRequest.ToMp3 -> ExportManager.Job("${base}_$t.mp3", "audio/mpeg") { out, report ->
                Mp3Converter.convert(app, req.source, out, req.bitrateKbps, report)
            }

            is RouterRequest.Compress -> ExportManager.Job("${base}_${req.maxHeight}p_$t.mp4", MP4) { out, report ->
                val clip = clipOf(app, req.source, req.startMs, req.endMs)
                VideoOps.compress(app, clip, out, req.maxHeight, req.videoBitrate, report)
            }

            is RouterRequest.Effect -> {
                val tag = if (req.filter.name != "NONE") req.filter.name.lowercase() else "texte"
                ExportManager.Job("${base}_${tag}_$t.mp4", MP4) { out, report ->
                    // ClipEffects.videoEffects() lit filter / text / textPos du Clip
                    val clip = clipOf(app, req.source, req.startMs, req.endMs)
                        .copy(filter = req.filter, text = req.text, textPos = req.textPos)
                    VideoOps.applyEffects(app, clip, out, maxHeight = null, onProgress = report)
                }
            }

            is RouterRequest.Mix -> ExportManager.Job("${base}_mix_$t.mp4", MP4) { out, report ->
                val video = clipOf(app, req.video)
                val music = clipOf(app, req.music)
                VideoOps.mixMusic(app, video, music, out, req.keepOriginalAudio, req.videoVolume, req.musicVolume, report)
            }

            is RouterRequest.Concat -> ExportManager.Job("montage_$t.mp4", MP4) { out, report ->
                val clips = req.clips.map { clipOf(app, it) }
                VideoOps.concat(app, clips, out, req.fade, onProgress = report)
            }

            is RouterRequest.Transform -> ExportManager.Job("${base}_pivot_$t.mp4", MP4) { out, report ->
                VideoOps.transform(app, clipOf(app, req.source), out, req.rotateDeg, req.flipH, report)
            }

            is RouterRequest.Speed -> {
                val tag = req.speed.toString().replace('.', '_')
                ExportManager.Job("${base}_x${tag}_$t.mp4", MP4) { out, report ->
                    VideoOps.speed(app, clipOf(app, req.source), out, req.speed, report)
                }
            }

            is RouterRequest.Volume ->
                if (req.audioOnly) ExportManager.Job("${base}_volume_$t.m4a", "audio/mp4") { out, report ->
                    VideoOps.volume(app, clipOf(app, req.source), out, req.volume, report)
                } else ExportManager.Job("${base}_volume_$t.mp4", MP4) { out, report ->
                    VideoOps.volume(app, clipOf(app, req.source), out, req.volume, report)
                }

            is RouterRequest.Mute -> ExportManager.Job("${base}_muet_$t.mp4", MP4) { out, report ->
                VideoOps.mute(app, clipOf(app, req.source), out, report)
            }

            is RouterRequest.Frame -> ExportManager.Job("${base}_image_$t.jpg", "image/jpeg") { out, report ->
                MediaFrame.extract(app, req.source, req.atMs, out, report)
            }

            is RouterRequest.ImageConvert -> {
                val (ext, mime) = when (req.format) {
                    "PNG" -> "png" to "image/png"
                    "WEBP" -> "webp" to "image/webp"
                    else -> "jpg" to "image/jpeg"
                }
                ExportManager.Job("${base}_$t.$ext", mime) { out, report ->
                    ImageOps.convert(app, req.source, out, req.format, req.quality, req.maxSide, report)
                }
            }

            is RouterRequest.ImagesToPdf -> ExportManager.Job("images_$t.pdf", "application/pdf") { out, report ->
                DocConverters.imagesToPdf(app, req.images, out, report)
            }

            is RouterRequest.WordToPdf -> ExportManager.Job("${base}_$t.pdf", "application/pdf") { out, report ->
                DocConverters.wordToPdf(app, req.source, out, report)
            }

            is RouterRequest.PdfToWord -> ExportManager.Job("${base}_$t.docx", DocConverters.DOCX_MIME) { out, report ->
                DocConverters.pdfToWord(app, req.source, out, report)
            }

            is RouterRequest.TextToPdf -> ExportManager.Job("${base}_$t.pdf", "application/pdf") { out, report ->
                DocConverters.textToPdf(app, req.source, out, report)
            }
        }
    }

    /** Lecture des métadonnées hors du thread principal (le bloc du Job s'exécute sur Main dans le service). */
    private suspend fun clipOf(ctx: Context, uri: Uri, startMs: Long = -1, endMs: Long = -1): Clip {
        val c = withContext(Dispatchers.IO) { Clip.from(ctx, uri) }
        if (c.durationMs <= 0) error("Durée du média illisible")
        if (startMs < 0 && endMs < 0) return c
        val s = startMs.coerceIn(0, c.durationMs - 1)
        val e = (if (endMs > 0) endMs else c.durationMs).coerceIn(s + 1, c.durationMs)
        return c.copy(startMs = s, endMs = e)
    }
}
