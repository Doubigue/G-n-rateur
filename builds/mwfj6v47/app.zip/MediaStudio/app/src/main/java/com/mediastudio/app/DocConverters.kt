package com.mediastudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.util.Xml
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Conversions de documents, 100 % hors-ligne :
 *  - Word (.docx) → PDF : texte, titres, gras/italique/souligné, couleurs, tailles, alignements, listes, tableaux (texte) et images ;
 *  - PDF → Word (.docx) : texte modifiable (PDFBox) ; PDF scanné (sans texte) → pages en images dans le .docx ;
 *  - Texte (.txt) → PDF ; images → un seul PDF.
 */
object DocConverters {

    const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

    private const val PAGE_W = 595 // A4 en points (72 dpi)
    private const val PAGE_H = 842
    private const val MARGIN = 56

    // ───────────────────────────── Word → PDF ─────────────────────────────

    suspend fun wordToPdf(ctx: Context, input: Uri, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            val tmp = copyToCache(ctx, input, ".docx")
            try {
                onProgress(0.05f)
                val blocks = DocxReader.read(tmp)
                writePdf(blocks, output, onProgress)
            } finally { tmp.delete() }
        }

    suspend fun textToPdf(ctx: Context, input: Uri, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            val text = ctx.contentResolver.openInputStream(input)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: error("Fichier illisible")
            val blocks = text.replace("\r\n", "\n").split('\n').map {
                Block.Para(SpannableStringBuilder(it), Layout.Alignment.ALIGN_NORMAL, 0, false, 0f)
            }
            writePdf(blocks, output, onProgress)
        }

    suspend fun imagesToPdf(ctx: Context, uris: List<Uri>, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            val doc = PdfDocument()
            try {
                uris.forEachIndexed { i, u ->
                    val bmp = ImageOps.decode(ctx, u, 2200)
                    val landscape = bmp.width > bmp.height
                    val pw = if (landscape) PAGE_H else PAGE_W
                    val ph = if (landscape) PAGE_W else PAGE_H
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
                    val m = 24f
                    val s = min((pw - 2 * m) / bmp.width, (ph - 2 * m) / bmp.height)
                    val w = bmp.width * s
                    val h = bmp.height * s
                    val left = (pw - w) / 2
                    val top = (ph - h) / 2
                    page.canvas.drawColor(Color.WHITE)
                    page.canvas.drawBitmap(bmp, null, RectF(left, top, left + w, top + h), Paint(Paint.FILTER_BITMAP_FLAG))
                    doc.finishPage(page)
                    bmp.recycle()
                    onProgress((i + 1f) / uris.size)
                }
                output.outputStream().use { doc.writeTo(it) }
            } finally { doc.close() }
        }

    // ───────────────────────────── PDF → Word ─────────────────────────────

    suspend fun pdfToWord(ctx: Context, input: Uri, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            PDFBoxResourceLoader.init(ctx.applicationContext)
            val tmp = copyToCache(ctx, input, ".pdf")
            try {
                val pages = ArrayList<List<String>>()
                try {
                    PDDocument.load(tmp).use { doc ->
                        val n = doc.numberOfPages
                        val stripper = PDFTextStripper().apply { sortByPosition = true }
                        for (p in 1..n) {
                            stripper.startPage = p
                            stripper.endPage = p
                            pages += mergeLines(stripper.getText(doc))
                            onProgress(0.7f * p / n)
                        }
                    }
                } catch (e: InvalidPasswordException) {
                    error("PDF protégé par mot de passe")
                }
                val hasText = pages.any { page -> page.any { it.isNotBlank() } }
                if (hasText) DocxWriter.writeText(pages, output)
                else DocxWriter.writeScanned(renderPages(tmp) { onProgress(0.1f + 0.85f * it) }, output) // PDF scanné
                onProgress(1f)
            } finally { tmp.delete() }
        }

    /** Recolle les lignes d'un même paragraphe (une ligne courte ou finissant par une ponctuation termine le paragraphe). */
    private fun mergeLines(text: String): List<String> {
        val lines = text.lines().map { it.trimEnd() }
        val maxLen = lines.maxOfOrNull { it.length } ?: 0
        val out = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotEmpty()) { out += cur.toString(); cur.clear() } }
        for (l in lines) {
            if (l.isBlank()) { flush(); continue }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(l.trim())
            val longLine = l.length >= maxLen * 0.7
            val endsSentence = l.lastOrNull()?.let { it in ".:!?;)" } == true
            if (!longLine || endsSentence) flush()
        }
        flush()
        return out
    }

    /** Pages du PDF rendues en JPEG (pour les PDF scannés). */
    private fun renderPages(pdf: File, progress: (Float) -> Unit): List<ByteArray> {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val out = ArrayList<ByteArray>()
        PdfRenderer(pfd).use { r ->
            for (i in 0 until r.pageCount) {
                r.openPage(i).use { page ->
                    val w = 1240
                    val h = (w.toFloat() * page.height / page.width).roundToInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val bos = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, bos)
                    bmp.recycle()
                    out.add(bos.toByteArray())
                }
                progress((i + 1f) / r.pageCount)
            }
        }
        pfd.close()
        return out
    }

    private fun copyToCache(ctx: Context, uri: Uri, suffix: String): File {
        val tmp = File.createTempFile("conv", suffix, ctx.cacheDir)
        ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { i.copyTo(it) } }
            ?: error("Fichier illisible")
        return tmp
    }

    // ───────────────────────────── Mise en page PDF ─────────────────────────────

    internal sealed interface Block {
        class Para(
            val text: SpannableStringBuilder, val align: Layout.Alignment, val heading: Int,
            val bullet: Boolean, val indentPt: Float
        ) : Block
        class Pic(val bitmap: Bitmap, val wPt: Float, val hPt: Float) : Block
        data object PageBreak : Block
    }

    private fun writePdf(blocks: List<Block>, output: File, onProgress: (Float) -> Unit) {
        val doc = PdfDocument()
        try {
            val pager = Pager(doc)
            blocks.forEachIndexed { i, b ->
                when (b) {
                    is Block.Para -> pager.para(b)
                    is Block.Pic -> pager.pic(b)
                    Block.PageBreak -> pager.newPage()
                }
                onProgress(0.05f + 0.95f * (i + 1f) / blocks.size)
            }
            pager.close()
            if (doc.pages.isEmpty()) error("Document vide")
            output.outputStream().use { doc.writeTo(it) }
        } finally { doc.close() }
    }

    private class Pager(private val doc: PdfDocument) {
        private var pageNo = 0
        private var page: PdfDocument.Page? = null
        private var y = MARGIN.toFloat()
        private val bottom = (PAGE_H - MARGIN).toFloat()
        private val width = PAGE_W - 2 * MARGIN

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            y = MARGIN.toFloat()
        }

        fun close() { page?.let { doc.finishPage(it) }; page = null }

        private fun canvas(): Canvas { if (page == null) newPage(); return page!!.canvas }

        fun para(p: Block.Para) {
            canvas()
            val size = when (p.heading) { 1 -> 22f; 2 -> 18f; 3 -> 15f; 0 -> 11f; else -> 13f }
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size; color = Color.BLACK; typeface = Typeface.SANS_SERIF
            }
            val text = SpannableStringBuilder()
            if (p.bullet) text.append("•  ")
            text.append(p.text)
            if (p.heading > 0 && text.isNotEmpty())
                text.setSpan(StyleSpan(Typeface.BOLD), 0, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            val indent = p.indentPt + if (p.bullet) 14f else 0f
            val w = (width - indent).toInt().coerceAtLeast(60)
            if (p.heading > 0) y += 6f
            if (text.isEmpty()) {
                y += size * 1.25f
                if (y > bottom) newPage()
                return
            }
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, w)
                .setAlignment(p.align).setLineSpacing(0f, 1.15f).setIncludePad(false).build()
            var line = 0
            while (line < layout.lineCount) {
                var last = line - 1
                val avail = bottom - y
                while (last + 1 < layout.lineCount && layout.getLineBottom(last + 1) - layout.getLineTop(line) <= avail) last++
                if (last < line) {
                    if (y > MARGIN + 1f) { newPage(); continue } else last = line // ligne plus haute que la page
                }
                val top = layout.getLineTop(line)
                val bot = layout.getLineBottom(last)
                val c = canvas()
                c.save()
                c.translate(MARGIN + indent, y - top)
                c.clipRect(0f, top.toFloat(), w.toFloat(), bot.toFloat())
                layout.draw(c)
                c.restore()
                y += (bot - top)
                line = last + 1
                if (line < layout.lineCount) newPage()
            }
            y += 6f
        }

        fun pic(b: Block.Pic) {
            canvas()
            var w = if (b.wPt > 1f) b.wPt else b.bitmap.width * 0.75f
            var h = if (b.hPt > 1f) b.hPt else b.bitmap.height * 0.75f
            val scale = minOf(1f, width / w, (bottom - MARGIN) / h)
            w *= scale
            h *= scale
            if (y + h > bottom) newPage()
            page!!.canvas.drawBitmap(b.bitmap, null, RectF(MARGIN.toFloat(), y, MARGIN + w, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
            y += h + 8f
        }
    }

    // ───────────────────────────── Lecture du .docx ─────────────────────────────

    private object DocxReader {
        fun read(file: File): List<Block> = ZipFile(file).use { zip ->
            val docEntry = zip.getEntry("word/document.xml") ?: error("Ce fichier n'est pas un document Word (.docx)")
            val rels = readRels(zip)
            val blocks = ArrayList<Block>()

            val p = Xml.newPullParser()
            p.setInput(zip.getInputStream(docEntry), "UTF-8")

            var sb = SpannableStringBuilder()
            var align = Layout.Alignment.ALIGN_NORMAL
            var heading = 0
            var bullet = false
            var ilvl = 0
            var inRun = false
            var inText = false
            var runStart = 0
            var bold = false; var italic = false; var underline = false
            var sizeHalfPt = 0
            var color = -1
            var pageBreakAfter = false
            var tableDepth = 0
            val cell = StringBuilder()
            val rowCells = ArrayList<String>()
            var picW = 0f; var picH = 0f
            val pics = ArrayList<Block.Pic>()

            fun on(v: String?) = v == null || (v != "0" && v != "false" && v != "none")

            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "w:p" -> { sb = SpannableStringBuilder(); align = Layout.Alignment.ALIGN_NORMAL; heading = 0; bullet = false; ilvl = 0; pageBreakAfter = false; pics.clear() }
                        "w:pStyle" -> heading = headingOf(p.getAttributeValue(null, "w:val"))
                        "w:jc" -> align = when (p.getAttributeValue(null, "w:val")) {
                            "center" -> Layout.Alignment.ALIGN_CENTER
                            "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                            else -> Layout.Alignment.ALIGN_NORMAL
                        }
                        "w:numPr" -> bullet = true
                        "w:ilvl" -> ilvl = p.getAttributeValue(null, "w:val")?.toIntOrNull() ?: 0
                        "w:r" -> { inRun = true; runStart = sb.length; bold = false; italic = false; underline = false; sizeHalfPt = 0; color = -1 }
                        "w:b" -> if (inRun) bold = on(p.getAttributeValue(null, "w:val"))
                        "w:i" -> if (inRun) italic = on(p.getAttributeValue(null, "w:val"))
                        "w:u" -> if (inRun) underline = on(p.getAttributeValue(null, "w:val"))
                        "w:sz" -> if (inRun) sizeHalfPt = p.getAttributeValue(null, "w:val")?.toIntOrNull() ?: 0
                        "w:color" -> if (inRun) color = p.getAttributeValue(null, "w:val")?.toIntOrNull(16)?.let { 0xFF000000.toInt() or it } ?: -1
                        "w:t" -> inText = true
                        "w:tab" -> if (inRun) sb.append('\t')
                        "w:br", "w:cr" -> if (inRun) {
                            if (p.getAttributeValue(null, "w:type") == "page") pageBreakAfter = true else sb.append('\n')
                        }
                        "w:tbl" -> tableDepth++
                        "w:tr" -> rowCells.clear()
                        "w:tc" -> cell.clear()
                        "wp:extent" -> {
                            picW = (p.getAttributeValue(null, "cx")?.toLongOrNull() ?: 0L) / 12700f
                            picH = (p.getAttributeValue(null, "cy")?.toLongOrNull() ?: 0L) / 12700f
                        }
                        "a:blip" -> p.getAttributeValue(null, "r:embed")?.let { id ->
                            rels[id]?.let { target -> loadImage(zip, target) }?.let { pics.add(Block.Pic(it, picW, picH)) }
                        }
                    }
                    XmlPullParser.TEXT -> if (inText) sb.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) {
                        "w:t" -> inText = false
                        "w:r" -> {
                            val end = sb.length
                            if (end > runStart) {
                                val f = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), runStart, end, f)
                                if (italic) sb.setSpan(StyleSpan(Typeface.ITALIC), runStart, end, f)
                                if (underline) sb.setSpan(UnderlineSpan(), runStart, end, f)
                                if (sizeHalfPt > 0) sb.setSpan(AbsoluteSizeSpan((sizeHalfPt / 2f).roundToInt(), false), runStart, end, f)
                                if (color != -1) sb.setSpan(ForegroundColorSpan(color), runStart, end, f)
                            }
                            inRun = false
                        }
                        "w:p" -> {
                            if (tableDepth > 0) {
                                if (cell.isNotEmpty()) cell.append(' ')
                                cell.append(sb.toString().trim())
                            } else {
                                blocks += Block.Para(sb, align, heading, bullet, ilvl * 18f)
                                blocks += pics
                                pics.clear()
                                if (pageBreakAfter) blocks += Block.PageBreak
                            }
                        }
                        "w:tc" -> rowCells += cell.toString().trim()
                        "w:tr" -> blocks += Block.Para(
                            SpannableStringBuilder(rowCells.joinToString("   |   ")),
                            Layout.Alignment.ALIGN_NORMAL, 0, false, 0f
                        )
                        "w:tbl" -> if (tableDepth > 0) tableDepth--
                    }
                }
                ev = p.next()
            }
            if (blocks.isEmpty()) error("Document vide")
            blocks
        }

        private fun headingOf(style: String?): Int {
            val v = style ?: return 0
            Regex("(?i)^(heading|titre)\\s*([1-6])$").find(v)?.let { return it.groupValues[2].toInt() }
            return if (v.equals("Title", true) || v.equals("Titre", true)) 1 else 0
        }

        private fun readRels(zip: ZipFile): Map<String, String> {
            val e = zip.getEntry("word/_rels/document.xml.rels") ?: return emptyMap()
            val map = HashMap<String, String>()
            val p = Xml.newPullParser()
            p.setInput(zip.getInputStream(e), "UTF-8")
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                    val id = p.getAttributeValue(null, "Id")
                    val target = p.getAttributeValue(null, "Target")
                    if (id != null && target != null) map[id] = target
                }
                ev = p.next()
            }
            return map
        }

        private fun loadImage(zip: ZipFile, target: String): Bitmap? {
            val path = if (target.startsWith("/")) target.removePrefix("/") else "word/$target"
            val e = zip.getEntry(path) ?: return null
            val bytes = zip.getInputStream(e).use { it.readBytes() }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0) return null // EMF / WMF non pris en charge
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1800) sample *= 2
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    }

    // ───────────────────────────── Écriture du .docx ─────────────────────────────

    private object DocxWriter {
        private const val NS = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
            "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\""

        private const val SECT = "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>"

        fun writeText(pages: List<List<String>>, output: File) {
            val body = StringBuilder()
            pages.forEachIndexed { i, paras ->
                if (i > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
                paras.forEach {
                    body.append("<w:p><w:r><w:rPr><w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\"/><w:sz w:val=\"22\"/></w:rPr>")
                        .append("<w:t xml:space=\"preserve\">").append(esc(it)).append("</w:t></w:r></w:p>")
                }
            }
            write(output, body.toString(), emptyList())
        }

        /** PDF scanné : une image JPEG par page. */
        fun writeScanned(jpegs: List<ByteArray>, output: File) {
            val body = StringBuilder()
            jpegs.forEachIndexed { i, bytes ->
                val id = i + 1
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                val cx = 6_000_000L
                val cy = cx * opts.outHeight / maxOf(opts.outWidth, 1)
                if (i > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
                body.append(
                    "<w:p><w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
                        "<wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:docPr id=\"$id\" name=\"Page $id\"/>" +
                        "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                        "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"$id\" name=\"page$id.jpg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                        "<pic:blipFill><a:blip r:embed=\"rId$id\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                        "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm>" +
                        "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
                        "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"
                )
            }
            write(output, body.toString(), jpegs)
        }

        private fun write(output: File, body: String, images: List<ByteArray>) {
            ZipOutputStream(output.outputStream().buffered()).use { z ->
                fun put(name: String, data: ByteArray) {
                    z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry()
                }
                val hdr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                put(
                    "[Content_Types].xml",
                    ("$hdr<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                        "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                        "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                        "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
                        "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                        "</Types>").toByteArray()
                )
                put(
                    "_rels/.rels",
                    ("$hdr<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                        "</Relationships>").toByteArray()
                )
                put("word/document.xml", "$hdr<w:document $NS><w:body>$body$SECT</w:body></w:document>".toByteArray())
                if (images.isNotEmpty()) {
                    val rels = StringBuilder("$hdr<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
                    images.forEachIndexed { i, bytes ->
                        val id = i + 1
                        rels.append("<Relationship Id=\"rId$id\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/page$id.jpg\"/>")
                        put("word/media/page$id.jpg", bytes)
                    }
                    rels.append("</Relationships>")
                    put("word/_rels/document.xml.rels", rels.toString().toByteArray())
                }
            }
        }

        /** Échappement XML + suppression des caractères interdits. */
        private fun esc(s: String): String = buildString(s.length + 16) {
            for (c in s) when {
                c == '&' -> append("&amp;")
                c == '<' -> append("&lt;")
                c == '>' -> append("&gt;")
                c.code < 0x20 && c != '\t' && c != '\n' && c != '\r' -> {}
                else -> append(c)
            }
        }
    }
}
