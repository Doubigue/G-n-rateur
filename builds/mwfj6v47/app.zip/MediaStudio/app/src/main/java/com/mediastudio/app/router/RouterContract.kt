package com.mediastudio.app.router

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import com.mediastudio.app.Filter
import com.mediastudio.app.TextPos

/**
 * Contrat d'Intent entre les applis clientes (LinkShare) et [com.mediastudio.app.MediaStudioRouterActivity].
 *
 * L'appelant envoie un Intent EXPLICITE (composant + action ci-dessous), les fichiers en `content://`
 * (data + ClipData) et FLAG_GRANT_READ_URI_PERMISSION. Il lance l'activité avec startActivityForResult
 * (Activity Result API) : MediaStudio peut ainsi vérifier l'appelant et lui renvoyer le résultat.
 */
object RouterContract {
    // Audio / vidéo
    const val ACTION_TO_MP3 = "com.mediastudio.app.action.TO_MP3"
    const val ACTION_COMPRESS = "com.mediastudio.app.action.COMPRESS_VIDEO"
    const val ACTION_EFFECT = "com.mediastudio.app.action.APPLY_EFFECT"
    const val ACTION_MIX = "com.mediastudio.app.action.MIX_MUSIC"
    const val ACTION_CONCAT = "com.mediastudio.app.action.CONCAT"
    const val ACTION_TRANSFORM = "com.mediastudio.app.action.TRANSFORM"   // rotation / miroir
    const val ACTION_SPEED = "com.mediastudio.app.action.SPEED"           // ralenti / accéléré
    const val ACTION_VOLUME = "com.mediastudio.app.action.VOLUME"         // volume (audio ou vidéo)
    const val ACTION_MUTE = "com.mediastudio.app.action.MUTE"             // retirer le son
    const val ACTION_FRAME = "com.mediastudio.app.action.FRAME"           // capture d'image d'une vidéo
    // Images
    const val ACTION_IMAGE = "com.mediastudio.app.action.IMAGE"           // convertir / compresser
    const val ACTION_IMAGES_TO_PDF = "com.mediastudio.app.action.IMAGES_TO_PDF"
    // Documents
    const val ACTION_WORD_TO_PDF = "com.mediastudio.app.action.WORD_TO_PDF"
    const val ACTION_PDF_TO_WORD = "com.mediastudio.app.action.PDF_TO_WORD"
    const val ACTION_TEXT_TO_PDF = "com.mediastudio.app.action.TEXT_TO_PDF"

    // Paramètres (tous optionnels, bornés côté MediaStudio)
    const val EXTRA_BITRATE_KBPS = "bitrate_kbps"      // Int   – MP3 (64..320, défaut 192)
    const val EXTRA_MAX_HEIGHT = "max_height"          // Int   – compression (240..2160, défaut 720)
    const val EXTRA_VIDEO_BITRATE = "video_bitrate"    // Int   – bits/s (défaut 2 000 000)
    const val EXTRA_FILTER = "filter"                  // String – nom de l'enum Filter (NOIR, WARM…)
    const val EXTRA_TEXT = "overlay_text"              // String – texte incrusté (120 car. max)
    const val EXTRA_TEXT_POS = "text_pos"              // String – TOP | MIDDLE | BOTTOM
    const val EXTRA_START_MS = "start_ms"              // Long  – découpe (début)
    const val EXTRA_END_MS = "end_ms"                  // Long  – découpe (fin)
    const val EXTRA_KEEP_AUDIO = "keep_original_audio" // Boolean – mixage
    const val EXTRA_VIDEO_VOLUME = "video_volume"      // Float 0..2
    const val EXTRA_MUSIC_VOLUME = "music_volume"      // Float 0..2
    const val EXTRA_FADE = "fade"                      // Boolean – assemblage avec fondu
    const val EXTRA_ROTATE_DEG = "rotate_deg"          // Int   – 0 / 90 / 180 / 270 (sens horaire)
    const val EXTRA_FLIP_H = "flip_h"                  // Boolean – miroir horizontal
    const val EXTRA_SPEED = "speed"                    // Float 0.25..4
    const val EXTRA_VOLUME = "volume"                  // Float 0..3
    const val EXTRA_TIME_MS = "time_ms"                // Long  – instant de la capture (défaut : milieu)
    const val EXTRA_IMG_FORMAT = "img_format"          // String – AUTO | JPG | PNG | WEBP
    const val EXTRA_IMG_QUALITY = "img_quality"        // Int   – 30..100
    const val EXTRA_IMG_MAX_SIDE = "img_max_side"      // Int   – 256..6000

    // Résultat renvoyé à l'appelant
    const val EXTRA_OUTPUT_NAME = "output_name"        // String – nom du fichier produit (RESULT_OK, data = URI MediaStore)
    const val EXTRA_ERROR = "error"                    // String – message d'erreur (RESULT_CANCELED)
}

class RouterException(message: String) : Exception(message)

private const val AUDIO_COLOR = 0xFF7C4DFF
private const val VIDEO_COLOR = 0xFFFF6D3F
private const val IMAGE_COLOR = 0xFF00B8A9
private const val DOC_COLOR = 0xFF2F80ED

/** Requête validée : plus aucune donnée brute de l'Intent n'est utilisée après [RouterParser.parse]. */
sealed class RouterRequest(val label: String, val emoji: String, val accent: Long, val sources: List<Uri>) {

    class ToMp3(val source: Uri, val bitrateKbps: Int) :
        RouterRequest("Conversion en MP3", "🎵", AUDIO_COLOR, listOf(source))

    class Compress(val source: Uri, val maxHeight: Int, val videoBitrate: Int, val startMs: Long, val endMs: Long) :
        RouterRequest("Compression de la vidéo", "🗜️", VIDEO_COLOR, listOf(source))

    class Effect(
        val source: Uri, val filter: Filter, val text: String, val textPos: TextPos, val startMs: Long, val endMs: Long
    ) : RouterRequest("Application des effets", "✨", VIDEO_COLOR, listOf(source))

    class Mix(val video: Uri, val music: Uri, val keepOriginalAudio: Boolean, val videoVolume: Float, val musicVolume: Float) :
        RouterRequest("Mixage musique + vidéo", "🎶", VIDEO_COLOR, listOf(video, music))

    class Concat(val clips: List<Uri>, val fade: Boolean) :
        RouterRequest("Assemblage des vidéos", "🎞️", VIDEO_COLOR, clips)

    class Transform(val source: Uri, val rotateDeg: Int, val flipH: Boolean) :
        RouterRequest(if (flipH && rotateDeg == 0) "Miroir de la vidéo" else "Rotation de la vidéo", "🔄", VIDEO_COLOR, listOf(source))

    class Speed(val source: Uri, val speed: Float) :
        RouterRequest(if (speed < 1f) "Ralenti de la vidéo" else "Accéléré de la vidéo", "⏩", VIDEO_COLOR, listOf(source))

    class Volume(val source: Uri, val volume: Float, val audioOnly: Boolean) :
        RouterRequest("Réglage du volume", "🔊", if (audioOnly) AUDIO_COLOR else VIDEO_COLOR, listOf(source))

    class Mute(val source: Uri) : RouterRequest("Suppression du son", "🔇", VIDEO_COLOR, listOf(source))

    class Frame(val source: Uri, val atMs: Long) : RouterRequest("Capture d'image", "📸", VIDEO_COLOR, listOf(source))

    class ImageConvert(val source: Uri, val format: String, val quality: Int, val maxSide: Int) :
        RouterRequest("Conversion de l'image", "🖼️", IMAGE_COLOR, listOf(source))

    class ImagesToPdf(val images: List<Uri>) : RouterRequest("Création du PDF", "📚", IMAGE_COLOR, images)

    class WordToPdf(val source: Uri) : RouterRequest("Word → PDF", "📄", DOC_COLOR, listOf(source))

    class PdfToWord(val source: Uri) : RouterRequest("PDF → Word", "📝", DOC_COLOR, listOf(source))

    class TextToPdf(val source: Uri) : RouterRequest("Texte → PDF", "📄", DOC_COLOR, listOf(source))
}

object RouterParser {
    private const val MAX_SOURCES = 50

    fun parse(ctx: Context, intent: Intent): RouterRequest {
        val uris = collectUris(intent)
        if (uris.isEmpty()) throw RouterException("Aucun fichier reçu.")
        val types = uris.map { mimeOf(ctx, it, intent) }
        val names = uris.map { displayName(ctx, it).orEmpty().lowercase() }

        fun need(ok: Boolean, msg: String) { if (!ok) throw RouterException(msg) }
        fun isVideo(i: Int) = types[i].startsWith("video/")
        fun isAudio(i: Int) = types[i].startsWith("audio/")
        fun isImage(i: Int) = types[i].startsWith("image/")
        fun isWord(i: Int) = types[i].contains("wordprocessingml") || names[i].endsWith(".docx")
        fun isPdf(i: Int) = types[i] == "application/pdf" || names[i].endsWith(".pdf")
        fun isText(i: Int) = types[i].startsWith("text/") || names[i].endsWith(".txt") || names[i].endsWith(".md")
        fun one(msg: String, ok: (Int) -> Boolean) = need(uris.size == 1 && ok(0), msg)

        fun long(key: String) = intent.getLongExtra(key, -1L)

        return when (intent.action) {
            RouterContract.ACTION_TO_MP3 -> {
                one("Fichier audio ou vidéo attendu.") { isAudio(it) || isVideo(it) }
                RouterRequest.ToMp3(uris[0], intent.getIntExtra(RouterContract.EXTRA_BITRATE_KBPS, 192).coerceIn(64, 320))
            }
            RouterContract.ACTION_COMPRESS -> {
                one("Une vidéo est attendue.", ::isVideo)
                RouterRequest.Compress(
                    uris[0],
                    intent.getIntExtra(RouterContract.EXTRA_MAX_HEIGHT, 720).coerceIn(240, 2160),
                    intent.getIntExtra(RouterContract.EXTRA_VIDEO_BITRATE, 2_000_000).coerceIn(300_000, 40_000_000),
                    long(RouterContract.EXTRA_START_MS), long(RouterContract.EXTRA_END_MS),
                )
            }
            RouterContract.ACTION_EFFECT -> {
                one("Une vidéo est attendue.", ::isVideo)
                val filter = Filter.entries.firstOrNull { it.name == intent.getStringExtra(RouterContract.EXTRA_FILTER) } ?: Filter.NONE
                val text = intent.getStringExtra(RouterContract.EXTRA_TEXT).orEmpty().trim().take(120)
                need(filter != Filter.NONE || text.isNotEmpty(), "Aucun effet demandé.")
                val pos = TextPos.entries.firstOrNull { it.name == intent.getStringExtra(RouterContract.EXTRA_TEXT_POS) } ?: TextPos.BOTTOM
                RouterRequest.Effect(uris[0], filter, text, pos, long(RouterContract.EXTRA_START_MS), long(RouterContract.EXTRA_END_MS))
            }
            RouterContract.ACTION_MIX -> {
                need(uris.size == 2, "Une vidéo et une musique sont attendues.")
                val v = types.indices.firstOrNull(::isVideo)
                val a = types.indices.firstOrNull(::isAudio)
                need(v != null && a != null, "Une vidéo et une musique sont attendues.")
                RouterRequest.Mix(
                    uris[v!!], uris[a!!],
                    intent.getBooleanExtra(RouterContract.EXTRA_KEEP_AUDIO, true),
                    intent.getFloatExtra(RouterContract.EXTRA_VIDEO_VOLUME, 1f).coerceIn(0f, 2f),
                    intent.getFloatExtra(RouterContract.EXTRA_MUSIC_VOLUME, 0.8f).coerceIn(0f, 2f),
                )
            }
            RouterContract.ACTION_CONCAT -> {
                need(uris.size >= 2, "Au moins deux vidéos sont nécessaires.")
                need(types.indices.all(::isVideo), "Seules des vidéos peuvent être assemblées.")
                RouterRequest.Concat(uris, intent.getBooleanExtra(RouterContract.EXTRA_FADE, false))
            }
            RouterContract.ACTION_TRANSFORM -> {
                one("Une vidéo est attendue.", ::isVideo)
                val deg = (intent.getIntExtra(RouterContract.EXTRA_ROTATE_DEG, 0) / 90 * 90).mod(360)
                val flip = intent.getBooleanExtra(RouterContract.EXTRA_FLIP_H, false)
                need(deg != 0 || flip, "Aucune transformation demandée.")
                RouterRequest.Transform(uris[0], deg, flip)
            }
            RouterContract.ACTION_SPEED -> {
                one("Une vidéo est attendue.", ::isVideo)
                RouterRequest.Speed(uris[0], intent.getFloatExtra(RouterContract.EXTRA_SPEED, 1f).coerceIn(0.25f, 4f))
            }
            RouterContract.ACTION_VOLUME -> {
                one("Un fichier audio ou vidéo est attendu.") { isAudio(it) || isVideo(it) }
                RouterRequest.Volume(uris[0], intent.getFloatExtra(RouterContract.EXTRA_VOLUME, 1f).coerceIn(0f, 3f), isAudio(0))
            }
            RouterContract.ACTION_MUTE -> {
                one("Une vidéo est attendue.", ::isVideo)
                RouterRequest.Mute(uris[0])
            }
            RouterContract.ACTION_FRAME -> {
                one("Une vidéo est attendue.", ::isVideo)
                RouterRequest.Frame(uris[0], long(RouterContract.EXTRA_TIME_MS))
            }
            RouterContract.ACTION_IMAGE -> {
                one("Une image est attendue.", ::isImage)
                val requested = intent.getStringExtra(RouterContract.EXTRA_IMG_FORMAT)?.uppercase()
                val format = when (requested) {
                    "JPG", "PNG", "WEBP" -> requested.orEmpty()
                    else -> if (types[0].contains("png")) "PNG" else "JPG" // AUTO : un PNG reste un PNG
                }
                RouterRequest.ImageConvert(
                    uris[0], format,
                    intent.getIntExtra(RouterContract.EXTRA_IMG_QUALITY, 85).coerceIn(30, 100),
                    intent.getIntExtra(RouterContract.EXTRA_IMG_MAX_SIDE, 6000).coerceIn(256, 6000),
                )
            }
            RouterContract.ACTION_IMAGES_TO_PDF -> {
                need(types.indices.all(::isImage), "Seules des images peuvent être converties en PDF.")
                RouterRequest.ImagesToPdf(uris)
            }
            RouterContract.ACTION_WORD_TO_PDF -> {
                one("Un document Word (.docx) est attendu. Les anciens .doc ne sont pas pris en charge.", ::isWord)
                RouterRequest.WordToPdf(uris[0])
            }
            RouterContract.ACTION_PDF_TO_WORD -> {
                one("Un fichier PDF est attendu.", ::isPdf)
                RouterRequest.PdfToWord(uris[0])
            }
            RouterContract.ACTION_TEXT_TO_PDF -> {
                one("Un fichier texte est attendu.", ::isText)
                RouterRequest.TextToPdf(uris[0])
            }
            else -> throw RouterException("Action non prise en charge.")
        }
    }

    /** data + ClipData, sans doublon, ordre conservé ; uniquement des content:// (jamais file://). */
    private fun collectUris(intent: Intent): List<Uri> {
        val out = LinkedHashSet<Uri>()
        intent.data?.let(out::add)
        intent.clipData?.let { c -> for (i in 0 until c.itemCount) c.getItemAt(i).uri?.let(out::add) }
        if (out.size > MAX_SOURCES) throw RouterException("Trop de fichiers (maximum $MAX_SOURCES).")
        if (out.any { it.scheme != ContentResolver.SCHEME_CONTENT }) throw RouterException("Source de fichier non prise en charge.")
        return out.toList()
    }

    private fun mimeOf(ctx: Context, uri: Uri, intent: Intent): String =
        (runCatching { ctx.contentResolver.getType(uri) }.getOrNull() ?: intent.type)
            ?.lowercase() ?: throw RouterException("Type de fichier inconnu.")

    fun displayName(ctx: Context, uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()

    /** Nom de base sûr : sans extension, sans séparateur de chemin ni caractère de contrôle. */
    fun baseName(ctx: Context, uri: Uri, fallback: String): String {
        val raw = displayName(ctx, uri)?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: fallback
        return raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().take(80).ifEmpty { fallback }
    }
}

/**
 * Contrôle de l'appelant. [callingPackage] n'est fiable que si l'activité a été lancée avec
 * startActivityForResult ; sinon la requête est refusée.
 *
 * L'identifiant des applis peut être réécrit à la compilation (ex. com.doubigue.converter), donc on accepte :
 *  - un paquet de la liste [ALLOWED_PACKAGES] ;
 *  - un paquet dont le nom contient « linkshare » ;
 *  - n'importe quelle appli signée avec la même clé que MediaStudio.
 * Le fichier source reste de toute façon choisi et accordé en lecture par l'appelant.
 */
object CallerVerifier {
    private val ALLOWED_PACKAGES = setOf("com.linkshare", "com.doubigue.linkshare", "com.doubigue.linkshareexplorer")

    fun isTrusted(ctx: Context, caller: String?): Boolean {
        if (caller.isNullOrEmpty()) return false
        if (caller in ALLOWED_PACKAGES || caller.contains("linkshare", ignoreCase = true)) return true
        return runCatching {
            ctx.packageManager.checkSignatures(ctx.packageName, caller) == PackageManager.SIGNATURE_MATCH
        }.getOrDefault(false)
    }
}
