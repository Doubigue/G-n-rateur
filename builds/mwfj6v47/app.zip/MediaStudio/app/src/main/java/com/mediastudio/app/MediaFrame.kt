package com.mediastudio.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Capture d'une image (JPEG) d'une vidéo. */
object MediaFrame {
    suspend fun extract(
        ctx: Context, uri: Uri, atMs: Long, output: File, onProgress: (Float) -> Unit = {}
    ) = withContext(Dispatchers.IO) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val t = (if (atMs >= 0) atMs else duration / 2).coerceIn(0L, maxOf(duration - 1, 0L))
            val bmp = r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: error("Image introuvable dans la vidéo")
            output.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            bmp.recycle()
        } finally {
            r.release()
        }
        onProgress(1f)
    }
}
