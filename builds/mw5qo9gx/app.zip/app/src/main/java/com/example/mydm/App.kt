package com.example.mydm

import android.app.Application
import android.util.Log
import androidx.room.Room
import com.example.mydm.core.AppDb
import com.example.mydm.core.Prefs
import com.example.mydm.downloader.DownloadEngine
import com.example.mydm.whatsapp.StatusRepository
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File

class App : Application() {
    lateinit var db: AppDb
    lateinit var downloadEngine: DownloadEngine
    lateinit var statusRepo: StatusRepository

    /** "loading" | "ready" | "error:<message>" — état du moteur yt-dlp */
    val ytState = MutableStateFlow("loading")

    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
        Prefs.init(this)
        com.example.mydm.core.NetworkMonitor.init(this)
        com.example.mydm.core.Incoming.appContext = applicationContext
        com.example.mydm.core.UserScripts.load()
        db = Room.databaseBuilder(this, AppDb::class.java, "mydm.db")
            .addMigrations(object : androidx.room.migration.Migration(2, 3) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("ALTER TABLE tasks ADD COLUMN durationSec INTEGER NOT NULL DEFAULT 0")
                }
            }, object : androidx.room.migration.Migration(3, 4) {
                override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("ALTER TABLE tasks ADD COLUMN scheduledAt INTEGER NOT NULL DEFAULT 0")
                }
            })
            .fallbackToDestructiveMigration().build()
        downloadEngine = DownloadEngine(this, db.downloadDao())
        statusRepo = StatusRepository(this)
        initYtDlp()
        // Téléchargements programmés : on s'assure que les alarmes existent toujours (arrêt forcé, mise à jour…)
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { downloadEngine.rearmSchedules() }
            // Téléphone éteint / appli arrêtée en plein téléchargement : tout repart tout seul (le réseau est attendu si besoin)
            runCatching {
                val ids = downloadEngine.resumeInterrupted()
                if (ids.isNotEmpty()) {
                    try { com.example.mydm.downloader.DownloadService.startMany(this@App, ids) }
                    catch (e: Exception) { ids.forEach { downloadEngine.start(it) } }
                }
            }
        }
    }

    private fun initYtDlp() {
        Thread {
            try {
                YoutubeDL.getInstance().init(this)
                FFmpeg.getInstance().init(this)
                // aria2c : téléchargement multi-connexions des vidéos YouTube/Facebook/TikTok (facultatif : sans lui, yt-dlp seul)
                runCatching { com.yausername.aria2c.Aria2c.getInstance().init(this) }
                    .onSuccess { com.example.mydm.downloader.DownloadEngine.aria2Ready = true }
                ytState.value = "ready"
                // Mise à jour de yt-dlp : au plus une fois par jour et APRÈS une pause, pour ne pas
                // ralentir (ni perturber) les premières analyses de liens
                if (Prefs.autoUpdateYt && System.currentTimeMillis() - Prefs.lastYtUpdate() > 24 * 3600_000L) {
                    Thread.sleep(20_000)
                    runCatching { YoutubeDL.getInstance().updateYoutubeDL(this) }.onSuccess { Prefs.markYtUpdated() }
                }
            } catch (t: Throwable) {
                ytState.value = "error:" + (t.message ?: t::class.java.simpleName)
            }
        }.start()
    }

    /** Mise à jour manuelle (Paramètres). Renvoie un message à afficher. */
    fun updateYtNow(onDone: (String) -> Unit) {
        Thread {
            val msg = try {
                YoutubeDL.getInstance().updateYoutubeDL(this); Prefs.markYtUpdated(); "yt-dlp mis à jour"
            } catch (t: Throwable) { "Échec de la mise à jour : " + (t.message ?: t::class.java.simpleName).take(120) }
            android.os.Handler(mainLooper).post { onDone(msg) }
        }.start()
    }

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(error)) }
            previous?.uncaughtException(thread, error)
        }
    }
}
