package com.example.mydm.core

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.URLUtil
import com.example.mydm.App
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Lien partagé / collé / cliqué : on le télécharge tout de suite, sans écran d'analyse.
 *  • vidéo YouTube / Facebook / TikTok / Instagram / X… et ~1000 autres sites (yt-dlp) → meilleure qualité
 *  • fichier direct (apk, zip, mp4, pdf, iso…)       → téléchargement multi-segments
 *  • simple page web                                 → rien (l'appelant l'ouvre dans le navigateur)
 */
object AutoDownload {
    class Outcome(val started: Boolean, val message: String = "")

    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).followRedirects(true).build()
    private val main = Handler(Looper.getMainLooper())

    private val fileExt = setOf(
        "apk", "xapk", "apks", "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "iso", "img", "exe", "msi", "dmg", "deb", "rpm", "jar",
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "epub", "mobi", "csv",
        "mp4", "mkv", "webm", "avi", "mov", "m4v", "flv", "wmv", "ts", "3gp",
        "mp3", "m4a", "flac", "wav", "ogg", "opus", "aac",
        "glb", "gltf", "usdz", "fbx", "obj", "stl", "ply", "dae", "3ds", "vrm", "blend"
    )
    /** Pour l'analyse d'un lien partagé : tout ce qui est un fichier, images et documents compris. */
    private val anyFileExt = fileExt + setOf(
        "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "avif", "svg", "tif", "tiff",
        "txt", "rtf", "odt", "ods", "odp", "pps", "ppsx", "srt", "torrent", "bin", "appimage", "pkg", "ipa", "obb", "m3u"
    )

    private val urlRe = Regex("https?://\\S+", RegexOption.IGNORE_CASE)

    private fun pathOf(url: String) = (Uri.parse(url).path ?: "").lowercase()

    fun looksLikeFile(url: String): Boolean = pathOf(url).substringAfterLast('.', "") in fileExt
    fun looksLikeAnyFile(url: String): Boolean = pathOf(url).substringAfterLast('.', "") in anyFileExt

    /** Lance le traitement en arrière-plan ; [onDone] est appelé sur le thread principal. */
    fun launch(app: App, link: String, probe: Boolean, onDone: (Outcome) -> Unit) {
        scope.launch {
            val o = runCatching { handle(app, link, probe) }.getOrElse { Outcome(false, "Échec : " + (it.message ?: "erreur").take(100)) }
            withContext(Dispatchers.Main) { onDone(o) }
        }
    }

    private suspend fun handle(app: App, raw: String, probe: Boolean): Outcome = withContext(Dispatchers.IO) {
        val link = raw.trim()
        if (!link.startsWith("http", true)) return@withContext Outcome(false)
        if (looksLikeFile(link)) return@withContext startFile(app, link, null)

        // Plateformes vidéo connues. Un lien PARTAGÉ est toujours tenté (fb.me, facebook.com/share/v/…, vm.tiktok.com…)
        if (MediaResolver.isSupportedPage(link)) {
            if (!probe && !MediaResolver.isVideoPage(link)) return@withContext Outcome(false)
            downloadVideo(app, link, mustHaveInfo = false)?.let { return@withContext it }
            return@withContext Outcome(false, "Aucune vidéo trouvée dans ce lien")
        }

        if (probe) {
            probeFile(link)?.let { return@withContext startFile(app, link, it) }
            // Autre site (Dailymotion, Reddit, Pinterest, Snapchat, Vimeo, Twitch…) : yt-dlp sait extraire la vidéo
            downloadVideo(app, link, mustHaveInfo = true)?.let { return@withContext it }
        }
        Outcome(false)
    }

    /** Analyse silencieuse (yt-dlp) puis téléchargement de la meilleure qualité. null = pas de vidéo. */
    private suspend fun downloadVideo(app: App, link: String, mustHaveInfo: Boolean): Outcome? {
        val info = withTimeoutOrNull(if (mustHaveInfo) 60_000L else 120_000L) { runCatching { MediaResolver.ytInfo(app, link) }.getOrNull() }
        if (info == null && mustHaveInfo) return null
        val opt = info?.options?.firstOrNull { !it.mp3 } ?: QualityOption("", null, false, "bv*+ba/b")
        val title = info?.title?.takeIf { it.isNotBlank() } ?: ("Vidéo " + (Uri.parse(link).host ?: "") + " " + (Uri.parse(link).lastPathSegment ?: "").takeLast(12))
        val id = app.downloadEngine.enqueueYt(link, title, opt, durationSec = info?.durationSec ?: 0, sizeBytes = opt.sizeBytes)
        launchService(app, id)
        return Outcome(true, "Téléchargement démarré : " + title.take(40))
    }

    /** true si le serveur répond par un fichier (et pas par une page web). */
    suspend fun probesAsFile(link: String): Boolean = withContext(Dispatchers.IO) { probeFile(link) != null }

    /** Fichier direct trouvé derrière un lien : nom proposé par le serveur, type, taille (null = inconnue). */
    class FileProbe(val url: String, val name: String, val mime: String?, val size: Long?)

    /**
     * Le lien mène-t-il directement à un fichier (image, APK, document, logiciel, archive, vidéo…) et pas à une page ?
     * Utilisé par l'écran d'analyse : renvoie le nom, le type et la taille ; null si c'est une page web.
     */
    suspend fun probeDirect(link: String): FileProbe? = withContext(Dispatchers.IO) {
        if (pathOf(link).endsWith(".m3u8")) return@withContext null
        probeFile(link) ?: if (looksLikeAnyFile(link)) {
            // serveur muet au sondage mais extension parlante : on garde le nom tiré du lien
            val n = Uri.decode(Uri.parse(link).lastPathSegment ?: "fichier")
            FileProbe(link, n, android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(n.substringAfterLast('.', "").lowercase()), null)
        } else null
    }

    /** Le serveur répond-il par un fichier (et pas une page HTML) ? */
    private fun probeFile(url: String): FileProbe? = runCatching {
        http.newCall(Request.Builder().url(url).header("User-Agent", UA).header("Range", "bytes=0-0").build()).execute().use { r ->
            if (!r.isSuccessful) null else {
                val ct = r.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase()
                val cd = r.header("Content-Disposition")
                val isFile = cd?.contains("attachment", true) == true ||
                    (ct != null && !ct.startsWith("text/") && ct != "application/xhtml+xml" && ct != "application/json" && ct != "application/javascript")
                // playlist HLS (.m3u8) : c'est un flux vidéo, pas un fichier à copier tel quel
                if (!isFile || ct?.contains("mpegurl") == true) null else {
                    // taille : « Content-Range: bytes 0-0/12345 » (reprise possible) sinon Content-Length (réponse entière)
                    val size = r.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull()
                        ?: r.header("Content-Length")?.toLongOrNull()?.takeIf { r.code == 200 && it > 1 }
                    val finalUrl = r.request.url.toString()
                    var name = URLUtil.guessFileName(finalUrl, cd, ct)
                    // image / fichier sans extension dans le lien : extension déduite du type annoncé
                    if (name.endsWith(".bin") && ct != null) android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(ct)
                        ?.let { name = name.removeSuffix(".bin") + "." + it }
                    FileProbe(finalUrl, name, ct, size)
                }
            }
        }
    }.getOrNull()

    private suspend fun startFile(app: App, url: String, p: FileProbe?): Outcome {
        val name = p?.name ?: (Uri.parse(url).lastPathSegment?.takeIf { it.isNotBlank() } ?: "fichier")
        val id = app.downloadEngine.enqueueFile(url, name, p?.mime, UA)
        launchService(app, id)
        return Outcome(true, "Téléchargement démarré : " + name.take(40))
    }

    /** Service au premier plan ; si Android refuse (appli en arrière-plan), le moteur tourne quand même. */
    private fun launchService(app: App, id: String) {
        try { DownloadService.start(app, id) } catch (e: Exception) { app.downloadEngine.start(id) }
    }
}
