package com.example.mydm.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class ViewKind { VIDEO, AUDIO, IMAGE, PDF, TEXT, APK, MODEL3D, OTHER }

data class ViewItem(val uri: Uri, val name: String, val mime: String?) {
    val kind: ViewKind get() = kindOf(name, mime)
}

fun kindOf(name: String, mime: String?): ViewKind {
    val e = extOf(name)
    val m = mime ?: ""
    return when {
        e in modelExt || m.startsWith("model/") -> ViewKind.MODEL3D
        e == "apk" || m == "application/vnd.android.package-archive" -> ViewKind.APK
        m.startsWith("video/") || e in videoExt -> ViewKind.VIDEO
        m.startsWith("audio/") || e in audioExt -> ViewKind.AUDIO
        m.startsWith("image/") || e in imageExt -> ViewKind.IMAGE
        m == "application/pdf" || e == "pdf" -> ViewKind.PDF
        (m.startsWith("text/") && m != "text/x-vcard") || e in textExt -> ViewKind.TEXT
        else -> ViewKind.OTHER
    }
}

fun LibFile.toViewItem() = ViewItem(uri, name, mime)

/** Visionneuse intégrée : liste d'éléments + position courante (lecteur vidéo/audio, images, PDF, texte, APK). */
object Viewer {
    var items by mutableStateOf<List<ViewItem>>(emptyList()); private set
    var index by mutableIntStateOf(0); private set
    val active get() = items.isNotEmpty()
    val current: ViewItem? get() = items.getOrNull(index)

    fun open(list: List<ViewItem>, start: Int = 0) {
        if (list.isEmpty()) return
        items = list; index = start.coerceIn(list.indices)
    }
    /** Ouvre [clicked] avec, comme liste de lecture, les fichiers du même type. */
    fun openFrom(files: List<LibFile>, clicked: LibFile) {
        val kind = kindOf(clicked.name, clicked.mime)
        val same = if (kind == ViewKind.OTHER || kind == ViewKind.APK || kind == ViewKind.MODEL3D) listOf(clicked) else files.filter { kindOf(it.name, it.mime) == kind }
        open(same.map { it.toViewItem() }, same.indexOfFirst { it.uri == clicked.uri }.coerceAtLeast(0))
    }
    fun go(i: Int) { if (i in items.indices) index = i }
    fun next() = go(index + 1)
    fun prev() = go(index - 1)
    fun close() { items = emptyList(); index = 0 }

    /** Fichier reçu d'une autre application (content:// ou file://). */
    fun fromExternal(ctx: Context, uri: Uri, mimeHint: String?): ViewItem {
        var name: String? = null
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        }
        val n = name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "fichier"
        val m = mimeHint?.takeIf { it.isNotBlank() && it != "*/*" } ?: runCatching { ctx.contentResolver.getType(uri) }.getOrNull()
        return ViewItem(uri, n, m)
    }
}

object Installer {
    /** Lance l'installation d'un APK (demande d'abord l'autorisation « sources inconnues » si besoin). */
    fun install(ctx: Context, uri: Uri) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(ctx, "Autorisez MyDM à installer des applications, puis réessayez", Toast.LENGTH_LONG).show()
            runCatching {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return
        }
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { Toast.makeText(ctx, "Installation impossible : ${it.message}", Toast.LENGTH_LONG).show() }
    }
}

fun openWithOtherApp(ctx: Context, item: ViewItem) {
    runCatching {
        ctx.startActivity(Intent.createChooser(
            Intent(Intent.ACTION_VIEW).setDataAndType(item.uri, item.mime ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { Toast.makeText(ctx, "Aucune application pour ouvrir ce fichier", Toast.LENGTH_SHORT).show() }
}

fun shareItem(ctx: Context, item: ViewItem) {
    runCatching {
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(item.mime ?: "*/*")
            .putExtra(Intent.EXTRA_STREAM, item.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
