# MyDM

Navigateur et gestionnaire de téléchargements pour Android : il détecte les vidéos et fichiers des pages web, les télécharge en plusieurs segments et les range automatiquement.

## Fonctions

- **Navigateur avec onglets** : pages web, onglets multiples, menu ⋮ (ZIP d'un site, console, recherche par photo)
- **Détection des médias** : pastille ⬇ avec le nombre de fichiers repérés (flux HLS par qualité, vidéos, sous-titres)
- **Téléchargement rapide** : multi-connexions, pause / reprise, notification avec progression
- **Téléchargements programmés** : choisis l'heure de départ (ce soir, cette nuit, date et heure précises), pour un fichier ou une sélection
- **Lien partagé** : partagez une vidéo Facebook, TikTok, Instagram, YouTube… vers MyDM : un écran « Analyse en cours » s'ouvre, puis la liste des formats (qualités vidéo, audio) avec leur taille
- **Analyser un lien** : YouTube, Facebook, TikTok, avec choix de la qualité ou MP3
- **Onglet Vidéos** : recherche, listes de lecture et chaînes, téléchargement de toute une liste d'un coup
- **Dossiers classés** : Vidéo, Images, Musiques, Documents, Statuts… dans Download/MyDM
- **Lecteur intégré** : vidéo (reprise), audio, images, PDF, texte, installation d'APK
- **Modèles 3D** : détection et téléchargement de GLB, glTF, USDZ, FBX, OBJ, STL… (dossier 3D)
- **Statuts WhatsApp** : liste et enregistrement des statuts
- **Paramètres** : 14 styles (fond, texte, accent), couleur d'accent, vitesse, Wi-Fi uniquement

## Comment l'utiliser

1. Ouvre un site dans le Navigateur et lance la vidéo dans le lecteur de la page.
2. Touche la pastille ⬇, coche les fichiers voulus puis « Télécharger ».
3. Vérifie le nom et le dossier, puis touche « COMMENCER ».
4. Suis la progression dans « Téléchargements » (Pause, Reprendre).
5. Retrouve tes fichiers dans « Dossiers » et ouvre-les avec le lecteur intégré.
6. Pour un lien YouTube, Facebook ou TikTok : « À télécharger » > « Analyser un lien / une page ».

## Astuces

> Certains sites protégés (captcha, DRM) bloquent l'analyse automatique : ouvre la page une fois dans le navigateur, puis relance. Les vidéos de 2 minutes ou moins sont ignorées (publicités) sauf sur les grandes plateformes.

## Captures (dossier Captures)

- `01-navigateur.png` : navigateur avec la pastille ⬇
- `02-fichiers-detectes.png` : fenêtre « Fichier(s) détectés ! »
- `03-telecharger-fichiers.png` : fenêtre « Télécharger le(s) fichier(s) ! »
- `04-telechargements.png` : téléchargements en cours et terminés
- `05-analyser-lien.png` : analyse d'un lien et choix de la qualité
- `06-dossiers.png` : dossiers classés
- `07-videos.png` : onglet Vidéos
- `08-selection.png` : écran « Sélectionné » d'une liste
- `09-torrent.png` : onglet Torrent
- `10-parametres.png` : paramètres et thèmes
