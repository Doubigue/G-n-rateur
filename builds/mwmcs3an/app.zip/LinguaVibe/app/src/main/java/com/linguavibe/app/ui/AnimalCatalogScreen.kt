package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.LanguageInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private data class AnimalTaxon(
    val key: Int, val commonName: String, val scientificName: String,
    val animalClass: String, val family: String
)

private data class AnimalPage(val count: Int, val results: List<AnimalTaxon>)

private object AnimalCatalogRepository {
    private val classKeys = mutableMapOf<String, Int>()

    private suspend fun classKey(name: String): Int = withContext(Dispatchers.IO) {
        classKeys[name]?.let { return@withContext it }
        val url = "https://api.gbif.org/v1/species/match?name=${URLEncoder.encode(name, "UTF-8")}&rank=CLASS&strict=true"
        val connection = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 12000; readTimeout = 15000 }
        try {
            val result = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val key = result.optInt("usageKey", -1)
            if (key <= 0) throw IllegalStateException("Classe taxonomique introuvable")
            classKeys[name] = key
            key
        } finally { connection.disconnect() }
    }

    suspend fun search(language: String, query: String, animalClass: String, offset: Int): AnimalPage = withContext(Dispatchers.IO) {
        val parentKey = if (animalClass.isBlank()) 1 else classKey(animalClass)
        val params = buildList {
            add("rank=SPECIES")
            add("highertaxon_key=$parentKey") // Animalia ou classe demandée
            add("status=ACCEPTED")
            add("limit=100")
            add("offset=$offset")
            if (query.isNotBlank()) add("q=${URLEncoder.encode(query.trim(), "UTF-8")}")
        }.joinToString("&")
        val connection = (URL("https://api.gbif.org/v1/species/search?$params").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Accept-Language", language)
            setRequestProperty("User-Agent", "LinguaVibe-Android-AnimalCatalog/1.0")
        }
        try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val rows = root.optJSONArray("results")
            val parsed = buildList {
                if (rows != null) for (i in 0 until rows.length()) {
                    val item = rows.optJSONObject(i) ?: continue
                    val key = item.optInt("key", -1)
                    val sci = item.optString("scientificName").ifBlank { item.optString("canonicalName") }
                    if (key > 0 && sci.isNotBlank()) {
                        val common = item.optString("vernacularName").ifBlank { item.optString("canonicalName", sci) }
                        add(AnimalTaxon(key, common, sci, item.optString("class", "Animal"), item.optString("family", "")))
                    }
                }
            }
            AnimalPage(root.optInt("count", parsed.size), parsed)
        } finally { connection.disconnect() }
    }
}

private data class AnimalGroup(val label: String, val apiClass: String, val emoji: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimalCatalogScreen(lang: LanguageInfo, onBack: () -> Unit) {
    val groups = listOf(
        AnimalGroup("Tous", "", "🐾"), AnimalGroup("Mammifères", "Mammalia", "🦁"),
        AnimalGroup("Oiseaux", "Aves", "🦅"), AnimalGroup("Reptiles", "Reptilia", "🐊"),
        AnimalGroup("Amphibiens", "Amphibia", "🐸"), AnimalGroup("Poissons", "Actinopterygii", "🐟"),
        AnimalGroup("Requins et raies", "Chondrichthyes", "🦈"), AnimalGroup("Insectes", "Insecta", "🦋"),
        AnimalGroup("Araignées et scorpions", "Arachnida", "🕷️"), AnimalGroup("Mollusques", "Mollusca", "🐙"),
        AnimalGroup("Crustacés", "Malacostraca", "🦀"), AnimalGroup("Coraux et méduses", "Cnidaria", "🪼"),
        AnimalGroup("Échinodermes", "Echinodermata", "⭐"), AnimalGroup("Vers annelés", "Annelida", "🪱"),
        AnimalGroup("Mille-pattes", "Myriapoda", "🐛"), AnimalGroup("Éponges marines", "Porifera", "🧽")
    )
    var selectedGroup by remember { mutableStateOf(groups.first()) }
    var query by rememberSaveable { mutableStateOf("") }
    var animals by remember { mutableStateOf<List<AnimalTaxon>>(emptyList()) }
    var count by remember { mutableIntStateOf(0) }
    var offset by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var refreshTrigger by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    suspend fun load(reset: Boolean) {
        if (loading && !reset) return
        loading = true
        error = ""
        val requestedQuery = query
        val requestedClass = selectedGroup.apiClass
        try {
            val start = if (reset) 0 else offset
            val page = AnimalCatalogRepository.search(lang.code, requestedQuery, requestedClass, start)
            if (requestedQuery == query && requestedClass == selectedGroup.apiClass) {
                animals = if (reset) page.results else animals + page.results.filterNot { a -> animals.any { it.key == a.key } }
                count = page.count
                offset = start + page.results.size
            }
        } catch (e: Exception) {
            if (requestedQuery == query && requestedClass == selectedGroup.apiClass) error = "Connexion impossible. Vérifiez Internet puis réessayez."
        } finally { loading = false }
    }

    LaunchedEffect(query, selectedGroup, lang.code, refreshTrigger) {
        delay(400)
        load(true)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFFF7F5F1))) {
        TopBar("Dictionnaire des animaux", "Noms dans ${lang.nativeName} · base taxonomique mondiale", Color(0xFF176B58), onBack)
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🔎", fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                BasicTextField(value = query, onValueChange = { query = it }, modifier = Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFF202820), fontSize = 15.sp), decorationBox = { inner -> if (query.isEmpty()) Text("Rechercher un animal ou son nom scientifique…", color = Color.Gray, fontSize = 13.sp); inner() })
                if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("Effacer") }
            }
            Spacer(Modifier.height(10.dp))
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(groups) { group ->
                    FilterChip(selected = selectedGroup == group, onClick = { selectedGroup = group }, label = { Text("${group.emoji} ${group.label}") })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(if (count > 0) "${animals.size} espèces affichées sur $count résultats disponibles" else "Catalogue mondial · chargement par pages de 100 espèces", color = Color(0xFF64736A), fontSize = 12.sp)
        }
        when {
            loading && animals.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            error.isNotEmpty() && animals.isEmpty() -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(error); Button(onClick = { refreshTrigger++ }) { Text("Réessayer") } }
            animals.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Aucune espèce trouvée.") }
            else -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(animals, key = { it.key }) { animal ->
                    val icon = when (animal.animalClass) { "Mammalia" -> "🐾"; "Aves" -> "🪶"; "Reptilia" -> "🐊"; "Amphibia" -> "🐸"; "Insecta" -> "🦋"; "Arachnida" -> "🕷️"; "Actinopterygii", "Chondrichthyes", "Sarcopterygii" -> "🐟"; "Mollusca" -> "🐙"; "Malacostraca" -> "🦀"; "Cnidaria" -> "🪼"; "Echinodermata" -> "⭐"; "Annelida" -> "🪱"; "Myriapoda" -> "🐛"; "Porifera" -> "🧽"; else -> "🌿" }
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Color.White).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F2EC)), contentAlignment = Alignment.Center) { Text(icon, fontSize = 27.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(animal.commonName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF20352A))
                            Text(animal.scientificName, fontSize = 12.sp, color = Color(0xFF66766D), fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                            Text(listOf(animal.animalClass, animal.family).filter { it.isNotBlank() }.joinToString(" · "), fontSize = 10.sp, color = Color(0xFF8A958E))
                        }
                    }
                }
                item {
                    if (offset < count && animals.size < 2000) {
                        Button(onClick = { scope.launch { load(false) } }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                            Text(if (loading) "Chargement…" else "Charger 100 espèces supplémentaires")
                        }
                    } else if (animals.size >= 2000) Text("Les 2 000 premières espèces de cette recherche sont chargées.", modifier = Modifier.padding(12.dp), color = Color.Gray)
                    Text("Source des noms scientifiques et vernaculaires : GBIF. Les noms communs dépendent des langues renseignées par les contributeurs ; le nom scientifique est conservé en l'absence de traduction.", modifier = Modifier.padding(top = 12.dp, bottom = 8.dp), color = Color(0xFF7A867E), fontSize = 10.sp)
                }
            }
        }
    }
}
